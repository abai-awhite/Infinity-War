package entity;

import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

/**
 * 敌对怪物类
 * 继承自entity基类，实现基本的AI行为和与玩家的交互
 * 包括巡逻、追击、攻击等行为模式
 */
public class enemy extends entity {
    GamePanel gp;
    
    // AI行为相关
    public enum AIState {
        PATROL,      // 巡逻状态
        CHASE,       // 追击状态
        ATTACK,      // 攻击状态
        IDLE,        // 待机状态
        SEARCH,      // 搜索状态（失去目标后搜索）
        RETREAT,     // 撤退状态（生命值低时）
        JUMP_CHASE,  // 跳跃追击状态
        AMBUSH       // 伏击状态
    }
    
    public AIState currentState = AIState.PATROL;
    public AIState previousState = AIState.PATROL;
    
    // 检测和攻击参数
    public int detectionRange = 200;        // 检测范围（像素）
    public int attackRange = 70;            // 攻击范围（像素）
    public int patrolDistance = 1024;        // 巡逻距离
    public int patrolStartX;                // 巡逻起始点X
    public boolean patrolDirection = true;  // 巡逻方向（true=右，false=左）
    
    // 高级AI参数
    public int searchTimer = 0;             // 搜索计时器
    public int maxSearchTime = 300;         // 最大搜索时间（5秒）
    public int lastPlayerX, lastPlayerY;    // 玩家最后已知位置
    public int stateTimer = 0;              // 状态计时器
    public int aggressionLevel = 1;         // 攻击性等级（1-3）
    public boolean canJump = true;          // 是否能跳跃
    public int jumpCooldown = 0;            // 跳跃冷却
    public int maxJumpCooldown = 120;       // 最大跳跃冷却
    public double intelligence = 1.0;       // 智能等级（影响反应速度）
    public int reactionDelay = 0;           // 反应延迟
    public int maxReactionDelay = 30;       // 最大反应延迟
    public int moveTimer = 0;               // 移动计时器
    public int moveInterval = 3;            // 移动间隔（每3帧移动一次，降低移动速度）
    
    // 战斗相关
    public int health = 100;                // 生命值
    public int maxHealth = 100;             // 最大生命值
    public int damage = 20;                 // 攻击伤害
    public int attackCooldown = 0;          // 攻击冷却
    public int maxAttackCooldown = 60;      // 最大攻击冷却（帧数）
    
    // 动画相关
    public BufferedImage[] walkLeft = new BufferedImage[2];
    public BufferedImage[] walkRight = new BufferedImage[2];
    public BufferedImage[] attackLeft = new BufferedImage[2];
    public BufferedImage[] attackRight = new BufferedImage[2];
    public BufferedImage[] idleLeft = new BufferedImage[2];
    public BufferedImage[] idleRight = new BufferedImage[2];
    
    private Random random = new Random();
    
    /**
     * 构造函数
     * @param gp 游戏面板引用
     * @param startX 初始X坐标
     * @param startY 初始Y坐标
     */
    public enemy(GamePanel gp, int startX, int startY) {
        this.gp = gp;
        this.worldx = startX;
        this.worldy = startY;
        this.patrolStartX = startX;
        this.lastPlayerX = startX;
        this.lastPlayerY = startY;
        
        // 初始化AABB碰撞检测
        setUseAABBCollision(true);
        setAABBSize(48, 48);
        setAABBOffset(8, 8);
        
        setDefaultValues();
        randomizeAttributes();
        loadEnemyImages();
    }
    
    /**
     * 设置默认属性值
     */
    public void setDefaultValues() {
        speed = 1;                              // 移动速度
        direction = "right";
        solidarea = new Rectangle(8, 8, 48, 48); // 碰撞箱
        
        // 初始化AABB边界框
        initializeAABB();
        
        // 物理参数（简化的重力系统）
        gravity = 0.5;
        maxFallSpeed = 8;
        onGround = false;
        
        // 跳跃参数
        jumpStrength = -12;
        velocityY = 0;
    }
    
    /**
     * 随机化敌人属性，创造多样性
     */
    private void randomizeAttributes() {
        // 随机化基础属性
        aggressionLevel = random.nextInt(3) + 1; // 1-3
        intelligence = 0.5 + random.nextDouble() * 1.5; // 0.5-2.0
        
        // 根据攻击性等级调整属性
        switch (aggressionLevel) {
            case 1: // 温和型
                detectionRange = 150 + random.nextInt(50);
                speed = 1;
                damage = 15 + random.nextInt(10);
                maxAttackCooldown = 80 + random.nextInt(40);
                canJump = random.nextBoolean();
                break;
            case 2: // 平衡型
                detectionRange = 200 + random.nextInt(50);
                speed = 1 + random.nextInt(1);
                damage = 20 + random.nextInt(10);
                maxAttackCooldown = 60 + random.nextInt(30);
                canJump = random.nextDouble() > 0.3;
                break;
            case 3: // 攻击型
                detectionRange = 250 + random.nextInt(50);
                speed = 2;
                damage = 25 + random.nextInt(15);
                maxAttackCooldown = 40 + random.nextInt(20);
                canJump = true;
                break;
        }
        
        // 随机化巡逻距离
        patrolDistance = 100 + random.nextInt(100);
        
        // 设置反应延迟（智能等级越高，反应越快）
        maxReactionDelay = (int)(50 / intelligence);
        
        // 随机初始状态（偶尔从伏击状态开始）
        if (random.nextDouble() < 0.1) {
            currentState = AIState.AMBUSH;
        }
    }
    
    /**
     * 加载敌人图像资源
     */
    public void loadEnemyImages() {
        try {
            // 加载用户提供的怪物图像
            BufferedImage enemyImage = ImageIO.read(getClass().getResourceAsStream("/res/player/other.png"));
            
            if (enemyImage != null) {
                // 使用真实的怪物图像
                for (int i = 0; i < 2; i++) {
                    walkLeft[i] = enemyImage;
                    walkRight[i] = flipImageHorizontally(enemyImage);
                    attackLeft[i] = enemyImage;
                    attackRight[i] = flipImageHorizontally(enemyImage);
                    idleLeft[i] = enemyImage;
                    idleRight[i] = flipImageHorizontally(enemyImage);
                }
            } else {
                // 如果图像加载失败，使用备用的颜色块
                System.out.println("Warning: Could not load enemy image, using fallback colors");
                for (int i = 0; i < 2; i++) {
                    walkLeft[i] = createColoredImage(Color.RED, 64, 64);
                    walkRight[i] = createColoredImage(Color.RED, 64, 64);
                    attackLeft[i] = createColoredImage(Color.DARK_GRAY, 64, 64);
                    attackRight[i] = createColoredImage(Color.DARK_GRAY, 64, 64);
                    idleLeft[i] = createColoredImage(Color.RED, 64, 64);
                    idleRight[i] = createColoredImage(Color.RED, 64, 64);
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading enemy image: " + e.getMessage());
            e.printStackTrace();
            // 使用备用的颜色块
            for (int i = 0; i < 2; i++) {
                walkLeft[i] = createColoredImage(Color.RED, 64, 64);
                walkRight[i] = createColoredImage(Color.RED, 64, 64);
                attackLeft[i] = createColoredImage(Color.DARK_GRAY, 64, 64);
                attackRight[i] = createColoredImage(Color.DARK_GRAY, 64, 64);
                idleLeft[i] = createColoredImage(Color.RED, 64, 64);
                idleRight[i] = createColoredImage(Color.RED, 64, 64);
            }
        }
    }
    
    /**
     * 创建指定颜色的图像
     */
    private BufferedImage createColoredImage(Color color, int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        g2.setColor(color);
        g2.fillRect(0, 0, width, height);
        g2.setColor(Color.BLACK);
        g2.drawRect(0, 0, width-1, height-1);
        g2.dispose();
        return image;
    }
    
    /**
     * 水平翻转图像
     */
    private BufferedImage flipImageHorizontally(BufferedImage original) {
        int width = original.getWidth();
        int height = original.getHeight();
        BufferedImage flipped = new BufferedImage(width, height, original.getType());
        Graphics2D g2 = flipped.createGraphics();
        g2.drawImage(original, width, 0, 0, height, 0, 0, width, height, null);
        g2.dispose();
        return flipped;
    }
    
    /**
     * 更新敌人状态
     */
    public void update() {
        // 更新各种计时器
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        if (jumpCooldown > 0) {
            jumpCooldown--;
        }
        if (reactionDelay > 0) {
            reactionDelay--;
        }
        if (searchTimer > 0) {
            searchTimer--;
        }
        
        stateTimer++;
        
        // 更新AI（只有在反应延迟结束后才执行）
        if (reactionDelay == 0) {
            updateAdvancedAI();
        }
        
        applyGravity();
        updateAnimation();
    }
    
    /**
     * 应用重力效果
     */
    private void applyGravity() {
        if (!onGround) {
            velocityY += gravity;
            if (velocityY > maxFallSpeed) {
                velocityY = maxFallSpeed;
            }
        }
        
        // 垂直移动
        if (velocityY != 0) {
            moveVerticallyWithCollision((int)velocityY);
        }
    }
    
    /**
     * 垂直移动并检测碰撞
     */
    private void moveVerticallyWithCollision(int totalMovement) {
        if (totalMovement == 0) return;
        
        int direction = totalMovement > 0 ? 1 : -1;
        int remainingMovement = Math.abs(totalMovement);
        int maxStepSize = 2;
        
        while (remainingMovement > 0) {
            int currentStep = Math.min(remainingMovement, maxStepSize);
            int moveDistance = currentStep * direction;
            
            int oldWorldY = worldy;
            worldy += moveDistance;
            
            collisionon = false;
            gp.checker.checkVerticalCollision(this, moveDistance);
            
            if (collisionon) {
                worldy = oldWorldY;
                
                if (velocityY > 0) {
                    onGround = true;
                }
                velocityY = 0;
                break;
            } else {
                remainingMovement -= currentStep;
                if (onGround && velocityY >= 0) {
                    onGround = false;
                }
            }
        }
    }
    
    /**
     * 更新AI行为
     */
    /**
     * 高级AI系统 - 更智能的行为决策
     */
    private void updateAdvancedAI() {
        double distanceToPlayer = getDistanceToPlayer();
        boolean playerVisible = isPlayerVisible();
        
        // 记录玩家位置（如果可见）
        if (playerVisible) {
            lastPlayerX = gp.player.worldx;
            lastPlayerY = gp.player.worldy;
            searchTimer = maxSearchTime; // 重置搜索计时器
        }
        
        // 状态转换逻辑
        AIState newState = determineNextState(distanceToPlayer, playerVisible);
        
        if (newState != currentState) {
            previousState = currentState;
            currentState = newState;
            stateTimer = 0;
            
            // 状态切换时的反应延迟
            if (intelligence < 1.5) {
                reactionDelay = (int)(maxReactionDelay / intelligence);
            }
        }
        
        // 执行当前状态的行为
        executeCurrentState(distanceToPlayer, playerVisible);
    }
    
    /**
     * 确定下一个AI状态
     */
    private AIState determineNextState(double distanceToPlayer, boolean playerVisible) {
        // 生命值低于30%时考虑撤退
        if (health < maxHealth * 0.3 && aggressionLevel < 3) {
            return AIState.RETREAT;
        }
        
        switch (currentState) {
            case PATROL:
                if (playerVisible && distanceToPlayer <= detectionRange) {
                    return (canJump && needsToJump()) ? AIState.JUMP_CHASE : AIState.CHASE;
                }
                // 偶尔进入伏击状态
                if (stateTimer > 300 && random.nextDouble() < 0.05) {
                    return AIState.AMBUSH;
                }
                break;
                
            case CHASE:
                if (!playerVisible) {
                    return AIState.SEARCH;
                }
                if (distanceToPlayer <= attackRange && attackCooldown == 0) {
                    return AIState.ATTACK;
                }
                if (canJump && needsToJump() && jumpCooldown == 0) {
                    return AIState.JUMP_CHASE;
                }
                if (distanceToPlayer > detectionRange * 2) {
                    return AIState.PATROL;
                }
                break;
                
            case JUMP_CHASE:
                if (!playerVisible) {
                    return AIState.SEARCH;
                }
                if (onGround) {
                    if (distanceToPlayer <= attackRange && attackCooldown == 0) {
                        return AIState.ATTACK;
                    } else {
                        return AIState.CHASE;
                    }
                }
                break;
                
            case ATTACK:
                return AIState.CHASE;
                
            case SEARCH:
                if (playerVisible) {
                    return AIState.CHASE;
                }
                if (searchTimer <= 0) {
                    return AIState.PATROL;
                }
                break;
                
            case RETREAT:
                if (health > maxHealth * 0.6) {
                    return AIState.PATROL;
                }
                if (distanceToPlayer > detectionRange * 2) {
                    return AIState.IDLE;
                }
                break;
                
            case AMBUSH:
                if (playerVisible && distanceToPlayer <= detectionRange * 0.8) {
                    return AIState.CHASE;
                }
                if (stateTimer > 600) { // 10秒后放弃伏击
                    return AIState.PATROL;
                }
                break;
                
            case IDLE:
                if (playerVisible && distanceToPlayer <= detectionRange) {
                    return AIState.CHASE;
                }
                if (stateTimer > 180) { // 3秒后开始巡逻
                    return AIState.PATROL;
                }
                break;
        }
        
        return currentState;
    }
    
    /**
     * 执行当前状态的具体行为
     */
    private void executeCurrentState(double distanceToPlayer, boolean playerVisible) {
        switch (currentState) {
            case PATROL:
                smartPatrol();
                break;
            case CHASE:
                intelligentChase(distanceToPlayer);
                break;
            case JUMP_CHASE:
                jumpChase();
                break;
            case ATTACK:
                attackPlayer();
                break;
            case SEARCH:
                searchForPlayer();
                break;
            case RETREAT:
                retreatFromPlayer();
                break;
            case AMBUSH:
                ambushBehavior();
                break;
            case IDLE:
                // 待机，偶尔左右看看
                if (stateTimer % 60 == 0) {
                    direction = direction.equals("right") ? "left" : "right";
                }
                break;
        }
    }
    
    /**
     * 智能巡逻行为 - 更自然的巡逻模式
     */
    private void smartPatrol() {
        // 偶尔停顿，让巡逻更自然
        if (stateTimer % 120 == 0 && random.nextDouble() < 0.3) {
            return; // 短暂停顿
        }
        
        if (patrolDirection) {
            // 向右巡逻
            if (worldx < patrolStartX + patrolDistance) {
                moveHorizontally(speed);
                direction = "right";
            } else {
                patrolDirection = false;
                // 转向时短暂停顿
                if (random.nextDouble() < 0.5) {
                    currentState = AIState.IDLE;
                    stateTimer = 0;
                }
            }
        } else {
            // 向左巡逻
            if (worldx > patrolStartX - patrolDistance) {
                moveHorizontally(-speed);
                direction = "left";
            } else {
                patrolDirection = true;
                // 转向时短暂停顿
                if (random.nextDouble() < 0.5) {
                    currentState = AIState.IDLE;
                    stateTimer = 0;
                }
            }
        }
    }
    
    /**
     * 智能追击玩家 - 预测性移动和障碍处理
     */
    private void intelligentChase(double distanceToPlayer) {
        int playerX = gp.player.worldx;
        int playerY = gp.player.worldy;
        
        // 预测玩家移动（基于玩家当前方向）
        int predictedPlayerX = playerX;
        if (intelligence > 1.2) {
            String playerDirection = gp.player.direction;
            int playerSpeed = gp.player.speed;
            
            if (playerDirection.equals("right")) {
                predictedPlayerX += playerSpeed * 10; // 预测10帧后的位置
            } else if (playerDirection.equals("left")) {
                predictedPlayerX -= playerSpeed * 10;
            }
        }
        
        // 根据距离调整速度
        int moveSpeed = speed;
        if (distanceToPlayer > 150) {
            moveSpeed = Math.min(speed + 1, 3); // 距离远时加速
        } else if (distanceToPlayer < 80) {
            moveSpeed = Math.max(speed - 1, 1); // 距离近时减速，避免冲过头
        }
        
        // 移动逻辑
        if (predictedPlayerX > worldx + 10) {
            moveHorizontally(moveSpeed);
            direction = "right";
        } else if (predictedPlayerX < worldx - 10) {
            moveHorizontally(-moveSpeed);
            direction = "left";
        }
        
        // 如果被卡住，尝试跳跃
        if (stateTimer > 60 && Math.abs(predictedPlayerX - worldx) > 20) {
            if (canJump && jumpCooldown == 0 && onGround) {
                currentState = AIState.JUMP_CHASE;
            }
        }
    }
    
    /**
     * 跳跃追击行为
     */
    private void jumpChase() {
        if (onGround && jumpCooldown == 0) {
            // 执行跳跃
            velocityY = jumpStrength;
            onGround = false;
            jumpCooldown = maxJumpCooldown;
            
            // 跳跃时继续水平移动
            int playerX = gp.player.worldx;
            if (playerX > worldx) {
                moveHorizontally(speed + 1);
                direction = "right";
            } else if (playerX < worldx) {
                moveHorizontally(-(speed + 1));
                direction = "left";
            }
        } else if (!onGround) {
            // 在空中时继续水平移动
            int playerX = gp.player.worldx;
            if (playerX > worldx) {
                moveHorizontally(1);
                direction = "right";
            } else if (playerX < worldx) {
                moveHorizontally(-1);
                direction = "left";
            }
        }
    }
    
    /**
     * 搜索玩家行为
     */
    private void searchForPlayer() {
        // 前往玩家最后已知位置
        if (Math.abs(worldx - lastPlayerX) > 20) {
            if (lastPlayerX > worldx) {
                moveHorizontally(speed);
                direction = "right";
            } else {
                moveHorizontally(-speed);
                direction = "left";
            }
        } else {
            // 到达最后位置后，左右搜索
            if (stateTimer % 120 < 60) {
                moveHorizontally(speed);
                direction = "right";
            } else {
                moveHorizontally(-speed);
                direction = "left";
            }
        }
    }
    
    /**
     * 撤退行为
     */
    private void retreatFromPlayer() {
        int playerX = gp.player.worldx;
        
        // 远离玩家
        if (playerX > worldx) {
            moveHorizontally(-speed);
            direction = "left";
        } else {
            moveHorizontally(speed);
            direction = "right";
        }
        
        // 如果被逼到角落，尝试跳跃逃脱
        if (canJump && jumpCooldown == 0 && onGround && stateTimer % 60 == 0) {
            velocityY = jumpStrength;
            onGround = false;
            jumpCooldown = maxJumpCooldown;
        }
    }
    
    /**
     * 伏击行为
     */
    private void ambushBehavior() {
        // 保持静止，等待玩家接近
        // 偶尔调整方向面向玩家
        if (stateTimer % 90 == 0) {
            int playerX = gp.player.worldx;
            direction = (playerX > worldx) ? "right" : "left";
        }
    }
    
    /**
     * 检查玩家是否可见（简单的视线检查）
     */
    private boolean isPlayerVisible() {
        double distance = getDistanceToPlayer();
        if (distance > detectionRange) {
            return false;
        }
        
        // 简单的视线检查 - 检查是否有墙壁阻挡
        int playerX = gp.player.worldx;
        int playerY = gp.player.worldy;
        
        // 如果玩家在不同的高度层，视为不可见
        if (Math.abs(playerY - worldy) > gp.tileSize * 2) {
            return false;
        }
        
        return true; // 简化版本，实际可以添加更复杂的视线检查
    }
    
    /**
     * 检查是否需要跳跃
     */
    private boolean needsToJump() {
        int playerY = gp.player.worldy;
        
        // 如果玩家在更高的位置，需要跳跃
        if (playerY < worldy - gp.tileSize) {
            return true;
        }
        
        // 如果前方有障碍物，需要跳跃
        // 这里可以添加更复杂的障碍检测逻辑
        
        return false;
    }
    
    /**
     * 智能攻击玩家
     */
    private void attackPlayer() {
        // 设置攻击冷却
        attackCooldown = maxAttackCooldown;
        
        // 面向玩家
        int playerX = gp.player.worldx;
        direction = (playerX > worldx) ? "right" : "left";
        
        // 检查玩家是否在攻击范围内
        double distanceToPlayer = getDistanceToPlayer();
        if (distanceToPlayer <= attackRange) {
            // 对玩家造成伤害
            if (gp.player != null) {
                // 计算实际伤害（基于攻击性等级）
                int actualDamage = damage + (aggressionLevel - 1) * 5;
                
                // 暴击几率（智能等级越高，暴击几率越高）
                if (random.nextDouble() < intelligence * 0.1) {
                    actualDamage = (int)(actualDamage * 1.5);
                    System.out.println("Critical hit! Enemy deals " + actualDamage + " damage!");
                } else {
                    System.out.println("Enemy attacks player for " + actualDamage + " damage!");
                }
                
                // 调用玩家的受伤方法
                gp.player.takeDamage(actualDamage);
            }
        }
        
        // 攻击后短暂后退（更真实的战斗行为）
        if (aggressionLevel < 3) {
            int retreatDistance = 10;
            if (direction.equals("right")) {
                moveHorizontally(-retreatDistance);
            } else {
                moveHorizontally(retreatDistance);
            }
        }
    }
    
    /**
     * 水平移动
     */
    private void moveHorizontally(int moveDistance) {
        if (moveDistance == 0) return;
        
        // 使用移动计时器控制移动频率
        moveTimer++;
        if (moveTimer < moveInterval) {
            return; // 还没到移动时间，跳过移动
        }
        moveTimer = 0; // 重置计时器
        
        int oldWorldX = worldx;
        worldx += moveDistance;
        
        collisionon = false;
        gp.checker.checkHorizontalCollision(this, moveDistance);
        
        if (collisionon) {
            worldx = oldWorldX;
            // 碰到墙壁时改变巡逻方向
            if (currentState == AIState.PATROL) {
                patrolDirection = !patrolDirection;
            }
        }
    }
    
    /**
     * 计算与玩家的距离
     */
    private double getDistanceToPlayer() {
        int dx = gp.player.worldx - worldx;
        int dy = gp.player.worldy - worldy;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * 更新动画
     */
    private void updateAnimation() {
        spriteCounter++;
        if (spriteCounter > 20) {
            spriteNum = (spriteNum == 1) ? 2 : 1;
            spriteCounter = 0;
        }
    }
    
    /**
     * 绘制敌人（增强版）
     */
    public void draw(Graphics2D g2) {
        // 计算屏幕坐标
        int screenX = worldx - gp.player.worldx + gp.player.screenx;
        int screenY = worldy - gp.player.worldy + gp.player.screeny;
        
        // 只在屏幕范围内绘制
        if (worldx + gp.tileSize > gp.player.worldx - gp.player.screenx &&
            worldx - gp.tileSize < gp.player.worldx + gp.player.screenx &&
            worldy + gp.tileSize > gp.player.worldy - gp.player.screeny &&
            worldy - gp.tileSize < gp.player.worldy + gp.player.screeny) {
            
            BufferedImage image = null;
            Color enemyColor = getStateColor();
            
            // 根据状态和方向选择图像
            switch (currentState) {
                case ATTACK:
                    image = direction.equals("right") ? 
                           attackRight[spriteNum - 1] : attackLeft[spriteNum - 1];
                    break;
                case CHASE:
                case JUMP_CHASE:
                case SEARCH:
                    image = direction.equals("right") ? 
                           walkRight[spriteNum - 1] : walkLeft[spriteNum - 1];
                    break;
                case PATROL:
                    image = direction.equals("right") ? 
                           walkRight[spriteNum - 1] : walkLeft[spriteNum - 1];
                    break;
                case RETREAT:
                    image = direction.equals("right") ? 
                           walkRight[spriteNum - 1] : walkLeft[spriteNum - 1];
                    break;
                case AMBUSH:
                case IDLE:
                default:
                    image = direction.equals("right") ? 
                           idleRight[spriteNum - 1] : idleLeft[spriteNum - 1];
                    break;
            }
            
            // 绘制敌人图像
            if (image != null) {
                g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
                
                // 根据AI状态添加颜色滤镜
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
                g2.setColor(enemyColor);
                g2.fillRect(screenX, screenY, gp.tileSize, gp.tileSize);
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
            } else {
                // 备用绘制方法（如果图像加载失败）
                g2.setColor(enemyColor);
                g2.fillRect(screenX, screenY, gp.tileSize, gp.tileSize);
            }
            
            // 绘制边框
            g2.setColor(Color.BLACK);
            g2.drawRect(screenX, screenY, gp.tileSize, gp.tileSize);
            
            // 绘制方向指示器
            drawDirectionIndicator(g2, screenX, screenY);
            
            // 绘制状态指示器
            drawStateIndicator(g2, screenX, screenY);
            
            // 绘制生命值条
            drawHealthBar(g2, screenX, screenY);
            
            // 绘制检测范围（调试用，可选）
            if (currentState == AIState.CHASE || currentState == AIState.SEARCH) {
                drawDetectionRange(g2, screenX, screenY);
            }
        }
    }
    
    /**
     * 根据AI状态获取颜色
     */
    private Color getStateColor() {
        switch (currentState) {
            case PATROL:
                return new Color(100, 150, 100); // 绿色 - 平静
            case CHASE:
            case JUMP_CHASE:
                return new Color(200, 100, 100); // 红色 - 攻击性
            case ATTACK:
                return new Color(255, 50, 50);   // 亮红色 - 攻击中
            case SEARCH:
                return new Color(200, 200, 100); // 黄色 - 搜索
            case RETREAT:
                return new Color(100, 100, 200); // 蓝色 - 撤退
            case AMBUSH:
                return new Color(150, 100, 150); // 紫色 - 伏击
            case IDLE:
            default:
                return new Color(150, 150, 150); // 灰色 - 待机
        }
    }
    
    /**
     * 绘制方向指示器
     */
    private void drawDirectionIndicator(Graphics2D g2, int screenX, int screenY) {
        g2.setColor(Color.WHITE);
        int centerX = screenX + gp.tileSize / 2;
        int centerY = screenY + gp.tileSize / 2;
        
        if (direction.equals("right")) {
            g2.fillPolygon(new int[]{centerX, centerX + 10, centerX}, 
                          new int[]{centerY - 5, centerY, centerY + 5}, 3);
        } else {
            g2.fillPolygon(new int[]{centerX, centerX - 10, centerX}, 
                          new int[]{centerY - 5, centerY, centerY + 5}, 3);
        }
    }
    
    /**
     * 绘制状态指示器
     */
    private void drawStateIndicator(Graphics2D g2, int screenX, int screenY) {
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 10));
        
        String stateText = "";
        switch (currentState) {
            case PATROL: stateText = "P"; break;
            case CHASE: stateText = "C"; break;
            case JUMP_CHASE: stateText = "JC"; break;
            case ATTACK: stateText = "A"; break;
            case SEARCH: stateText = "S"; break;
            case RETREAT: stateText = "R"; break;
            case AMBUSH: stateText = "AM"; break;
            case IDLE: stateText = "I"; break;
        }
        
        g2.drawString(stateText, screenX + 2, screenY + 12);
        
        // 绘制攻击性等级
        g2.setColor(Color.YELLOW);
        for (int i = 0; i < aggressionLevel; i++) {
            g2.fillOval(screenX + 2 + i * 6, screenY + gp.tileSize - 8, 4, 4);
        }
    }
    
    /**
     * 绘制检测范围（调试用）
     */
    private void drawDetectionRange(Graphics2D g2, int screenX, int screenY) {
        g2.setColor(new Color(255, 0, 0, 30)); // 半透明红色
        int centerX = screenX + gp.tileSize / 2;
        int centerY = screenY + gp.tileSize / 2;
        int rangeRadius = detectionRange;
        
        g2.fillOval(centerX - rangeRadius, centerY - rangeRadius, 
                   rangeRadius * 2, rangeRadius * 2);
    }
    
    /**
     * 绘制生命值条
     */
    private void drawHealthBar(Graphics2D g2, int screenX, int screenY) {
        // 生命值条背景
        g2.setColor(Color.BLACK);
        g2.fillRect(screenX, screenY - 10, gp.tileSize, 6);
        
        // 生命值条
        g2.setColor(Color.RED);
        int healthWidth = (int)((double)health / maxHealth * gp.tileSize);
        g2.fillRect(screenX, screenY - 10, healthWidth, 6);
        
        // 生命值条边框
        g2.setColor(Color.WHITE);
        g2.drawRect(screenX, screenY - 10, gp.tileSize, 6);
    }
    
    /**
     * 受到伤害
     */
    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            health = 0;
            // 敌人死亡逻辑
        }
    }
    
    /**
     * 检查是否死亡
     */
    public boolean isDead() {
        return health <= 0;
    }
}