package entity;

import main.GamePanel;
import item.BlockItem;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

/**
 * 炸弹实体类
 * 处理炸弹的爆炸逻辑、方块破坏和范围伤害
 */
public class Bomb extends entity {
    public int damage;                 // 爆炸伤害
    public int explosionRadius;        // 爆炸半径（以图块为单位）
    public int fuseTime;              // 引信时间（帧数）
    private int currentFuseTime;       // 当前引信时间
    private boolean exploded;          // 是否已爆炸
    private GamePanel gamePanel;       // 游戏面板引用
    private List<Point> destroyedBlocks; // 被破坏的方块坐标列表
    private BufferedImage bombImage;
    
    // 投掷动画属性
    public double velocityX;
    public double velocityY;
    private double gravity;
    private boolean isFlying;
    private ArrayList<Point> trail;
    private int maxTrailLength;
    
    // 网络同步属性
    public String bombId;              // 炸弹唯一标识符
    private boolean isRemoteBomb;      // 是否为远程玩家的炸弹
    
    // 物理效果属性
    private double friction;        // 摩擦系数
    private double bounciness;      // 反弹系数
    private boolean onGround;       // 是否在地面上
    private double rotationAngle;   // 旋转角度
    private double angularVelocity; // 角速度
    
    /**
     * 构造函数
     */
    public Bomb(int worldX, int worldY, int damage, int explosionRadius, int fuseTime, GamePanel gp) {
        this.worldx = worldX;
        this.worldy = worldY;
        this.damage = damage;
        this.explosionRadius = explosionRadius;
        this.fuseTime = fuseTime;
        this.currentFuseTime = fuseTime;
        this.exploded = false;
        this.isRemoteBomb = false;
        this.bombId = "local_" + System.currentTimeMillis() + "_" + Math.random();
        this.gamePanel = gp;
        this.destroyedBlocks = new ArrayList<>();
        
        // 设置碰撞箱
        solidarea = new Rectangle(0, 0, 16, 16);
        
        // 初始化投掷动画属性
        this.velocityX = 0;
        this.velocityY = 0;
        this.gravity = 0.15;
        this.isFlying = false;
        this.trail = new ArrayList<>();
        this.maxTrailLength = 10;
        
        // 初始化物理效果属性
        this.friction = 0.95;       // 摩擦系数
        this.bounciness = 0.6;      // 反弹系数
        this.onGround = false;
        this.rotationAngle = 0;
        this.angularVelocity = 0;
        
        // 创建炸弹图像
        createBombImage();
    }
    
    /**
     * 创建炸弹图像
     */
    private void createBombImage() {
        bombImage = new BufferedImage(gamePanel.tileSize, gamePanel.tileSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bombImage.createGraphics();
        
        // 绘制炸弹主体
        g2.setColor(Color.BLACK);
        int bombSize = gamePanel.tileSize - 8;
        g2.fillOval(4, 4, bombSize, bombSize);
        
        // 绘制引信
        g2.setColor(new Color(139, 69, 19));
        g2.setStroke(new BasicStroke(3));
        g2.drawLine(gamePanel.tileSize/2, 4, gamePanel.tileSize/2, 0);
        
        // 绘制火花（闪烁效果）
        if (currentFuseTime % 10 < 5) {
            g2.setColor(Color.RED);
            g2.fillOval(gamePanel.tileSize/2 - 2, -2, 4, 4);
        }
        
        g2.dispose();
    }
    
    /**
     * 网络同步构造函数
     */
    public Bomb(double worldX, double worldY, double velocityX, double velocityY, 
               int damage, int explosionRadius, int fuseTime, GamePanel gp) {
        this.worldx = (int)worldX;
        this.worldy = (int)worldY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.damage = damage;
        this.explosionRadius = explosionRadius;
        this.fuseTime = fuseTime;
        this.currentFuseTime = fuseTime;
        this.exploded = false;
        this.gamePanel = gp;
        this.destroyedBlocks = new ArrayList<>();
        this.isFlying = true;
        
        // 设置碰撞箱
        solidarea = new Rectangle(0, 0, 16, 16);
        
        // 初始化投掷动画属性
        this.gravity = 0.15;
        this.trail = new ArrayList<>();
        this.maxTrailLength = 10;
        
        // 初始化物理效果属性
        this.friction = 0.95;       // 摩擦系数
        this.bounciness = 0.6;      // 反弹系数
        this.onGround = false;
        this.rotationAngle = 0;
        this.angularVelocity = 0;
        
        // 创建炸弹图像
        createBombImage();
    }
    
    /**
     * 设置投掷速度
     */
    public void setVelocity(double vx, double vy) {
        this.velocityX = vx;
        this.velocityY = vy;
        this.isFlying = true;
    }
    
    /**
     * 设置是否为远程炸弹
     */
    public void setRemoteBomb(boolean isRemote) {
        this.isRemoteBomb = isRemote;
    }
    
    /**
     * 获取是否为远程炸弹
     */
    public boolean isRemoteBomb() {
        return this.isRemoteBomb;
    }
    
    /**
     * 更新炸弹状态
     */
    public void update() {
        if (!exploded) {
            // 更新投掷动画
            if (isFlying) {
                updateThrowAnimation();
            }
            
            currentFuseTime--;
            
            // 更新图像（闪烁效果）
            createBombImage();
            
            // 检查是否应该爆炸
            if (currentFuseTime <= 0) {
                explode();
            }
        }
    }
    
    /**
     * 更新投掷动画
     */
    private void updateThrowAnimation() {
        // 保存当前位置到轨迹
        trail.add(new Point(worldx, worldy));
        if (trail.size() > maxTrailLength) {
            trail.remove(0);
        }
        
        // 应用重力
        if (!onGround) {
            velocityY += gravity;
        }
        
        // 保存旧位置用于碰撞检测
        int oldX = worldx;
        int oldY = worldy;
        
        // 更新位置
        worldx += (int)velocityX;
        worldy += (int)velocityY;
        
        // 地面碰撞检测
        checkGroundCollision(oldY);
        
        // 方块碰撞检测
        checkBlockCollision(oldX, oldY);
        
        // 更新旋转角度
        if (Math.abs(velocityX) > 0.1 || Math.abs(velocityY) > 0.1) {
            angularVelocity = velocityX * 0.1; // 根据水平速度计算角速度
            rotationAngle += angularVelocity;
        }
        
        // 应用摩擦力
        if (onGround) {
            velocityX *= friction;
            angularVelocity *= friction;
            
            // 如果速度很小，停止运动
            if (Math.abs(velocityX) < 0.1 && Math.abs(velocityY) < 0.1) {
                isFlying = false;
                velocityX = 0;
                velocityY = 0;
                angularVelocity = 0;
            }
        }
    }
    
    /**
     * 检查地面碰撞
     */
    private void checkGroundCollision(int oldY) {
        int groundLevel = getGroundLevel(worldx);
        
        // 只有当找到有效地面且炸弹向下移动时才进行碰撞检测
        if (groundLevel < gamePanel.maxworldrow * gamePanel.tileSize && 
            worldy + gamePanel.tileSize >= groundLevel && velocityY > 0) {
            // 碰撞到地面
            worldy = groundLevel - gamePanel.tileSize;
            
            if (!onGround) {
                // 第一次着地，应用反弹
                velocityY = -velocityY * bounciness;
                
                // 如果反弹速度很小，停在地面上
                if (Math.abs(velocityY) < 2) {
                    velocityY = 0;
                    onGround = true;
                }
            } else {
                velocityY = 0;
            }
        } else if (groundLevel < gamePanel.maxworldrow * gamePanel.tileSize && 
                   worldy + gamePanel.tileSize < groundLevel) {
            onGround = false;
        }
    }
    
    /**
     * 检查方块碰撞
     */
    private void checkBlockCollision(int oldX, int oldY) {
        // 获取炸弹当前所在的瓦片坐标
        int tileX = worldx / gamePanel.tileSize;
        int tileY = worldy / gamePanel.tileSize;
        
        // 检查周围的瓦片
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int checkX = tileX + dx;
                int checkY = tileY + dy;
                
                if (checkX >= 0 && checkX < gamePanel.maxworldcol && 
                    checkY >= 0 && checkY < gamePanel.maxworldrow) {
                    
                    int tileNum = gamePanel.tilemanager.mapnum[checkX][checkY];
                    
                    // 如果是固体方块（1表示墙壁）
                    if (tileNum == 1) {
                        Rectangle tileRect = new Rectangle(
                            checkX * gamePanel.tileSize,
                            checkY * gamePanel.tileSize,
                            gamePanel.tileSize,
                            gamePanel.tileSize
                        );
                        
                        Rectangle bombRect = new Rectangle(
                            worldx,
                            worldy,
                            gamePanel.tileSize,
                            gamePanel.tileSize
                        );
                        
                        if (tileRect.intersects(bombRect)) {
                            // 发生碰撞，计算反弹方向
                            handleBlockCollision(tileRect, oldX, oldY);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * 处理方块碰撞
     */
    private void handleBlockCollision(Rectangle tileRect, int oldX, int oldY) {
        // 恢复到碰撞前的位置
        worldx = oldX;
        worldy = oldY;
        
        // 计算碰撞面
        int bombCenterX = worldx + gamePanel.tileSize / 2;
        int bombCenterY = worldy + gamePanel.tileSize / 2;
        int tileCenterX = tileRect.x + gamePanel.tileSize / 2;
        int tileCenterY = tileRect.y + gamePanel.tileSize / 2;
        
        int deltaX = bombCenterX - tileCenterX;
        int deltaY = bombCenterY - tileCenterY;
        
        // 判断主要碰撞方向
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // 水平碰撞
            velocityX = -velocityX * bounciness;
        } else {
            // 垂直碰撞
            velocityY = -velocityY * bounciness;
        }
    }
    
    /**
     * 获取指定X坐标的地面高度
     */
    private int getGroundLevel(int x) {
        int tileX = x / gamePanel.tileSize;
        int currentTileY = worldy / gamePanel.tileSize;
        
        // 从炸弹当前位置向下搜索第一个固体方块
        for (int y = currentTileY; y < gamePanel.maxworldrow; y++) {
            if (tileX >= 0 && tileX < gamePanel.maxworldcol) {
                int tileNum = gamePanel.tilemanager.mapnum[tileX][y];
                if (tileNum == 1) {
                    return y * gamePanel.tileSize;
                }
            }
        }
        
        // 如果没有找到固体方块，返回世界底部
        return gamePanel.maxworldrow * gamePanel.tileSize;
    }
    
    /**
     * 爆炸逻辑
     */
    private void explode() {
        exploded = true;
        
        // 计算爆炸中心的图块坐标
        int centerCol = worldx / gamePanel.tileSize;
        int centerRow = worldy / gamePanel.tileSize;
        
        System.out.println("Bomb exploded at tile (" + centerCol + ", " + centerRow + ")!");
        
        // 破坏范围内的方块
        destroyBlocksInRadius(centerCol, centerRow);
        
        // 对范围内的实体造成伤害
        damageEntitiesInRadius();
        
        // 创建爆炸效果（可选）
        createExplosionEffect();
    }
    
    /**
     * 破坏爆炸半径内的方块
     */
    private void destroyBlocksInRadius(int centerCol, int centerRow) {
        boolean mapChanged = false; // 标记地图是否发生变化
        
        for (int col = centerCol - explosionRadius; col <= centerCol + explosionRadius; col++) {
            for (int row = centerRow - explosionRadius; row <= centerRow + explosionRadius; row++) {
                // 检查是否在地图范围内
                if (col >= 0 && col < gamePanel.maxworldcol && row >= 0 && row < gamePanel.maxworldrow) {
                    // 计算距离
                    double distance = Math.sqrt(Math.pow(col - centerCol, 2) + Math.pow(row - centerRow, 2));
                    
                    // 如果在爆炸半径内
                    if (distance <= explosionRadius) {
                        // 使用TileManager的方法破坏方块
                        if (gamePanel.tilemanager.mapnum[col][row] == 1) {
                            int tileIndex = gamePanel.tilemanager.mapnum[col][row];
                            gamePanel.tilemanager.mapnum[col][row] = 0; // 将墙壁变为空气
                            
                            // 记录被破坏的方块
                            destroyedBlocks.add(new Point(col, row));
                            
                            // 将方块添加到玩家物品栏
                            addBlockToInventory(tileIndex);
                            
                            System.out.println("Destroyed block at (" + col + ", " + row + ") - Type: " + tileIndex);
                            
                            mapChanged = true; // 标记地图已变化
                        }
                    }
                }
            }
        }
        
        // 如果地图发生变化且在多人游戏模式下，发送地图同步消息
        if (mapChanged && gamePanel.isMultiplayer && gamePanel.networkClient != null && gamePanel.networkClient.isConnected()) {
            gamePanel.networkClient.sendMapSync(
                gamePanel.tilemanager.mapnum,
                gamePanel.maxworldcol,
                gamePanel.maxworldrow
            );
            System.out.println("已发送地图同步消息（炸弹爆炸后）");
        }
    }
    
    /**
     * 将破坏的方块添加到玩家物品栏
     */
    private void addBlockToInventory(int tileIndex) {
        if (gamePanel.inventory != null) {
            // 根据方块类型创建对应的物品
            String blockName = getBlockName(tileIndex);
            BlockItem blockItem = new BlockItem(blockName, tileIndex);
            
            // 尝试添加到物品栏
            gamePanel.inventory.addItem(blockItem, 1);
        }
    }
    
    /**
     * 根据方块索引获取方块名称
     */
    private String getBlockName(int tileIndex) {
        switch (tileIndex) {
            case 1: return "石头";
            case 2: return "泥土";
            case 3: return "草地";
            default: return "未知方块";
        }
    }
    
    /**
     * 对爆炸范围内的实体造成伤害
     */
    private void damageEntitiesInRadius() {
        // 对玩家造成伤害
        if (gamePanel.player != null) {
            double playerDistance = getDistanceToPlayer();
            if (playerDistance <= explosionRadius * gamePanel.tileSize) {
                int actualDamage = calculateDamageByDistance(playerDistance);
                gamePanel.player.takeDamage(actualDamage);
                System.out.println("Player takes " + actualDamage + " explosion damage!");
            }
        }
        
        // 对敌人造成伤害
        if (gamePanel.enemies != null) {
            for (enemy e : gamePanel.enemies) {
                double enemyDistance = getDistanceToEnemy(e);
                if (enemyDistance <= explosionRadius * gamePanel.tileSize) {
                    int actualDamage = calculateDamageByDistance(enemyDistance);
                    e.takeDamage(actualDamage);
                    System.out.println("Enemy takes " + actualDamage + " explosion damage!");
                }
            }
        }
    }
    
    /**
     * 计算到玩家的距离
     */
    private double getDistanceToPlayer() {
        return Math.sqrt(Math.pow(worldx - gamePanel.player.worldx, 2) + 
                        Math.pow(worldy - gamePanel.player.worldy, 2));
    }
    
    /**
     * 计算到敌人的距离
     */
    private double getDistanceToEnemy(enemy e) {
        return Math.sqrt(Math.pow(worldx - e.worldx, 2) + 
                        Math.pow(worldy - e.worldy, 2));
    }
    
    /**
     * 根据距离计算伤害
     */
    private int calculateDamageByDistance(double distance) {
        double maxDistance = explosionRadius * gamePanel.tileSize;
        double damageRatio = 1.0 - (distance / maxDistance);
        return (int)(damage * Math.max(0.1, damageRatio)); // 最少造成10%伤害
    }
    
    /**
     * 创建爆炸效果
     */
    private void createExplosionEffect() {
        // 这里可以添加爆炸粒子效果或动画
        // 目前只是简单的控制台输出
        System.out.println("BOOM! Explosion effect at (" + worldx + ", " + worldy + ")");
    }
    
    /**
     * 检查炸弹是否应该被移除
     */
    public boolean shouldRemove() {
        return exploded && fuseTime <= -60; // 爆炸后60帧移除
    }
    
    /**
     * 绘制炸弹
     */
    public void draw(Graphics2D g2) {
        if (!exploded && bombImage != null) {
            // 计算屏幕坐标
            int screenX = worldx - gamePanel.player.worldx + gamePanel.player.screenx;
            int screenY = worldy - gamePanel.player.worldy + gamePanel.player.screeny;
            
            // 绘制轨迹（如果正在飞行）
            if (isFlying) {
                drawTrail(g2);
            }
            
            // 只在屏幕范围内绘制
            if (screenX + gamePanel.tileSize > 0 && screenX < gamePanel.screenWidth &&
                screenY + gamePanel.tileSize > 0 && screenY < gamePanel.screenHeight) {
                
                // 保存原始变换
                AffineTransform originalTransform = g2.getTransform();
                
                // 如果炸弹在运动，应用旋转
                if (Math.abs(angularVelocity) > 0.01) {
                    int centerX = screenX + gamePanel.tileSize / 2;
                    int centerY = screenY + gamePanel.tileSize / 2;
                    g2.rotate(rotationAngle, centerX, centerY);
                }
                
                // 绘制炸弹图像
                g2.drawImage(bombImage, screenX, screenY, null);
                
                // 恢复变换
                g2.setTransform(originalTransform);
                
                // 绘制倒计时数字（不旋转）
                drawCountdown(g2, screenX, screenY);
            }
        }
    }
    
    /**
     * 绘制投掷轨迹
     */
    private void drawTrail(Graphics2D g2) {
        if (trail.size() < 2) return;
        
        // 保存原始设置
        Stroke originalStroke = g2.getStroke();
        Color originalColor = g2.getColor();
        
        // 绘制轨迹点
        for (int i = 0; i < trail.size(); i++) {
            Point trailPoint = trail.get(i);
            
            // 计算屏幕坐标
            int screenX = trailPoint.x - gamePanel.player.worldx + gamePanel.player.screenx;
            int screenY = trailPoint.y - gamePanel.player.worldy + gamePanel.player.screeny;
            
            // 计算透明度（越新的点越不透明）
            float alpha = (float)i / trail.size() * 0.8f;
            
            // 设置颜色和透明度
            g2.setColor(new Color(1.0f, 0.5f, 0.0f, alpha)); // 橙色轨迹
            
            // 绘制轨迹点
            int size = Math.max(1, i / 2); // 轨迹点大小随位置变化
            g2.fillOval(screenX - size/2, screenY - size/2, size, size);
        }
        
        // 恢复原始设置
        g2.setStroke(originalStroke);
        g2.setColor(originalColor);
    }
    
    /**
     * 绘制倒计时数字
     */
    private void drawCountdown(Graphics2D g2, int screenX, int screenY) {
        // 计算剩余秒数（60帧 = 1秒）
        int remainingSeconds = (int)Math.ceil(currentFuseTime / 60.0);
        
        if (remainingSeconds > 0) {
            // 设置字体和颜色
            Font originalFont = g2.getFont();
            Font countdownFont = new Font("Arial", Font.BOLD, 24);
            g2.setFont(countdownFont);
            
            // 根据剩余时间改变颜色
            Color textColor;
            if (remainingSeconds <= 1) {
                textColor = Color.RED;  // 最后1秒红色
            } else if (remainingSeconds <= 2) {
                textColor = Color.ORANGE;  // 倒数第2秒橙色
            } else {
                textColor = Color.YELLOW;  // 其他时间黄色
            }
            
            // 添加闪烁效果（最后1秒）
            if (remainingSeconds <= 1 && currentFuseTime % 10 < 5) {
                textColor = Color.WHITE;
            }
            
            String countdownText = String.valueOf(remainingSeconds);
            FontMetrics fm = g2.getFontMetrics();
            int textWidth = fm.stringWidth(countdownText);
            int textHeight = fm.getHeight();
            
            // 计算文字位置（炸弹上方居中）
            int textX = screenX + (gamePanel.tileSize - textWidth) / 2;
            int textY = screenY - 10;
            
            // 绘制文字阴影
            g2.setColor(Color.BLACK);
            g2.drawString(countdownText, textX + 2, textY + 2);
            
            // 绘制文字
            g2.setColor(textColor);
            g2.drawString(countdownText, textX, textY);
            
            // 恢复原始字体
            g2.setFont(originalFont);
        }
    }
    
    // Getters
    public boolean isExploded() { return exploded; }
    public List<Point> getDestroyedBlocks() { return destroyedBlocks; }
    public int getCurrentFuseTime() { return currentFuseTime; }
}