package entity;

import main.GamePanel;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

/**
 * 箭矢实体类
 * 处理箭矢的飞行、碰撞和渲染
 */
public class Arrow {
    // 位置和运动
    public double worldX, worldY;       // 世界坐标
    public double velocityX, velocityY; // 速度向量
    public double angle;                // 箭矢角度
    public double gravity = 0.02;       // 重力加速度（减少下坠）
    public double initialVelocityY;     // 初始Y轴速度（用于计算角度）
    
    // 属性
    public int damage;                  // 伤害值
    public int maxRange;                // 最大射程
    public double traveledDistance;     // 已飞行距离
    public boolean active;              // 是否活跃
    
    // 碰撞检测
    public Rectangle hitbox;            // 碰撞箱
    public int width = 24;              // 箭矢宽度
    public int height = 4;              // 箭矢高度
    
    // 游戏引用
    private GamePanel gp;
    
    // 轨迹效果
    private ArrayList<Point> trail;     // 轨迹点
    private int maxTrailLength = 8;     // 最大轨迹长度
    
    /**
     * 构造函数
     */
    public Arrow(double startX, double startY, double velX, double velY, 
                 int damage, int range, GamePanel gamePanel) {
        this.worldX = startX;
        this.worldY = startY;
        this.velocityX = velX;
        this.velocityY = velY;
        this.initialVelocityY = velY; // 保存初始Y轴速度
        this.damage = damage;
        this.maxRange = range;
        this.gp = gamePanel;
        
        this.traveledDistance = 0;
        this.active = true;
        
        // 计算箭矢角度
        this.angle = Math.atan2(velocityY, velocityX);
        
        // 初始化碰撞箱
        this.hitbox = new Rectangle((int)worldX - width/2, (int)worldY - height/2, width, height);
        
        // 初始化轨迹
        this.trail = new ArrayList<>();
    }
    
    /**
     * 更新箭矢状态
     */
    public void update() {
        if (!active) return;
        
        // 保存当前位置到轨迹
        trail.add(new Point((int)worldX, (int)worldY));
        if (trail.size() > maxTrailLength) {
            trail.remove(0);
        }
        
        // 应用重力效果
        velocityY += gravity;
        
        // 更新箭矢角度以反映当前飞行方向
        angle = Math.atan2(velocityY, velocityX);
        
        // 更新位置
        worldX += velocityX;
        worldY += velocityY;
        
        // 更新已飞行距离
        double frameDistance = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        traveledDistance += frameDistance;
        
        // 更新碰撞箱位置
        hitbox.x = (int)worldX - width/2;
        hitbox.y = (int)worldY - height/2;
        
        // 检查是否超出射程
        if (traveledDistance >= maxRange) {
            active = false;
            return;
        }
        
        // 检查地图边界碰撞
        if (checkMapCollision()) {
            active = false;
            return;
        }
        
        // 检查与敌人的碰撞
        checkEnemyCollision();
    }
    
    /**
     * 检查地图碰撞
     */
    private boolean checkMapCollision() {
        // 使用AABB碰撞系统检查地图碰撞
        if (gp.aabbCollisionSystem != null) {
            // 创建临时实体用于碰撞检测
            entity tempEntity = new entity() {
                {
                    worldx = (int)worldX;
                    worldy = (int)worldY;
                    solidarea = new Rectangle(-width/2, -height/2, width, height);
                }
            };
            
            // 检查水平碰撞
            if (gp.aabbCollisionSystem.checkTileCollision(tempEntity, (float)velocityX, 0).hasCollision) {
                return true;
            }
            
            // 检查垂直碰撞
            if (gp.aabbCollisionSystem.checkTileCollision(tempEntity, 0, (float)velocityY).hasCollision) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查与敌人的碰撞
     */
    private void checkEnemyCollision() {
        for (int i = 0; i < gp.enemies.size(); i++) {
            enemy currentEnemy = gp.enemies.get(i);
            
            // 创建敌人的碰撞区域
            Rectangle enemyHitbox = new Rectangle(
                currentEnemy.worldx + currentEnemy.solidarea.x,
                currentEnemy.worldy + currentEnemy.solidarea.y,
                currentEnemy.solidarea.width,
                currentEnemy.solidarea.height
            );
            
            // 检查碰撞
            if (hitbox.intersects(enemyHitbox)) {
                // 对敌人造成伤害
                currentEnemy.takeDamage(damage);
                System.out.println("Arrow hits enemy for " + damage + " ranged damage!");
                
                // 箭矢失效
                active = false;
                return;
            }
        }
    }
    
    /**
     * 绘制箭矢
     */
    public void draw(Graphics2D g2, player player) {
        if (!active) return;
        
        // 计算屏幕坐标
        int screenX = (int)worldX - player.worldx + player.screenx;
        int screenY = (int)worldY - player.worldy + player.screeny;
        
        // 只在屏幕范围内绘制
        if (screenX > -50 && screenX < gp.screenWidth + 50 && 
            screenY > -50 && screenY < gp.screenHeight + 50) {
            
            // 绘制轨迹
            drawTrail(g2, player);
            
            // 保存原始变换
            AffineTransform originalTransform = g2.getTransform();
            
            // 旋转箭矢
            g2.rotate(angle, screenX, screenY);
            
            // 绘制箭矢主体
            g2.setColor(new Color(139, 69, 19)); // 棕色箭杆
            g2.fillRect(screenX - width/2, screenY - 1, width - 6, 2);
            
            // 绘制箭头
            g2.setColor(Color.GRAY);
            int[] arrowHeadX = {screenX + width/2 - 6, screenX + width/2, screenX + width/2 - 6};
            int[] arrowHeadY = {screenY - 2, screenY, screenY + 2};
            g2.fillPolygon(arrowHeadX, arrowHeadY, 3);
            
            // 绘制箭羽
            g2.setColor(new Color(255, 255, 255, 150));
            int[] featherX = {screenX - width/2, screenX - width/2 + 4, screenX - width/2};
            int[] featherY1 = {screenY - 2, screenY, screenY - 1};
            int[] featherY2 = {screenY + 2, screenY, screenY + 1};
            g2.fillPolygon(featherX, featherY1, 3);
            g2.fillPolygon(featherX, featherY2, 3);
            
            // 恢复变换
            g2.setTransform(originalTransform);
        }
    }
    
    /**
     * 绘制箭矢轨迹
     */
    private void drawTrail(Graphics2D g2, player player) {
        if (trail.size() < 2) return;
        
        g2.setColor(new Color(255, 255, 0, 100)); // 半透明黄色
        
        for (int i = 1; i < trail.size(); i++) {
            Point prev = trail.get(i - 1);
            Point curr = trail.get(i);
            
            int prevScreenX = prev.x - player.worldx + player.screenx;
            int prevScreenY = prev.y - player.worldy + player.screeny;
            int currScreenX = curr.x - player.worldx + player.screenx;
            int currScreenY = curr.y - player.worldy + player.screeny;
            
            // 根据轨迹位置调整透明度
            float alpha = (float)i / trail.size() * 0.5f;
            g2.setColor(new Color(1f, 1f, 0f, alpha));
            
            g2.drawLine(prevScreenX, prevScreenY, currScreenX, currScreenY);
        }
    }
    
    /**
     * 检查箭矢是否应该被移除
     */
    public boolean shouldRemove() {
        return !active;
    }
    
    // Getters
    public boolean isActive() { return active; }
    public double getWorldX() { return worldX; }
    public double getWorldY() { return worldY; }
    public int getDamage() { return damage; }
}