package entity;

import main.AABB;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.sql.Ref;

/**
 * 实体基类
 * 定义了游戏中所有可移动实体的基本属性和行为
 * 包括位置、速度、动画图像、方向、碰撞检测等核心属性
 * 支持AABB碰撞检测系统
 */
public class entity {
    public int worldx,worldy;
    public int speed;
    public BufferedImage left,leftz,right,rightz,up,upz,down,downz,stop,stopz;
    public String direction;
    public int spriteCounter = 0;
    public int spriteNum =1;
    public Rectangle solidarea;
    public  boolean collisionon =false;
    
    // AABB碰撞检测相关属性
    public AABB boundingBox;                   // AABB包围盒
    public boolean useAABBCollision = true;    // 是否使用AABB碰撞检测
    public float aabbOffsetX = 0;              // AABB相对于实体位置的X偏移
    public float aabbOffsetY = 0;              // AABB相对于实体位置的Y偏移
    
    // 横版跳跃系统 - 优化的物理参数
    public double velocityY = 0;           // 垂直速度
    public double gravity = 0.2;           // 重力加速度（增强重力感）
    public double jumpStrength = -10;      // 跳跃初始速度（增强跳跃力，能跳到更高点）
    public double maxFallSpeed = 6  ;       // 最大下落速度（防止无限加速）
    public boolean onGround = false;       // 地面状态
    public boolean isJumping = false;      // 跳跃状态
    public boolean canJump = true;         // 跳跃冷却（防止连跳）
    public int jumpCooldown = 0;           // 跳跃冷却计时器
    
    // 跳跃手感优化参数
    public double jumpBufferTime = 5;      // 跳跃缓冲时间（帧数）
    public double coyoteTime = 8;          // 土狼时间（离开平台后仍可跳跃的时间）
    public int jumpBuffer = 0;             // 跳跃缓冲计时器
    public int coyoteTimer = 0;            // 土狼时间计时器
    
    /**
     * 初始化AABB包围盒
     * 基于solidarea创建AABB包围盒
     */
    public void initializeAABB() {
        if (solidarea != null) {
            aabbOffsetX = solidarea.x;
            aabbOffsetY = solidarea.y;
            boundingBox = new AABB(
                worldx + aabbOffsetX,
                worldy + aabbOffsetY,
                solidarea.width,
                solidarea.height
            );
        }
    }
    
    /**
     * 更新AABB包围盒位置
     * 当实体位置改变时调用
     */
    public void updateAABB() {
        if (boundingBox != null) {
            boundingBox.setPosition(worldx + aabbOffsetX, worldy + aabbOffsetY);
        }
    }
    
    /**
     * 获取当前的AABB包围盒
     * @return 当前的AABB包围盒
     */
    public AABB getAABB() {
        if (boundingBox == null) {
            initializeAABB();
        } else {
            updateAABB();
        }
        return boundingBox;
    }
    
    /**
     * 设置AABB包围盒大小
     * @param width 宽度
     * @param height 高度
     */
    public void setAABBSize(float width, float height) {
        if (boundingBox != null) {
            boundingBox.setSize(width, height);
        }
    }
    
    /**
     * 设置AABB偏移量
     * @param offsetX X偏移
     * @param offsetY Y偏移
     */
    public void setAABBOffset(float offsetX, float offsetY) {
        this.aabbOffsetX = offsetX;
        this.aabbOffsetY = offsetY;
        updateAABB();
    }
    
    /**
     * 检查是否使用AABB碰撞检测
     * @return 是否使用AABB碰撞检测
     */
    public boolean isUsingAABBCollision() {
        return useAABBCollision;
    }
    
    /**
     * 设置是否使用AABB碰撞检测
     * @param useAABB 是否使用AABB碰撞检测
     */
    public void setUseAABBCollision(boolean useAABB) {
        this.useAABBCollision = useAABB;
    }
}
