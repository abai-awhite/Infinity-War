package entity;

import main.GamePanel;
import main.KeyBoard;
import main.KeySettings;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Composite;

public class player extends entity{
    GamePanel gp;
    public KeyBoard KB;
    private KeySettings keySettings;

    public  final  int screenx;
    public  final  int screeny;
    
    // 移动状态枚举
    public enum MovementState {
        WALKING(4),    // 普通走路速度
        RUNNING(6),    // 跑步速度
        SPRINTING(9);  // 冲刺速度
        
        private final int speed;
        
        MovementState(int speed) {
            this.speed = speed;
        }
        
        public int getSpeed() {
            return speed;
        }
    }
    
    // 移动状态相关变量
    public MovementState currentMovementState = MovementState.WALKING;
    public int baseSpeed = 4;              // 基础移动速度
    public int stamina = 100;              // 当前耐力值
    public int maxStamina = 100;           // 最大耐力值
    public int staminaRegenRate = 1;       // 耐力恢复速度（每帧）
    public int sprintStaminaCost = 2;      // 冲刺耐力消耗（每帧）
    public boolean canSprint = true;       // 是否可以冲刺
    public int staminaRegenDelay = 0;      // 耐力恢复延迟计时器
    public int maxStaminaRegenDelay = 60;  // 停止冲刺后的耐力恢复延迟（1秒）

        // 图像字段声明
    public BufferedImage right, rightz, left, leftz;
    public BufferedImage up, upz, down, downz;
    public BufferedImage jump, jumpz;
    
    // 剑攻击相关图像
    public BufferedImage swordImage;
    public BufferedImage swordImageRight; // 右侧攻击剑图片
    
    // 战斗系统相关属性
    public int health = 100;                // 当前生命值
    public int maxHealth = 100;             // 最大生命值
    public int attackDamage = 30;           // 攻击伤害
    public int attackRange = 300;            // 攻击范围（像素）
    public int attackCooldown = 0;          // 攻击冷却计时器
    public int maxAttackCooldown = 60;      // 最大攻击冷却（帧数）- 减慢攻击速度
    
    // 蓄力攻击相关
    public int maxChargeTime = 480;         // 最大蓄力时间（2秒，60fps）
    public float chargeMultiplier = 1.0f;   // 蓄力伤害倍数
    public boolean isCharging = false;      // 是否正在蓄力
    public boolean isAttacking = false;     // 是否正在攻击
    public int attackAnimationTimer = 0;    // 攻击动画计时器
    public int maxAttackAnimationTime = 60; // 攻击动画持续时间（增加到30帧让动画更慢）
    
    // 剑相关变量
    public double swordAngle = 0;           // 剑的角度
    public int swordOffsetX = 0;            // 剑相对于玩家的X偏移
    public int swordOffsetY = 0;            // 剑相对于玩家的Y偏移
    public int swordSize = 48;              // 剑的显示大小
    public ArrayList<enemy> hitEnemiesThisAttack = new ArrayList<>(); // 本次攻击已命中的敌人列表
    
    // 无敌时间（受伤后的短暂无敌）
    public int invulnerabilityTimer = 0;
    public int maxInvulnerabilityTime = 120; // 无敌时间（帧数）- 增加到2秒
    
    // 网络同步相关属性
    public double velocityx = 0;            // X轴速度
    public double velocityy = 0;            // Y轴速度
    public boolean isMoving = false;        // 是否正在移动
    public boolean isJumping = false;       // 是否正在跳跃
    public boolean isFalling = false;       // 是否正在下落
    public boolean attackJustStarted = false; // 攻击刚开始标志
    public boolean blockJustPlaced = false;   // 方块刚放置标志
    public boolean isChargedAttack = false;   // 是否为蓄力攻击

    public player(GamePanel gp,KeyBoard KB){
        this.gp=gp;
        this.KB=KB;
        this.keySettings = KeySettings.getInstance();

        screenx = gp.screenWidth/2-(gp.tileSize/2);
        screeny = gp.screenHeight/2-(gp.tileSize/2);

        solidarea = new Rectangle(5,5,54,54);
        
        // 初始化AABB碰撞检测
        setUseAABBCollision(true);
        setAABBSize(54, 54);
        setAABBOffset(5, 5);

        setPlayer();
        getplayerpicture();
    }
    public void setPlayer(){

        worldx = gp.tileSize * 15;
        worldy = gp.tileSize * 15;
        speed = currentMovementState.getSpeed();
        direction = "down";
        
        // 初始化AABB边界框
        initializeAABB();
    }
    public void getplayerpicture(){
        try {
            right = ImageIO.read(getClass().getResourceAsStream("/res/player/player_right.png"));
            rightz = ImageIO.read(getClass().getResourceAsStream("/res/player/player_right_1.png"));
            left = ImageIO.read(getClass().getResourceAsStream("/res/player/player_left.png"));
            leftz = ImageIO.read(getClass().getResourceAsStream("/res/player/player_left_1.png"));
            up = ImageIO.read(getClass().getResourceAsStream("/res/player/player_up.png"));
            upz = ImageIO.read(getClass().getResourceAsStream("/res/player/player_up_1.png"));
            down = ImageIO.read(getClass().getResourceAsStream("/res/player/player_down.png"));
            downz = ImageIO.read(getClass().getResourceAsStream("/res/player/player_down_1.png"));
            stop = ImageIO.read(getClass().getResourceAsStream("/res/player/player_stop.png"));
            stopz = ImageIO.read(getClass().getResourceAsStream("/res/player/player_stop_1.png"));
            
            // 加载剑图片
            swordImage = ImageIO.read(getClass().getResourceAsStream("/res/player/jian.png"));
            swordImageRight = ImageIO.read(getClass().getResourceAsStream("/res/player/jian_r.png"));
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    public void updata() {
        // 保存上一帧的位置用于计算速度
        int oldWorldX = worldx;
        int oldWorldY = worldy;
        
        // 处理移动状态和耐力系统
        handleMovementState();
        
        // 更新蓄力时间
        KB.updateChargeTime();
        
        // 更新战斗系统计时器
        updateCombatTimers();
        
        // 处理攻击输入
        handleAttackInput();
        
        // 处理方块放置输入
        handleBlockPlacement();
        
        // 横向移动处理
        handleHorizontalMovement();
        
        // 跳跃系统处理
        handleJumpSystem();
        
        // 重力和垂直移动处理
        handleGravityAndVerticalMovement();
        
        // 检测与敌人的碰撞
        checkEnemyCollisions();
        
        // 动画更新
        updateAnimation();
        
        // 更新网络同步属性
        updateNetworkSyncProperties(oldWorldX, oldWorldY);
    }
    
    /**
     * 更新网络同步属性
     */
    private void updateNetworkSyncProperties(int oldWorldX, int oldWorldY) {
        // 计算速度
        velocityx = worldx - oldWorldX;
        velocityy = worldy - oldWorldY;
        
        // 更新移动状态
        isMoving = (velocityx != 0 || velocityy != 0);
        
        // 更新跳跃和下落状态
        isFalling = velocityY > 0 && !onGround;
        // isJumping在跳跃系统中已经设置
        
        // 重置攻击和方块放置标志（这些标志会在相应的处理方法中设置）
        // attackJustStarted和blockJustPlaced会在对应的处理方法中设置为true
        // 在网络同步后需要重置为false
    }
    
    /**
     * 处理横向移动
     */
    private void handleHorizontalMovement() {
        double moveX = 0;
        
        // 计算横向移动
        if (KB.left) {
            moveX -= speed;
            direction = "left";
        }
        if (KB.right) {
            moveX += speed;
            direction = "right";
        }
        
        // 如果没有横向移动且在地面上，设置为停止状态
        if (moveX == 0 && onGround) {
            direction = "stop";
        }
        
        // 应用横向移动 - 使用分步移动防止穿墙
        if (moveX != 0) {
            moveHorizontallyWithCollision((int)moveX);
            // 水平移动后检测坠落
            checkFallAfterHorizontalMovement();
        }
    }
    
    /**
     * 分步横向移动，防止高速移动时穿墙
     * @param totalMovement 总移动距离
     */
    private void moveHorizontallyWithCollision(int totalMovement) {
        if (totalMovement == 0) return;
        
        // 计算移动方向和步长
        int direction = totalMovement > 0 ? 1 : -1;
        int remainingMovement = Math.abs(totalMovement);
        int maxStepSize = 1; // 最小步长1像素，确保绝对不穿墙
        
        while (remainingMovement > 0) {
            // 计算当前步长
            int currentStep = Math.min(remainingMovement, maxStepSize);
            int moveDistance = currentStep * direction;
            
            // 保存当前位置
            int oldWorldX = worldx;
            worldx += moveDistance;
            
            // 检查水平碰撞
            collisionon = false;
            gp.checker.checkHorizontalCollision(this, moveDistance);
            
            if (collisionon) {
                // 发生碰撞，恢复位置并停止移动
                worldx = oldWorldX;
                break; // 碰撞后停止移动
            } else {
                // 没有碰撞，继续移动
                remainingMovement -= currentStep;
            }
        }
    }
    
    /**
     * 水平移动后检测坠落
     * 检查玩家脚下是否有支撑，如果没有则开始坠落
     */
    private void checkFallAfterHorizontalMovement() {
        // 只有在地面上时才需要检测坠落
        if (!onGround) return;
        
        // 检测脚下一个像素位置是否有碰撞
        int oldWorldY = worldy;
        worldy += 1; // 向下移动1像素检测
        
        collisionon = false;
        gp.checker.checkVerticalCollision(this, 1);
        
        // 恢复位置
        worldy = oldWorldY;
        
        // 如果脚下没有碰撞，说明悬空了，开始坠落
        if (!collisionon) {
            onGround = false;
            coyoteTimer = (int)coyoteTime; // 开始土狼时间
        }
    }
    
    /**
     * 处理跳跃系统
     */
    private void handleJumpSystem() {
        // 更新跳跃缓冲和土狼时间
        if (jumpBuffer > 0) jumpBuffer--;
        if (coyoteTimer > 0) coyoteTimer--;
        if (jumpCooldown > 0) jumpCooldown--;
        
        // 检测跳跃输入
        if (isKeyPressed(KeySettings.JUMP) && jumpBuffer == 0) {
            jumpBuffer = (int)jumpBufferTime;
        }
        
        // 执行跳跃
        if (jumpBuffer > 0 && (onGround || coyoteTimer > 0) && jumpCooldown == 0) {
            velocityY = jumpStrength;
            isJumping = true;
            onGround = false;
            jumpBuffer = 0;
            jumpCooldown = 10; // 设置跳跃冷却
            coyoteTimer = 0;
        }
    }
    
    /**
     * 处理重力和垂直移动
     */
    private void handleGravityAndVerticalMovement() {
        // 应用重力
        if (!onGround) {
            velocityY += gravity;
            
            // 限制最大下落速度
            if (velocityY > maxFallSpeed) {
                velocityY = maxFallSpeed;
            }
        }
        
        // 应用垂直移动 - 使用分步移动防止穿墙
        if (velocityY != 0) {
            moveVerticallyWithCollision((int)velocityY);
        }
        
        // 地面检测（向下检测一个像素）
        if (velocityY >= 0 && !onGround) {
            int oldWorldY = worldy;
            worldy += 1; // 向下检测1像素
            
            collisionon = false;
            gp.checker.checktile(this);
            
            if (collisionon) {
                onGround = true;
                isJumping = false;
                velocityY = 0;
                coyoteTimer = (int)coyoteTime;
            }
            
            worldy = oldWorldY; // 恢复位置
        }
    }
    
    /**
     * 分步垂直移动，防止高速移动时穿墙
     * @param totalMovement 总移动距离
     */
    private void moveVerticallyWithCollision(int totalMovement) {
        if (totalMovement == 0) return;
        
        // 计算移动方向和步长
        int direction = totalMovement > 0 ? 1 : -1;
        int remainingMovement = Math.abs(totalMovement);
        int maxStepSize = 1; // 最小步长1像素，确保绝对不穿墙
        
        while (remainingMovement > 0) {
            // 计算当前步长
            int currentStep = Math.min(remainingMovement, maxStepSize);
            int moveDistance = currentStep * direction;
            
            // 保存当前位置
            int oldWorldY = worldy;
            worldy += moveDistance;
            
            // 检查垂直碰撞
            collisionon = false;
            gp.checker.checkVerticalCollision(this, moveDistance);
            
            if (collisionon) {
                // 发生碰撞，恢复位置并停止移动
                worldy = oldWorldY;
                
                if (velocityY > 0) {
                    // 向下碰撞，着陆
                    onGround = true;
                    isJumping = false;
                    coyoteTimer = (int)coyoteTime;
                } else {
                    // 向上碰撞，撞到天花板
                    // 可以添加撞头效果
                }
                velocityY = 0;
                break; // 碰撞后停止移动
            } else {
                // 没有碰撞，继续移动
                remainingMovement -= currentStep;
                
                // 检查是否离开地面
                if (onGround && velocityY >= 0) {
                    onGround = false;
                    coyoteTimer = (int)coyoteTime;
                }
            }
        }
    }
    
    /**
     * 更新战斗系统计时器
     */
    private void updateCombatTimers() {
        // 更新攻击冷却
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        
        // 更新攻击动画计时器和剑的动画
        if (attackAnimationTimer > 0) {
            attackAnimationTimer--;
            updateSwordAnimation();
            
            // 在攻击动画期间持续检测剑与敌人的碰撞
            checkSwordCollisionWithEnemies();
            
            if (attackAnimationTimer == 0) {
                isAttacking = false;
                // 攻击结束时清空已命中敌人列表
                hitEnemiesThisAttack.clear();
            }
        }
        
        // 更新无敌时间
        if (invulnerabilityTimer > 0) {
            invulnerabilityTimer--;
        }
    }
    
    /**
     * 处理攻击输入
     * 支持蓄力攻击：按住左键蓄力，释放时攻击
     * 只有选中物品时才能使用该物品攻击
     * 背包打开时禁用攻击功能
     */
    private void handleAttackInput() {
        // 检查背包是否打开，如果打开则禁用攻击
        if (gp.inventory.isShowingFullInventory()) {
            // 重置攻击状态
            isCharging = false;
            if (KB.attackPressed) {
                KB.attackPressed = false;
            }
            return; // 背包打开时直接返回，不处理攻击
        }
        
        // 获取当前选中的物品
        item.Item selectedItem = gp.inventory.getSelectedItem();
        
        // 处理蓄力状态
        if (KB.isCharging() && selectedItem != null && attackCooldown == 0 && !isAttacking) {
            isCharging = true;
            // 计算蓄力倍数（最大4倍伤害）
            float chargeProgress = Math.min(KB.getChargeTime() / (float)maxChargeTime, 1.0f);
            chargeMultiplier = 1.0f + chargeProgress * 4.0f; // 1.0 到 4.0 倍伤害
        } else {
            isCharging = false;
        }
        
        // 检查攻击释放（鼠标左键释放且之前在蓄力）
        if (!KB.isCharging() && KB.getChargeTime() > 0 && attackCooldown == 0 && !isAttacking && selectedItem != null) {
            // 设置网络同步标志
            attackJustStarted = true;
            isChargedAttack = (chargeMultiplier > 1.0f);
            
            if (selectedItem instanceof item.SwordItem) {
                // 使用剑攻击
                useSwordFromInventory();
            } else if (selectedItem instanceof item.BowItem) {
                // 使用弓箭攻击
                useBowFromInventory();
            } else if (selectedItem instanceof item.BombItem) {
                // 使用炸弹
                useBombFromInventory();
            }
            
            // 重置蓄力状态
            KB.attackHoldTime = 0;
        }
        
        // 重置攻击按下状态
        if (KB.attackPressed) {
            KB.attackPressed = false;
        }
     }
     
     /**
      * 使用物品栏中的弓箭
      */
     private void useBowFromInventory() {
         // 获取当前选中槽位的物品
         if (gp.inventory.getSelectedItem() instanceof item.BowItem) {
             item.BowItem bow = (item.BowItem) gp.inventory.getSelectedItem();
             if (bow != null && bow.canUse()) {
                 // 使用蓄力倍数增强伤害
                 bow.setChargeMultiplier(chargeMultiplier);
                 bow.use();
                 // 根据蓄力程度设置攻击冷却（蓄力越多，冷却越长）
                 int chargeCooldownBonus = (int)(maxAttackCooldown * (chargeMultiplier - 1.0f) * 0.5f);
                 attackCooldown = maxAttackCooldown + chargeCooldownBonus;
             }
         }
     }
     
     /**
      * 使用物品栏中的剑
      */
     private void useSwordFromInventory() {
         // 获取当前选中槽位的物品
         if (gp.inventory.getSelectedItem() instanceof item.SwordItem) {
             item.SwordItem sword = (item.SwordItem) gp.inventory.getSelectedItem();
             if (sword != null && sword.canUse()) {
                 // 使用蓄力倍数增强伤害
                 sword.setChargeMultiplier(chargeMultiplier);
                 sword.use();
                 // 同时触发攻击动画
                 isAttacking = true;
                 attackAnimationTimer = maxAttackAnimationTime;
                 // 根据蓄力程度设置攻击冷却（蓄力越多，冷却越长）
                 int chargeCooldownBonus = (int)(maxAttackCooldown * (chargeMultiplier - 1.0f) * 0.5f);
                 attackCooldown = maxAttackCooldown + chargeCooldownBonus;
                 setupSwordAttackAnimation();
             }
         }
      }
      
      /**
       * 使用物品栏中的炸弹
       */
      private void useBombFromInventory() {
          // 获取当前选中槽位的物品
          if (gp.inventory.getSelectedItem() instanceof item.BombItem) {
              item.BombItem bomb = (item.BombItem) gp.inventory.getSelectedItem();
              if (bomb != null) {
                  bomb.use();
                  // 设置短暂的攻击冷却，防止连续投掷
                  attackCooldown = 30; // 0.5秒冷却
              }
          }
      }
      
    /**
     * 处理方块放置输入
     * 检测右键点击并放置选中的方块物品
     */
    private void handleBlockPlacement() {
        // 检查右键是否被按下
        if (KB.rightClickPressed) {
            // 获取当前选中的物品
            item.Item selectedItem = gp.inventory.getSelectedItem();
            
            // 检查选中的物品是否为方块物品
            if (selectedItem instanceof item.BlockItem) {
                item.BlockItem blockItem = (item.BlockItem) selectedItem;
                
                // 计算鼠标点击位置对应的世界坐标
                int worldX = KB.mouseX + gp.player.worldx - gp.player.screenx;
                int worldY = KB.mouseY + gp.player.worldy - gp.player.screeny;
                
                // 转换为图块坐标
                int tileX = worldX / gp.tileSize;
                int tileY = worldY / gp.tileSize;
                
                // 检查坐标是否在有效范围内
                if (tileX >= 0 && tileX < gp.maxworldcol && tileY >= 0 && tileY < gp.maxworldrow) {
                    // 检查该位置是否为空（可以放置方块）
                    if (gp.tilemanager.mapnum[tileX][tileY] == 0) {
                        // 放置方块
                        blockItem.use();
                        
                        // 如果方块物品有效，在该位置放置方块
                        if (blockItem.canUse()) {
                            // 设置方块类型（这里使用方块物品的图块索引）
                            gp.tilemanager.mapnum[tileX][tileY] = blockItem.getTileIndex();
                            
                            // 从物品栏中移除一个方块物品
                            gp.inventory.removeItem(gp.inventory.getSelectedSlot(), 1);
                            
                            // 设置网络同步标志
                            blockJustPlaced = true;
                        }
                    }
                }
            }
            
            // 重置右键按下状态
            KB.rightClickPressed = false;
        }
    }
    
    /**
     * 执行攻击
     */
    private void performAttack() {
        isAttacking = true;
        attackAnimationTimer = maxAttackAnimationTime;
        attackCooldown = maxAttackCooldown;
        
        // 清空上次攻击的已命中敌人列表
        hitEnemiesThisAttack.clear();
        
        // 设置剑的初始攻击动画参数
        setupSwordAttackAnimation();
    }
    
    /**
     * 检测剑与敌人的碰撞
     */
    private void checkSwordCollisionWithEnemies() {
        // 计算剑的当前位置
        int swordCenterX = worldx + gp.tileSize/2 + swordOffsetX;
        int swordCenterY = worldy + gp.tileSize/2 + swordOffsetY;
        
        // 获取玩家在屏幕上的位置
        int playerScreenX = screenx + gp.tileSize / 2;
        int playerScreenY = screeny + gp.tileSize / 2;
        
        // 计算鼠标相对于玩家的位置，确定攻击方向
        int deltaX = KB.mouseX - playerScreenX;
        boolean isRightAttack = deltaX >= 0;
        
        // 检测与所有敌人的碰撞
        for (int i = 0; i < gp.enemies.size(); i++) {
            enemy currentEnemy = gp.enemies.get(i);
            
            // 计算敌人相对于玩家的位置
            int enemyCenterX = currentEnemy.worldx + currentEnemy.solidarea.x + currentEnemy.solidarea.width/2;
            int enemyCenterY = currentEnemy.worldy + currentEnemy.solidarea.y + currentEnemy.solidarea.height/2;
            
            // 计算敌人相对于玩家的方向
            int enemyDeltaX = enemyCenterX - (worldx + gp.tileSize/2);
            int enemyDeltaY = enemyCenterY - (worldy + gp.tileSize/2);
            
            // 检查敌人是否在正确的攻击方向上
            boolean enemyInAttackDirection = false;
            if (isRightAttack && enemyDeltaX > 0) {
                // 右侧攻击，敌人在右侧
                enemyInAttackDirection = true;
            } else if (!isRightAttack && enemyDeltaX < 0) {
                // 左侧攻击，敌人在左侧
                enemyInAttackDirection = true;
            }
            
            // 只有在正确方向且距离足够近时才能攻击
            if (enemyInAttackDirection) {
                double distance = Math.sqrt(enemyDeltaX * enemyDeltaX + enemyDeltaY * enemyDeltaY);
                if (distance <= attackRange) {
                    // 创建剑的碰撞区域（更小的矩形）
                    Rectangle swordHitbox = new Rectangle(
                        swordCenterX - swordSize/4,
                        swordCenterY - swordSize/4,
                        swordSize/2,
                        swordSize/2
                    );
                    
                    // 创建敌人的碰撞区域
                    Rectangle enemyHitbox = new Rectangle(
                        currentEnemy.worldx + currentEnemy.solidarea.x,
                        currentEnemy.worldy + currentEnemy.solidarea.y,
                        currentEnemy.solidarea.width,
                        currentEnemy.solidarea.height
                    );
                    
                    // 检测碰撞
                    if (swordHitbox.intersects(enemyHitbox)) {
                        // 检查这个敌人是否已经在本次攻击中被命中过
                        if (!hitEnemiesThisAttack.contains(currentEnemy)) {
                            // 计算实际伤害（包含蓄力倍数）
                            int actualDamage = (int)(attackDamage * chargeMultiplier);
                            currentEnemy.takeDamage(actualDamage);
                            
                            // 将敌人添加到已命中列表，防止重复伤害
                            hitEnemiesThisAttack.add(currentEnemy);
                            
                            System.out.println("Sword hits enemy causing " + actualDamage + " melee damage!");
                        }
                    }
                }
            }
        }
    }
    
    /**
     * 设置剑攻击动画参数
     * 根据鼠标位置判断左右攻击方向
     */
    private void setupSwordAttackAnimation() {
        // 获取玩家在屏幕上的位置
        int playerScreenX = screenx + gp.tileSize / 2;
        int playerScreenY = screeny + gp.tileSize / 2;
        
        // 计算鼠标相对于玩家的位置
        int deltaX = KB.mouseX - playerScreenX;
        
        // 只根据鼠标的左右位置设置初始攻击方向
         if (deltaX >= 0) {
             // 鼠标在右侧，设置正常右侧攻击的初始位置
             swordAngle = 45; // 右上角开始（45度）
             swordOffsetX = 60;
             swordOffsetY = -20;
         } else {
              // 鼠标在左侧，设置左侧攻击的初始位置
              swordAngle = -45; // 左上角开始（-45度），与updateSwordAnimation保持一致
              swordOffsetX = -60;
              swordOffsetY = -20;
          }
    }
     
     /**
      * 更新剑的攻击动画
      * 根据鼠标在角色左右两侧的位置决定挥动方向
      */
      private void updateSwordAnimation() {
          // 计算动画进度（0.0 到 1.0）
          float progress = 1.0f - (float)attackAnimationTimer / maxAttackAnimationTime;
          
          // 使用缓动函数让动画更流畅
          float easedProgress = (float)(1 - Math.pow(1 - progress, 3)); // 缓出效果
          
          // 获取玩家在屏幕上的位置
          int playerScreenX = screenx + gp.tileSize / 2;
          int playerScreenY = screeny + gp.tileSize / 2;
          
          // 计算鼠标相对于玩家的位置
          int deltaX = KB.mouseX - playerScreenX;
          
          // 根据鼠标在角色左右两侧的位置决定挥动方向
          if (deltaX >= 0) {
              // 鼠标在右侧，正常右侧攻击：从右上挥到右下
              swordAngle = -45 + (90 * easedProgress); // 从45度挥到-45度
              swordOffsetX =96 + (int)(10 * easedProgress);
              swordOffsetY = -20 + (int)(40 * easedProgress);
          } else {
              // 鼠标在左侧，左侧攻击：从左上挥到左下（镜像右侧攻击）
              swordAngle = 45 - (90 * easedProgress); // 从-45度挥到45度（与右侧相反）
              swordOffsetX = -96 - (int)(10 * easedProgress);
              swordOffsetY = -20 + (int)(40 * easedProgress);
          }
      }
     
     /**
      * 计算与敌人的距离
      */
    private double getDistanceToEnemy(enemy enemy) {
        int dx = enemy.worldx - worldx;
        int dy = enemy.worldy - worldy;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * 检测与敌人的碰撞（受伤检测）
     */
    private void checkEnemyCollisions() {
        // 如果在无敌时间内，不检测碰撞
        if (invulnerabilityTimer > 0) return;
        
        Rectangle playerRect = new Rectangle(worldx + solidarea.x, worldy + solidarea.y, 
                                           solidarea.width, solidarea.height);
        
        for (enemy currentEnemy : gp.enemies) {
            Rectangle enemyRect = new Rectangle(currentEnemy.worldx + currentEnemy.solidarea.x, 
                                              currentEnemy.worldy + currentEnemy.solidarea.y,
                                              currentEnemy.solidarea.width, currentEnemy.solidarea.height);
            
            // 检测碰撞
            if (playerRect.intersects(enemyRect)) {
                takeDamage(currentEnemy.damage);
                break; // 一次只受到一个敌人的伤害
            }
        }
    }
    
    /**
     * 玩家受到伤害
     */
    public void takeDamage(int damage) {
        if (invulnerabilityTimer > 0) return; // 无敌时间内不受伤害
        
        int oldHealth = health;
        health -= damage;
        invulnerabilityTimer = maxInvulnerabilityTime;
        
        System.out.println("Player takes " + damage + " damage! Health: " + health + "/" + maxHealth);
        
        // 检查是否死亡
        if (health <= 0) {
            health = 0;
            handlePlayerDeath();
        }
        
        // 如果生命值发生变化且在多人游戏模式下，发送生命值更新消息
        if (oldHealth != health && gp.isMultiplayer && gp.networkClient != null && gp.networkClient.isConnected()) {
            gp.networkClient.sendPlayerHealth(health, maxHealth);
        }
    }
    
    /**
     * 处理玩家死亡
     */
    private void handlePlayerDeath() {
        System.out.println("Player died! Game Over!");
        // 这里可以添加游戏结束逻辑，比如重置游戏或显示游戏结束画面
        // 暂时重置玩家状态
        health = maxHealth;
        worldx = gp.tileSize * 15;
        worldy = gp.tileSize * 15;
        
        // 如果在多人游戏模式下，发送生命值更新消息
        if (gp.isMultiplayer && gp.networkClient != null && gp.networkClient.isConnected()) {
            gp.networkClient.sendPlayerHealth(health, maxHealth);
        }
    }
    
    /**
     * 检查玩家是否死亡
     */
    public boolean isDead() {
        return health <= 0;
    }
    
    /**
     * 更新动画
     * 根据移动状态调整动画速度
     */
    private void updateAnimation() {
        spriteCounter++;
        
        // 根据移动状态设置不同的动画速度
        int animationSpeed = getAnimationSpeed();
        
        if (spriteCounter > animationSpeed) {
            if (spriteNum == 1) {
                spriteNum = 2;
            }
        }
        if (spriteCounter > animationSpeed + 60) {
            if (spriteNum == 2) {
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }
    
    /**
     * 根据移动状态获取动画速度
     * @return 动画帧间隔（数值越小动画越快）
     */
    private int getAnimationSpeed() {
        // 如果没有移动，使用慢速动画
        if (direction.equals("stop")) {
            return 120; // 慢速待机动画
        }
        
        // 根据移动状态返回不同的动画速度
        switch (currentMovementState) {
            case WALKING:
                return 60; // 正常走路动画速度
            case RUNNING:
                return 30; // 跑步动画速度（更快）
            case SPRINTING:
                return 15; // 冲刺动画速度（最快）
            default:
                return 60; // 默认速度
        }
     }
     
     /**
      * 绘制移动状态的视觉效果
      */
     private void drawMovementEffects(Graphics2D g2) {
         switch (currentMovementState) {
             case RUNNING:
                 drawRunningEffect(g2);
                 break;
             case SPRINTING:
                 drawSprintingEffect(g2);
                 break;
             case WALKING:
             default:
                 // 走路状态无特殊效果
                 break;
         }
     }
     
     /**
      * 绘制跑步效果（轻微的粒子效果）
      */
     private void drawRunningEffect(Graphics2D g2) {
         // 只在移动时显示效果
         if (direction.equals("stop")) return;
         
         // 设置跑步粒子颜色（淡蓝色）
         g2.setColor(new Color(173, 216, 230, 80));
         
         // 在脚部位置绘制小粒子
         int footY = screeny + gp.tileSize - 8;
         for (int i = 0; i < 3; i++) {
             int particleX = screenx + gp.tileSize/2 + (int)(Math.random() * 20 - 10);
             int particleY = footY + (int)(Math.random() * 10);
             g2.fillOval(particleX, particleY, 2, 2);
         }
     }
     
     /**
      * 绘制冲刺效果（残影和强烈粒子效果）
      */
     private void drawSprintingEffect(Graphics2D g2) {
         // 只在移动时显示效果
         if (direction.equals("stop")) return;
         
         // 绘制残影效果
         drawAfterImage(g2);
         
         // 绘制冲刺粒子效果
         g2.setColor(new Color(255, 165, 0, 120)); // 橙色粒子
         
         // 在角色周围绘制更多粒子
         int footY = screeny + gp.tileSize - 8;
         for (int i = 0; i < 8; i++) {
             int particleX = screenx + gp.tileSize/2 + (int)(Math.random() * 40 - 20);
             int particleY = footY + (int)(Math.random() * 15);
             int size = (int)(Math.random() * 3 + 1);
             g2.fillOval(particleX, particleY, size, size);
         }
         
         // 绘制速度线条效果
         drawSpeedLines(g2);
     }
     
     /**
      * 绘制残影效果
      */
     private void drawAfterImage(Graphics2D g2) {
         // 保存当前透明度
         Composite originalComposite = g2.getComposite();
         
         // 设置半透明
         g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
         
         // 在稍微偏后的位置绘制残影
         int offsetX = direction.equals("left") ? 8 : (direction.equals("right") ? -8 : 0);
         
         // 绘制残影（使用当前角色图像）
         BufferedImage afterImage = direction.equals("left") ? left : 
                                   (direction.equals("right") ? right : stop);
         
         if (afterImage != null) {
             g2.drawImage(afterImage, screenx + offsetX, screeny, gp.tileSize, gp.tileSize, null);
         }
         
         // 恢复原始透明度
         g2.setComposite(originalComposite);
     }
     
     /**
      * 绘制速度线条效果
      */
     private void drawSpeedLines(Graphics2D g2) {
         g2.setColor(new Color(255, 255, 255, 150));
         g2.setStroke(new BasicStroke(2.0f));
         
         // 根据移动方向绘制速度线
         int lineLength = 20;
         int startX = direction.equals("left") ? screenx + gp.tileSize : screenx;
         int endX = direction.equals("left") ? startX + lineLength : startX - lineLength;
         
         // 绘制多条速度线
         for (int i = 0; i < 3; i++) {
             int lineY = screeny + gp.tileSize/2 + (i - 1) * 8;
             g2.drawLine(startX, lineY, endX, lineY);
         }
     }
     
     public void draw(Graphics2D g2) {
        BufferedImage image = null;

        // 绘制移动状态的视觉效果（在角色之前绘制）
        drawMovementEffects(g2);

        // 优先处理跳跃状态的动画
        if (isJumping || !onGround) {
            // 跳跃状态下根据方向显示对应的跳跃动画
            if (direction.equals("left")) {
                if(spriteNum == 1) image = left;
                if(spriteNum == 2) image = leftz;
            } else if (direction.equals("right")) {
                if(spriteNum == 1) image = right;
                if(spriteNum == 2) image = rightz;
            } else {
                // 默认跳跃动画（如果有跳跃图片的话）
                if(spriteNum == 1) image = stop;
                if(spriteNum == 2) image = stopz;
            }
        } else {
            // 地面状态的正常动画
            switch (direction) {
                case "left":
                    if(spriteNum == 1) image = left;
                    if(spriteNum == 2) image = leftz;
                    break;
                case "right":
                    if(spriteNum == 1) image = right;
                    if(spriteNum == 2) image = rightz;
                    break;
                case "stop":
                default:
                    if(spriteNum == 1) image = stop;
                    if(spriteNum == 2) image = stopz;
                    break;
            }
        }

        // 无敌时间闪烁效果
        boolean shouldDraw = true;
        if (invulnerabilityTimer > 0) {
            // 每5帧切换一次可见性，创建闪烁效果
            shouldDraw = (invulnerabilityTimer / 5) % 2 == 0;
        }
        
        // 绘制角色
        if (shouldDraw) {
            g2.drawImage(image, screenx, screeny, gp.tileSize, gp.tileSize, null);
        }
        
        // 绘制剑（如果正在攻击）
        if (isAttacking && shouldDraw) {
            drawSword(g2);
        }
        
        // 攻击范围可视化（调试用，可选）
        if (isAttacking) {
            g2.setColor(new Color(255, 0, 0, 50)); // 半透明红色
            g2.fillOval(screenx - attackRange/2 + gp.tileSize/2, 
                       screeny - attackRange/2 + gp.tileSize/2, 
                       attackRange, attackRange);
        }
        
        // 绘制玩家血量条
        drawHealthBar(g2);
        
        // 绘制蓄力进度条
        if (isCharging) {
            drawChargeBar(g2);
        }
    }
    
    /**
      * 绘制剑的攻击动画
      */
     private void drawSword(Graphics2D g2) {
         if (swordImage == null) return;
         
         // 根据鼠标位置判断攻击方向，选择合适的剑图片
         BufferedImage currentSwordImage;
         int playerScreenX = screenx + gp.tileSize / 2;
         int deltaX = KB.mouseX - playerScreenX;
         
         if (deltaX >= 0 && swordImageRight != null) {
             // 鼠标在右侧，使用右侧攻击剑图片
             currentSwordImage = swordImageRight;
         } else {
             // 鼠标在左侧，使用左侧攻击剑图片
             currentSwordImage = swordImage;
         }
         
         // 保存当前的变换状态
         Graphics2D g2d = (Graphics2D) g2.create();
         
         // 计算玩家手部位置作为旋转中心（更自然的挥砍效果）
         int rotationCenterX = screenx + gp.tileSize/2;
         int rotationCenterY = screeny + gp.tileSize/2;
         
         // 计算剑的实际绘制位置
         int swordCenterX = rotationCenterX + swordOffsetX;
         int swordCenterY = rotationCenterY + swordOffsetY;
         
         // 绘制攻击轨迹（半透明弧线）
         drawAttackTrail(g2d, rotationCenterX, rotationCenterY);
         
         // 设置旋转变换（以玩家为中心旋转）
         g2d.rotate(Math.toRadians(swordAngle), rotationCenterX, rotationCenterY);
         
         // 添加剑的发光效果
         float alpha = 0.8f + 0.2f * (float)Math.sin(System.currentTimeMillis() * 0.01);
         g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
         
         // 绘制剑（以玩家为旋转中心）
         g2d.drawImage(currentSwordImage, 
                      swordCenterX - swordSize/2, 
                      swordCenterY - swordSize/2, 
                      swordSize, swordSize, null);
         
         // 恢复变换状态
         g2d.dispose();
     }
     
     /**
      * 绘制攻击轨迹
      */
     private void drawAttackTrail(Graphics2D g2, int centerX, int centerY) {
         // 计算动画进度
         float progress = 1.0f - (float)attackAnimationTimer / maxAttackAnimationTime;
         
         // 设置轨迹颜色（金黄色，半透明）
         g2.setColor(new Color(255, 215, 0, (int)(100 * (1 - progress))));
         g2.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
         
         // 根据方向绘制不同的攻击轨迹
         int trailRadius = 60;
         switch (direction) {
             case "right":
                 // 右侧弧形轨迹
                 g2.drawArc(centerX - trailRadius, centerY - trailRadius, 
                           trailRadius * 2, trailRadius * 2, -30, (int)(120 * progress));
                 break;
             case "left":
                 // 左侧弧形轨迹
                 g2.drawArc(centerX - trailRadius, centerY - trailRadius, 
                           trailRadius * 2, trailRadius * 2, 30, (int)(-120 * progress));
                 break;
             default:
                 // 垂直弧形轨迹
                 g2.drawArc(centerX - trailRadius, centerY - trailRadius, 
                           trailRadius * 2, trailRadius * 2, -45, (int)(90 * progress));
                 break;
         }
     }
    
    /**
     * 绘制玩家血量条（垂直柱状，位于玩家左侧）
     */
    private void drawHealthBar(Graphics2D g2) {
        int barWidth = 4;   // 柱状血量条宽度（更薄）
        int barHeight = 64; // 柱状血量条高度（与玩家一样高）
        int barX = screenx - 6; // 位于玩家左侧
        int barY = screeny; // 与玩家垂直对齐
        
        // 血量条背景边框
        g2.setColor(Color.BLACK);
        g2.fillRect(barX - 1, barY - 1, barWidth + 2, barHeight + 2);
        
        // 血量条背景（深灰色）
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(barX, barY, barWidth, barHeight);
        
        // 当前血量条（从底部向上填充）
        g2.setColor(Color.RED);
        int currentHealthHeight = (int)((double)health / maxHealth * barHeight);
        int healthBarY = barY + barHeight - currentHealthHeight; // 从底部开始
        g2.fillRect(barX, healthBarY, barWidth, currentHealthHeight);
        
        // 血量条边框
        g2.setColor(Color.WHITE);
        g2.drawRect(barX - 1, barY - 1, barWidth + 1, barHeight + 1);
        
        // 血量文字（显示在物品栏上方偏左）
        g2.setColor(Color.green);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        g2.drawString(health + "/" + maxHealth, screenx - 40, screeny - 50);
        
        // 攻击冷却指示器（显示在物品栏上方）
        if (attackCooldown > 0) {
            g2.setColor(Color.gray);
            g2.setFont(new Font("Arial", Font.BOLD, 10));
            g2.drawString("CD: " + String.format("%.1f", attackCooldown / 60.0f), screenx + 20, screeny - 50);
        }
    }
    
    /**
     * 绘制蓄力进度条
     */
    private void drawChargeBar(Graphics2D g2) {
        int barWidth = gp.tileSize+6; // 与玩家宽度一致
        int barHeight = 4; // 改为4像素高度
        int barX = screenx-6; // 与玩家左边对齐
        int barY = screeny + gp.tileSize+6; // 紧贴玩家底部
        
        // 蓄力条背景
        g2.setColor(Color.BLACK);
        g2.fillRect(barX - 1, barY - 1, barWidth + 2, barHeight + 2);
        
        // 蓄力条背景（深灰色）
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(barX, barY, barWidth, barHeight);
        
        // 蓄力进度
        float chargeProgress = Math.min(KB.getChargeTime() / (float)maxChargeTime, 1.0f);
        
        // 根据蓄力程度改变颜色
        if (chargeProgress < 0.5f) {
            g2.setColor(Color.YELLOW);
        } else if (chargeProgress < 0.8f) {
            g2.setColor(Color.ORANGE);
        } else {
            g2.setColor(Color.RED);
        }
        
        int chargeBarWidth = (int) (barWidth * chargeProgress);
        g2.fillRect(barX, barY, chargeBarWidth, barHeight);
        
        // 蓄力条边框
        g2.setColor(Color.WHITE);
        g2.drawRect(barX - 1, barY - 1, barWidth + 1, barHeight + 1);
        
        // 显示蓄力倍数文字
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        String chargeText = String.format("%.1fx", chargeMultiplier);
        g2.drawString(chargeText, barX + barWidth + 10, barY + barHeight);
    }
    
    /**
     * 处理移动状态和耐力系统
     */
    private void handleMovementState() {
        boolean isMoving = KB.left || KB.right;
        
        // 检查是否按下跑步或冲刺键（使用动态按键绑定）
        boolean runKeyPressed = isKeyPressed(KeySettings.RUN);     // 跑步键状态
        boolean sprintKeyPressed = isKeyPressed(KeySettings.SPRINT);   // 冲刺键状态
        
        // 更新移动状态
        if (isMoving) {
            if (sprintKeyPressed && canSprint && stamina > 0) {
                // 冲刺状态
                currentMovementState = MovementState.SPRINTING;
                stamina -= sprintStaminaCost;
                staminaRegenDelay = maxStaminaRegenDelay;
                
                // 耐力耗尽时无法继续冲刺
                if (stamina <= 0) {
                    stamina = 0;
                    canSprint = false;
                }
            } else if (runKeyPressed) {
                // 跑步状态
                currentMovementState = MovementState.RUNNING;
            } else {
                // 普通走路状态
                currentMovementState = MovementState.WALKING;
            }
        } else {
            // 静止时默认为走路状态
            currentMovementState = MovementState.WALKING;
        }
        
        // 耐力恢复逻辑
        if (currentMovementState != MovementState.SPRINTING) {
            if (staminaRegenDelay > 0) {
                staminaRegenDelay--;
            } else {
                // 恢复耐力
                if (stamina < maxStamina) {
                    stamina += staminaRegenRate;
                    if (stamina > maxStamina) {
                        stamina = maxStamina;
                    }
                }
                
                // 耐力恢复到一定程度后可以重新冲刺
                if (stamina >= 20) {
                    canSprint = true;
                }
            }
        }
        
        // 更新玩家速度
        speed = currentMovementState.getSpeed();
    }
    
    // 辅助方法：检查指定动作的按键是否被按下
    private boolean isKeyPressed(String action) {
        // 直接检查KeyBoard中对应的状态，而不依赖硬编码的按键映射
        if (action.equals(KeySettings.MOVE_UP)) {
            return KB.up;
        } else if (action.equals(KeySettings.MOVE_DOWN)) {
            return KB.down;
        } else if (action.equals(KeySettings.MOVE_LEFT)) {
            return KB.left;
        } else if (action.equals(KeySettings.MOVE_RIGHT)) {
            return KB.right;
        } else if (action.equals(KeySettings.JUMP)) {
            return KB.space;
        } else if (action.equals(KeySettings.RUN)) {
            return KB.shift;
        } else if (action.equals(KeySettings.SPRINT)) {
            return KB.ctrl;
        }
        
        return false;
    }
}
