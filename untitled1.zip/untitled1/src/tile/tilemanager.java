package tile;

import main.GamePanel;
import main.TerrainGenerator;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * 图块管理器类
 * 负责管理游戏地图的图块资源和地图数据
 * 包括图块图像的加载、地图文件的读取和地图的绘制
 * 支持程序化地形生成
 */
public class tilemanager {
    /**
     * 游戏面板引用
     * 用于获取游戏配置信息和玩家位置
     */
    GamePanel gp;
    
    /**
     * 图块数组，存储不同类型的图块
     * 每个索引对应一种图块类型，包含图像和碰撞属性
     */
    public tile[] TI;
    
    /**
     * 地图数据二维数组，存储每个位置的图块索引
     * mapnum[列][行] = 图块类型索引
     */
    public int[][] mapnum;
    
    /**
     * 地形生成器
     * 用于程序化生成地形
     */
    private TerrainGenerator terrainGenerator;

    /**
     * 构造函数，初始化图块管理器
     * 创建图块数组、地图数组，并加载图块资源和地图数据
     * @param gp 游戏面板实例
     */
    public tilemanager(GamePanel gp) {
        this.gp = gp;
        TI = new tile[2]; // 初始化图块数组，只支持空气和墙壁两种类型
        mapnum = new int[gp.maxworldcol][gp.maxworldrow]; // 根据游戏世界大小初始化地图数组
        terrainGenerator = new TerrainGenerator(); // 初始化地形生成器
        gettilemanager(); // 加载图块图像资源
        // mapload("/maps/test.txt"); // 注释掉原有的地图加载，改用地形生成
        generateTerrain(); // 生成程序化地形
    }

    /**
     * 生成程序化地形
     * 使用地形生成器创建横版2D地形数据
     */
    public void generateTerrain() {
        // 使用横版2D地形生成方法
        mapnum = terrainGenerator.generateTerrain(gp.maxworldcol, gp.maxworldrow);
        System.out.println("Generated 2D side-scrolling terrain with dimensions: " + gp.maxworldcol + "x" + gp.maxworldrow);
    }
    
    /**
     * 重新生成地形
     * 使用新的随机种子重新生成地形
     */
    public void regenerateTerrain() {
        TerrainGenerator.GenerationConfig config = terrainGenerator.getConfig();
        config.seed = System.currentTimeMillis(); // 使用当前时间作为新种子
        terrainGenerator.setConfig(config);
        generateTerrain();
    }
    
    /**
     * 生成平坦测试地形
     * 用于调试和测试
     * @param groundLevel 地面高度
     */
    public void generateFlatTerrain(int groundLevel) {
        mapnum = terrainGenerator.generateFlatTerrain(gp.maxworldcol, gp.maxworldrow, groundLevel);
    }
    
    /**
     * 获取地形生成器
     * @return 当前使用的地形生成器实例
     */
    public TerrainGenerator getTerrainGenerator() {
        return terrainGenerator;
    }
    
    /**
     * 设置地形生成器配置
     * @param config 新的生成配置
     */
    
    /**
     * 更新地图数据
     * 用于从网络接收到的地图数据
     * @param newMapData 新的地图数据
     * @param mapWidth 地图宽度
     * @param mapHeight 地图高度
     */
    public void updateMapData(int[][] newMapData, int mapWidth, int mapHeight) {
        if (newMapData != null && mapWidth > 0 && mapHeight > 0 && 
            mapWidth <= gp.maxworldcol && mapHeight <= gp.maxworldrow) {
            
            // 复制地图数据
            for (int col = 0; col < mapWidth; col++) {
                for (int row = 0; row < mapHeight; row++) {
                    if (col < gp.maxworldcol && row < gp.maxworldrow) {
                        mapnum[col][row] = newMapData[col][row];
                    }
                }
            }
            
            System.out.println("地图数据已更新，大小: " + mapWidth + "x" + mapHeight);
        }
    }
    
    /**
     * 更新特定图块
     * 用于从网络接收到的部分地图更新
     * @param tileIndices 需要更新的图块一维索引数组
     * @param tileValues 对应的图块值数组 [value1, value2, ...]
     * @param count 更新的图块数量
     */
    public void updateMapTiles(int[] tileIndices, int[] tileValues, int count) {
        if (tileIndices != null && tileValues != null && count > 0 && count <= tileIndices.length && count <= tileValues.length) {
            int updatedCount = 0;
            
            for (int i = 0; i < count; i++) {
                int index = tileIndices[i];
                int value = tileValues[i];
                
                // 将一维索引转换为二维坐标
                int row = index / gp.maxworldcol;
                int col = index % gp.maxworldcol;
                
                // 检查坐标是否在地图范围内
                if (col >= 0 && col < gp.maxworldcol && row >= 0 && row < gp.maxworldrow) {
                    mapnum[col][row] = value;
                    updatedCount++;
                }
            }
            
            System.out.println("已更新 " + updatedCount + " 个图块");
        }
    }
    public void setTerrainConfig(TerrainGenerator.GenerationConfig config) {
        terrainGenerator.setConfig(config);
    }

    /**
     * 获取图块管理器资源
     * 加载所有图块的图像文件并设置其属性
     * 包括碰撞检测属性的设置
     */
    public void gettilemanager() {
        try {
            // 加载第一个图块（索引0）- 空气/可通行区域
            TI[0] = new tile();
            TI[0].image = ImageIO.read(getClass().getResourceAsStream("/res/tiles/wall_0_1.png"));
            TI[0].collision = false; // 空气不阻挡移动

            // 加载第二个图块（索引1）- 石头/墙壁图块
            TI[1] = new tile();
            TI[1].image = ImageIO.read(getClass().getResourceAsStream("/res/tiles/wall_4_2.png"));
            TI[1].collision = true; // 石头阻挡移动

            // 只使用空气(0)和墙壁(1)两种地形类型

        } catch (IOException e) {
            e.printStackTrace(); // 打印异常信息，便于调试
        }
    }

    /**
     * 从文件加载地图数据
     * 读取地图文件并解析为二维数组，每个数字代表对应位置的图块类型
     * @param filePath 地图文件的路径（相对于资源文件夹）
     */
    public void mapload(String filePath) {
        try {
            // 获取地图文件输入流
            InputStream is = getClass().getResourceAsStream(filePath);
            // 创建缓冲读取器读取文件内容
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            // 初始化地图数组，将所有位置设置为默认值0（可通行地面）
            for (int r = 0; r < gp.maxScreenRow; r++) {
                for (int c = 0; c < gp.maxworldcol; c++) {
                    mapnum[c][r] = 0; // 默认使用0号图块（可通行）
                }
            }

            String line; // 存储每行读取的内容
            int row = 0; // 当前处理的行索引

            // 逐行读取地图文件，直到文件结束或达到最大行数
            while ((line = br.readLine()) != null && row < gp.maxworldrow) {
                String nums[] = line.split(""); // 将每行拆分为单个字符
                int col = 0; // 当前处理的列索引

                // 处理当前行的所有列，直到达到最大列数或行数据结束
                while (col < gp.maxworldcol && col < nums.length) {
                    if (!nums[col].isEmpty()) { // 确保字符不为空
                        try {
                            // 将字符转换为整数作为图块索引
                            int num = Integer.parseInt(nums[col]);
                            mapnum[col][row] = num; // 存储图块索引到地图数组
                        } catch (NumberFormatException e) {
                            // 如果转换失败，使用默认值0
                            mapnum[col][row] = 0;
                        }
                    }
                    col++; // 移动到下一列
                }
                row++; // 移动到下一行
            }
            br.close(); // 关闭文件读取器
        } catch (Exception e) {
            e.printStackTrace(); // 异常处理：打印错误堆栈
        }
    }

    /**
     * 破坏指定位置的方块
     * @param col 方块列坐标
     * @param row 方块行坐标
     * @return 被破坏的方块类型索引，如果无法破坏则返回-1
     */
    public int destroyBlock(int col, int row) {
        // 检查坐标是否在地图范围内
        if (col < 0 || col >= gp.maxworldcol || row < 0 || row >= gp.maxworldrow) {
            return -1;
        }
        
        int tileIndex = mapnum[col][row];
        
        // 只能破坏非空气方块
        if (tileIndex != 0) {
            mapnum[col][row] = 0; // 设置为空气
            return tileIndex; // 返回被破坏的方块类型
        }
        
        return -1; // 无法破坏
    }
    
    /**
     * 检查方块是否可以被破坏
     * @param col 方块列坐标
     * @param row 方块行坐标
     * @return 是否可以破坏
     */
    public boolean canDestroyBlock(int col, int row) {
        // 检查坐标是否在地图范围内
        if (col < 0 || col >= gp.maxworldcol || row < 0 || row >= gp.maxworldrow) {
            return false;
        }
        
        int tileIndex = mapnum[col][row];
        return tileIndex != 0; // 非空气方块可以被破坏
    }
    
    /**
     * 获取指定位置的方块类型
     * @param col 方块列坐标
     * @param row 方块行坐标
     * @return 方块类型索引
     */
    public int getBlockType(int col, int row) {
        if (col < 0 || col >= gp.maxworldcol || row < 0 || row >= gp.maxworldrow) {
            return -1;
        }
        return mapnum[col][row];
    }
    
    /**
     * 绘制地图到屏幕
     * 根据玩家位置计算可见区域，只绘制屏幕范围内的图块以优化性能
     * @param g2 图形绘制对象
     */
    public void draw(Graphics2D g2) {
        int wcol = 0; // 当前绘制的世界列索引
        int wrow = 0; // 当前绘制的世界行索引

        // 遍历整个世界地图的所有图块
        while (wcol < gp.maxworldcol && wrow < gp.maxworldrow) {
            // 获取当前位置的图块类型索引
            int tilenum = mapnum[wcol][wrow];

            // 计算图块在世界坐标系中的位置
            int wx = wcol * gp.tileSize; // 世界X坐标
            int wy = wrow * gp.tileSize; // 世界Y坐标
            
            // 将世界坐标转换为屏幕坐标（相对于玩家位置）
            int sx = wx - gp.player.worldx + gp.player.screenx; // 屏幕X坐标
            int sy = wy - gp.player.worldy + gp.player.screeny; // 屏幕Y坐标
            
            // 视锥剔除：只绘制在屏幕可见范围内的图块（包含缓冲区）
            if (wx + gp.tileSize * 2 > gp.player.worldx - gp.player.screenx &&
                wx - gp.tileSize * 2 < gp.player.worldx + gp.player.screenx &&
                wy + gp.tileSize * 2 > gp.player.worldy - gp.player.screeny &&
                wy - gp.tileSize * 2 < gp.player.worldy + gp.player.screeny) {
                // 绘制图块到计算出的屏幕位置
                g2.drawImage(TI[tilenum].image, sx, sy, gp.tileSize, gp.tileSize, null);
            }
            
            wcol++; // 移动到下一列

            // 如果到达当前行的末尾，换到下一行
            if (wcol == gp.maxworldcol) {
                wcol = 0; // 重置列索引到行首
                wrow++; // 移动到下一行
            }
        }
    }
}
