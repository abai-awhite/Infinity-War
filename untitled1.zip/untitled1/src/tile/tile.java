package tile;

import java.awt.image.BufferedImage;

/**
 * 图块类
 * 表示游戏地图中的一个图块单元
 * 包含图块的图像和碰撞属性
 */
public class tile {
    /**
     * 图块的图像
     * 用于在屏幕上绘制该图块的视觉表现
     */
    public BufferedImage image;
    
    /**
     * 碰撞属性
     * true表示该图块具有碰撞体积，实体无法穿过
     * false表示该图块可以被实体穿过（如草地、地板等）
     */
    public boolean collision = false;
}
