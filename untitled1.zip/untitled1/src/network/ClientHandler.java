package network;

import java.io.*;
import java.net.*;

/**
 * 客户端处理器类
 * 处理单个客户端的连接和消息通信
 */
public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private String clientId;
    private transient GameServer server;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private boolean isConnected = true;
    private String playerName;
    private long lastHeartbeat;
    
    public ClientHandler(Socket clientSocket, String clientId, GameServer server) {
        this.clientSocket = clientSocket;
        this.clientId = clientId;
        this.server = server;
        this.lastHeartbeat = System.currentTimeMillis();
        
        try {
            // 注意：先创建输出流，再创建输入流
            outputStream = new ObjectOutputStream(clientSocket.getOutputStream());
            outputStream.flush();
            inputStream = new ObjectInputStream(clientSocket.getInputStream());
        } catch (IOException e) {
            System.err.println("创建客户端流时出错: " + e.getMessage());
            disconnect();
        }
    }
    
    @Override
    public void run() {
        try {
            // 等待客户端发送玩家名称
            NetworkMessage firstMessage = (NetworkMessage) inputStream.readObject();
            if (firstMessage instanceof PlayerJoinMessage) {
                PlayerJoinMessage joinMsg = (PlayerJoinMessage) firstMessage;
                this.playerName = joinMsg.playerName;
                server.playerJoined(clientId, playerName);
            }
            
            // 消息处理循环
            while (isConnected && !clientSocket.isClosed()) {
                try {
                    // 使用socket超时来避免阻塞
                    clientSocket.setSoTimeout(100);
                    
                    try {
                        Object obj = inputStream.readObject();
                        
                        if (obj == null) {
                            continue;
                        }
                        
                        if (obj instanceof NetworkMessage) {
                            NetworkMessage message = (NetworkMessage) obj;
                            handleMessage(message);
                        } else {
                            System.err.println("服务器收到非NetworkMessage对象: " + obj.getClass().getName());
                            // 如果是String类型，可能是客户端发送的调试信息
                            if (obj instanceof String) {
                                System.out.println("客户端消息: " + obj);
                            }
                        }
                    } catch (StreamCorruptedException e) {
                        System.err.println("服务器流损坏: " + e.getMessage());
                        // 重新创建输入流
                        try {
                            inputStream.close();
                            inputStream = new ObjectInputStream(clientSocket.getInputStream());
                            System.out.println("已重置客户端 " + clientId + " 的输入流");
                        } catch (IOException resetEx) {
                            System.err.println("重置输入流失败: " + resetEx.getMessage());
                            break; // 退出循环，断开连接
                        }
                    } catch (SocketTimeoutException e) {
                        // 超时，继续循环
                        continue;
                    }
                } catch (EOFException e) {
                    // 客户端断开连接
                    System.out.println("客户端断开连接: " + clientId);
                    break;
                } catch (SocketTimeoutException e) {
                    // 检查心跳超时
                    if (System.currentTimeMillis() - lastHeartbeat > 30000) { // 30秒超时
                        System.out.println("客户端心跳超时: " + clientId);
                        break;
                    }
                } catch (ClassNotFoundException e) {
                    System.err.println("服务器消息类型错误: " + e.getMessage());
                    e.printStackTrace();
                    // 继续尝试接收下一条消息
                } catch (InvalidClassException e) {
                    System.err.println("服务器类序列化版本不匹配: " + e.getMessage());
                    e.printStackTrace();
                    // 继续尝试接收下一条消息
                } catch (StreamCorruptedException e) {
                    System.err.println("服务器流损坏: " + e.getMessage());
                    e.printStackTrace();
                    // 流已损坏，需要断开连接
                    break;
                } catch (OptionalDataException e) {
                    System.err.println("服务器通信错误: invalid type code: " + String.format("%02X", e.length));
                    e.printStackTrace();
                    // 继续尝试接收下一条消息
                } catch (IOException e) {
                    if (e.getMessage() != null && e.getMessage().contains("invalid type code")) {
                        System.err.println("服务器通信错误: " + e.getMessage());
                        // 继续尝试接收下一条消息
                    } else {
                        System.err.println("接收消息时出错: " + e.getMessage());
                        e.printStackTrace();
                        break;
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            if (isConnected) {
                System.err.println("客户端通信错误: " + e.getMessage());
                e.printStackTrace();
            }
        } finally {
            disconnect();
        }
    }
    
    /**
     * 处理接收到的消息
     */
    private void handleMessage(NetworkMessage message) {
        // 更新心跳时间
        lastHeartbeat = System.currentTimeMillis();
        
        switch (message.getType()) {
            case PONG:
                // 心跳响应，不需要特殊处理
                break;
            case ECHO:
                // 处理Echo消息
                handleEcho((EchoMessage) message);
                break;
            case PLAYER_POSITION:
            case PLAYER_ATTACK:
            case ARROW_SHOOT:
            case BLOCK_PLACE:
            case MAP_SYNC:
                // 将消息添加到服务器处理队列
                server.queueMessage(message);
                break;
            default:
                System.out.println("收到未知消息类型: " + message.getType());
                break;
        }
    }
    
    /**
     * 发送消息给客户端
     */
    public void sendMessage(NetworkMessage message) {
        if (isConnected && outputStream != null) {
            try {
                outputStream.writeObject(message);
                outputStream.flush();
            } catch (IOException e) {
                System.err.println("发送消息失败: " + e.getMessage());
                disconnect();
            }
        }
    }
    
    /**
     * 断开客户端连接
     */
    public void disconnect() {
        if (isConnected) {
            isConnected = false;
            
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                System.err.println("关闭客户端连接时出错: " + e.getMessage());
            }
            
            // 通知服务器玩家离开
            server.playerLeft(clientId);
        }
    }
    
    public String getClientId() {
        return clientId;
    }
    
    public String getPlayerName() {
        return playerName;
    }
    
    public boolean isConnected() {
        return isConnected;
    }
    
    /**
     * 处理Echo消息
     */
    private void handleEcho(EchoMessage message) {
        System.out.println("服务器收到Echo消息: " + message.getMessage() + "，来自玩家: " + message.getPlayerId());
        // 直接回复相同的Echo消息
        sendMessage(message);
    }
}