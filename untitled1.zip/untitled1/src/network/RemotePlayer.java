package network;

/**
 * 远程玩家类
 * 表示其他联机玩家的状态和信息
 */
public class RemotePlayer {
    public String playerId;
    public String playerName;
    
    // 位置和移动状态
    public double worldX;
    public double worldY;
    public double velocityX;
    public double velocityY;
    
    // 玩家状态
    public boolean isMoving;
    public boolean isJumping;
    public boolean isFalling;
    public String direction; // "left" 或 "right"
    public String animationState;
    
    // 生命值
    public int health;
    public int maxHealth;
    
    // 时间戳
    public long lastUpdateTime;
    
    /**
     * 构造函数
     */
    public RemotePlayer(String playerId, String playerName, double worldX, double worldY, int health, int maxHealth) {
        this.playerId = playerId;
        this.playerName = playerName;
        this.worldX = worldX;
        this.worldY = worldY;
        this.health = health;
        this.maxHealth = maxHealth;
        
        this.velocityX = 0;
        this.velocityY = 0;
        this.isMoving = false;
        this.isJumping = false;
        this.isFalling = false;
        this.direction = "right";
        this.animationState = "idle";
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新位置信息
     */
    public void updatePosition(double worldX, double worldY, double velocityX, double velocityY) {
        this.worldX = worldX;
        this.worldY = worldY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新状态信息
     */
    public void updateState(boolean isMoving, boolean isJumping, boolean isFalling, String direction, String animationState) {
        this.isMoving = isMoving;
        this.isJumping = isJumping;
        this.isFalling = isFalling;
        this.direction = direction;
        this.animationState = animationState;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新生命值
     */
    public void updateHealth(int health) {
        this.health = Math.max(0, Math.min(health, maxHealth));
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新生命值和最大生命值
     */
    public void updateHealth(int health, int maxHealth) {
        this.maxHealth = maxHealth;
        this.health = Math.max(0, Math.min(health, maxHealth));
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 检查玩家是否超时（用于清理断线玩家）
     */
    public boolean isTimeout(long timeoutMs) {
        return System.currentTimeMillis() - lastUpdateTime > timeoutMs;
    }
    
    /**
     * 获取屏幕坐标X（相对于摄像机）
     */
    public int getScreenX(double cameraX, int screenWidth) {
        return (int)(worldX - cameraX + screenWidth / 2);
    }
    
    /**
     * 获取屏幕坐标Y（相对于摄像机）
     */
    public int getScreenY(double cameraY, int screenHeight) {
        return (int)(worldY - cameraY + screenHeight / 2);
    }
    
    /**
     * 检查是否在屏幕可见范围内
     */
    public boolean isVisible(double cameraX, double cameraY, int screenWidth, int screenHeight) {
        int screenX = getScreenX(cameraX, screenWidth);
        int screenY = getScreenY(cameraY, screenHeight);
        
        // 玩家大小大约48x48像素，留一些边距
        return screenX > -64 && screenX < screenWidth + 64 && 
               screenY > -64 && screenY < screenHeight + 64;
    }
    
    @Override
    public String toString() {
        return String.format("RemotePlayer{id='%s', name='%s', pos=(%.1f,%.1f), health=%d/%d}", 
                           playerId, playerName, worldX, worldY, health, maxHealth);
    }
}