package network;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * 游戏服务器类
 * 处理多客户端连接，管理游戏状态同步
 */
public class GameServer implements Serializable {
    private static final int DEFAULT_PORT = 12345;
    private static final int MAX_PLAYERS = 8;
    
    private static final long serialVersionUID = 1L;
    
    private transient ServerSocket serverSocket;
    private boolean isRunning = false;
    private int port;
    private transient Map<String, ClientHandler> connectedClients;
    private transient ExecutorService threadPool;
    private transient Timer gameUpdateTimer;
    
    // 游戏状态
    private transient Map<String, PlayerState> playerStates;
    private transient List<NetworkMessage> messageQueue;
    private transient Object messageQueueLock = new Object();
    
    // 地形生成
    private transient int[][] mapData;
    private int mapWidth;
    private int mapHeight;
    private long terrainSeed;
    
    public GameServer() {
        this(DEFAULT_PORT);
    }
    
    public GameServer(int port) {
        this.port = port;
        this.connectedClients = new ConcurrentHashMap<>();
        this.playerStates = new ConcurrentHashMap<>();
        this.messageQueue = new ArrayList<>();
        this.threadPool = Executors.newCachedThreadPool();
        
        // 初始化地形生成相关字段
        this.terrainSeed = System.currentTimeMillis();
        this.mapWidth = 999; // 地图宽度
        this.mapHeight = 999; // 地图高度
        
        // 生成地形
        generateTerrain();
    }
    
    /**
     * 启动服务器
     */
    public void start() {
        try {
            serverSocket = new ServerSocket(port);
            isRunning = true;
            
            System.out.println("游戏服务器启动在端口: " + port);
            System.out.println("等待玩家连接...");
            
            // 启动游戏更新循环
            startGameUpdateLoop();
            
            // 接受客户端连接
            while (isRunning) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    
                    if (connectedClients.size() >= MAX_PLAYERS) {
                        // 服务器已满，拒绝连接
                        clientSocket.close();
                        continue;
                    }
                    
                    String clientId = UUID.randomUUID().toString();
                    ClientHandler clientHandler = new ClientHandler(clientSocket, clientId, this);
                    connectedClients.put(clientId, clientHandler);
                    
                    threadPool.execute(clientHandler);
                    
                    System.out.println("新玩家连接: " + clientId + " (" + connectedClients.size() + "/" + MAX_PLAYERS + ")");
                    
                } catch (IOException e) {
                    if (isRunning) {
                        System.err.println("接受客户端连接时出错: " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("启动服务器失败: " + e.getMessage());
        }
    }
    
    /**
     * 启动游戏更新循环
     */
    private void startGameUpdateLoop() {
        gameUpdateTimer = new Timer();
        gameUpdateTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                updateGame();
            }
        }, 0, 1000 / 60); // 60 FPS
    }
    
    /**
     * 游戏状态更新
     */
    private void updateGame() {
        synchronized (messageQueueLock) {
            // 处理消息队列
            for (NetworkMessage message : messageQueue) {
                processMessage(message);
            }
            messageQueue.clear();
        }
        
        // 发送心跳包
        sendHeartbeat();
    }
    
    /**
     * 处理网络消息
     */
    private void processMessage(NetworkMessage message) {
        switch (message.getType()) {
            case PLAYER_POSITION:
                handlePlayerPosition((PlayerPositionMessage) message);
                break;
            case PLAYER_HEALTH:
                handlePlayerHealth((PlayerHealthMessage) message);
                break;
            case PLAYER_ATTACK:
                broadcastMessage(message, message.getPlayerId());
                break;
            case ARROW_SHOOT:
                broadcastMessage(message, message.getPlayerId());
                break;
            case BOMB_PLACE:
                broadcastMessage(message, message.getPlayerId());
                break;
            case BLOCK_PLACE:
                broadcastMessage(message, message.getPlayerId());
                break;
            case MAP_SYNC:
                handleMapSync((MapSyncMessage) message);
                break;
            default:
                break;
        }
    }
    
    /**
     * 处理玩家位置更新
     */
    private void handlePlayerPosition(PlayerPositionMessage message) {
        PlayerState state = playerStates.get(message.getPlayerId());
        if (state != null) {
            state.updatePosition(message.worldX, message.worldY, message.velocityX, message.velocityY);
            state.updateState(message.isMoving, message.isJumping, message.isFalling, message.direction, message.animationState);
        }
        
        // 广播给其他玩家
        broadcastMessage(message, message.getPlayerId());
    }
    
    /**
     * 处理玩家生命值更新
     */
    private void handlePlayerHealth(PlayerHealthMessage message) {
        PlayerState state = playerStates.get(message.getPlayerId());
        if (state != null) {
            state.updateHealth(message.health);
        }
        
        // 广播给其他玩家
        broadcastMessage(message, message.getPlayerId());
    }
    
    /**
     * 处理地图同步消息
     * 接收地图数据并广播给所有其他玩家
     */
    private void handleMapSync(MapSyncMessage message) {
        System.out.println("服务器接收到地图同步消息，来自玩家: " + message.getPlayerId());
        System.out.println("地图大小: " + message.getMapWidth() + "x" + message.getMapHeight());
        
        // 广播给所有其他玩家
        broadcastMessage(message, message.getPlayerId());
    }
    
    /**
     * 广播消息给所有客户端（除了发送者）
     */
    public void broadcastMessage(NetworkMessage message, String excludeClientId) {
        for (Map.Entry<String, ClientHandler> entry : connectedClients.entrySet()) {
            if (!entry.getKey().equals(excludeClientId)) {
                entry.getValue().sendMessage(message);
            }
        }
    }
    
    /**
     * 发送消息给特定客户端
     */
    public void sendMessageToClient(String clientId, NetworkMessage message) {
        ClientHandler client = connectedClients.get(clientId);
        if (client != null) {
            client.sendMessage(message);
        }
    }
    
    /**
     * 添加消息到处理队列
     */
    public void queueMessage(NetworkMessage message) {
        synchronized (messageQueueLock) {
            messageQueue.add(message);
        }
    }
    
    /**
     * 玩家加入游戏
     */
    public void playerJoined(String clientId, String playerName) {
        // 创建玩家状态
        PlayerState playerState = new PlayerState(clientId, playerName, 500, 500); // 默认出生点
        playerStates.put(clientId, playerState);
        
        // 通知新玩家其他玩家的信息
        for (PlayerState existingPlayer : playerStates.values()) {
            if (!existingPlayer.playerId.equals(clientId)) {
                PlayerJoinMessage joinMsg = new PlayerJoinMessage(
                    existingPlayer.playerId, existingPlayer.playerName,
                    existingPlayer.worldX, existingPlayer.worldY,
                    existingPlayer.health, existingPlayer.maxHealth
                );
                sendMessageToClient(clientId, joinMsg);
            }
        }
        
        // 通知其他玩家新玩家加入
        PlayerJoinMessage newPlayerMsg = new PlayerJoinMessage(
            clientId, playerName, playerState.worldX, playerState.worldY,
            playerState.health, playerState.maxHealth
        );
        broadcastMessage(newPlayerMsg, clientId);
        
        // 发送服务器生成的地形数据给新玩家
        sendMapDataToClient(clientId);
        
        System.out.println("玩家 " + playerName + " 加入游戏");
    }
    
    /**
     * 向客户端发送地图数据
     * @param clientId 客户端ID
     */
    private void sendMapDataToClient(String clientId) {
        if (mapData != null && mapWidth > 0 && mapHeight > 0) {
            try {
                MapSyncMessage mapSyncMessage = new MapSyncMessage(
                    "server",  // 使用"server"作为发送者ID，标识这是服务器生成的地图
                    mapData,
                    mapWidth,
                    mapHeight
                );
                
                // 确保mapWidth和mapHeight字段被正确设置
                mapSyncMessage.setMapWidth(mapWidth);
                mapSyncMessage.setMapHeight(mapHeight);
                
                // 发送地图数据给指定客户端
                ClientHandler client = connectedClients.get(clientId);
                if (client != null) {
                    client.sendMessage(mapSyncMessage);
                    System.out.println("已向客户端 " + clientId + " 发送服务器生成的地图数据，大小: " + mapWidth + "x" + mapHeight);
                }
            } catch (Exception e) {
                System.err.println("发送地图数据时出错: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.err.println("无法发送地图数据：地图数据为空或尺寸无效");
        }
    }
    
    /**
     * 生成地形
     * 使用TerrainGenerator生成地形数据
     */
    private void generateTerrain() {
        try {
            // 创建地形生成器
            main.TerrainGenerator terrainGenerator = new main.TerrainGenerator();
            
            // 设置种子
            main.TerrainGenerator.GenerationConfig config = new main.TerrainGenerator.GenerationConfig();
            config.seed = this.terrainSeed;
            terrainGenerator.setConfig(config);
            
            // 生成地形
            this.mapData = terrainGenerator.generateTerrain(mapWidth, mapHeight);
            System.out.println("服务器已生成地形，大小: " + mapWidth + "x" + mapHeight + ", 种子: " + terrainSeed);
        } catch (Exception e) {
            System.err.println("生成地形时出错: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 玩家离开游戏
     */
    public void playerLeft(String clientId) {
        connectedClients.remove(clientId);
        PlayerState playerState = playerStates.remove(clientId);
        
        if (playerState != null) {
            // 通知其他玩家
            PlayerLeaveMessage leaveMsg = new PlayerLeaveMessage(clientId, "disconnect");
            broadcastMessage(leaveMsg, clientId);
            
            System.out.println("玩家 " + playerState.playerName + " 离开游戏");
        }
    }
    
    /**
     * 发送心跳包
     */
    private void sendHeartbeat() {
        NetworkMessage pingMsg = new NetworkMessage(NetworkMessage.MessageType.PING, "server") {};
        for (ClientHandler client : connectedClients.values()) {
            client.sendMessage(pingMsg);
        }
    }
    
    /**
     * 停止服务器
     */
    public void stop() {
        isRunning = false;
        
        if (gameUpdateTimer != null) {
            gameUpdateTimer.cancel();
        }
        
        // 关闭所有客户端连接
        for (ClientHandler client : connectedClients.values()) {
            client.disconnect();
        }
        
        threadPool.shutdown();
        
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException e) {
            System.err.println("关闭服务器时出错: " + e.getMessage());
        }
        
        System.out.println("服务器已停止");
    }
    
    /**
     * 获取连接的玩家数量
     */
    public int getPlayerCount() {
        return connectedClients.size();
    }
    
    /**
     * 主方法 - 启动独立服务器
     */
    public static void main(String[] args) {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("无效端口号，使用默认端口: " + DEFAULT_PORT);
            }
        }
        
        GameServer server = new GameServer(port);
        
        // 添加关闭钩子
        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
        
        server.start();
    }
}