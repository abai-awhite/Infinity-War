package network;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * 简单Echo客户端
 * 用于测试Echo对接功能，不依赖于GamePanel
 */
public class SimpleEchoClient implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private transient Socket socket;
    private transient ObjectInputStream inputStream;
    private transient ObjectOutputStream outputStream;
    private boolean isConnected = false;
    private String playerId;
    private String playerName;
    private transient ExecutorService messageProcessor;
    private transient Timer heartbeatTimer;
    
    public SimpleEchoClient() {
        this.messageProcessor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * 连接到服务器
     */
    public boolean connect(String serverAddress, int port, String playerName) {
        try {
            this.playerName = playerName;
            socket = new Socket(serverAddress, port);
            
            // 创建输入输出流
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            outputStream.flush();
            inputStream = new ObjectInputStream(socket.getInputStream());
            
            isConnected = true;
            
            // 发送玩家加入消息
            playerId = UUID.randomUUID().toString();
            PlayerJoinMessage joinMessage = new PlayerJoinMessage(
                playerId, playerName, 
                100, 100, // 默认位置
                100, 100  // 默认生命值
            );
            sendMessage(joinMessage);
            
            // 启动消息接收线程
            startMessageReceiver();
            
            // 启动心跳
            startHeartbeat();
            
            System.out.println("成功连接到服务器: " + serverAddress + ":" + port);
            return true;
            
        } catch (IOException e) {
            System.err.println("连接服务器失败: " + e.getMessage());
            disconnect();
            return false;
        }
    }
    
    /**
     * 启动消息接收线程
     */
    private void startMessageReceiver() {
        messageProcessor.execute(() -> {
            try {
                while (isConnected && !socket.isClosed()) {
                    NetworkMessage message = (NetworkMessage) inputStream.readObject();
                    if (message != null) {
                        handleMessage(message);
                    }
                }
            } catch (EOFException e) {
                System.out.println("服务器断开连接");
            } catch (IOException | ClassNotFoundException e) {
                if (isConnected) {
                    System.err.println("接收消息时出错: " + e.getMessage());
                }
            } finally {
                disconnect();
            }
        });
    }
    
    /**
     * 启动心跳机制
     */
    private void startHeartbeat() {
        heartbeatTimer = new Timer();
        heartbeatTimer.scheduleAtFixedRate(new TimerTask() {
            private static final long serialVersionUID = 1L;
            @Override
            public void run() {
                if (isConnected) {
                    PongMessage pongMsg = new PongMessage(playerId);
                    sendMessage(pongMsg);
                }
            }
        }, 5000, 5000); // 每5秒发送一次心跳
    }
    
    /**
     * 处理接收到的消息
     */
    private void handleMessage(NetworkMessage message) {
        switch (message.getType()) {
            case ECHO:
                handleEcho((EchoMessage) message);
                break;
            case PING:
                // 服务器心跳，发送响应
                PongMessage pongMsg = new PongMessage(playerId);
                sendMessage(pongMsg);
                break;
            default:
                System.out.println("收到消息类型: " + message.getType());
                break;
        }
    }
    
    /**
     * 处理Echo消息
     */
    private void handleEcho(EchoMessage message) {
        System.out.println("收到Echo消息: " + message.getMessage());
    }
    
    /**
     * 发送Echo消息
     */
    public void sendEcho(String message) {
        if (isConnected) {
            EchoMessage echoMessage = new EchoMessage(playerId, message);
            sendMessage(echoMessage);
            System.out.println("已发送Echo消息: " + message);
        }
    }
    
    /**
     * 发送消息到服务器
     */
    private void sendMessage(NetworkMessage message) {
        if (isConnected && outputStream != null) {
            try {
                outputStream.writeObject(message);
                outputStream.flush();
            } catch (IOException e) {
                System.err.println("发送消息失败: " + e.getMessage());
                disconnect();
            }
        }
    }
    
    /**
     * 断开连接
     */
    public void disconnect() {
        if (isConnected) {
            isConnected = false;
            
            if (heartbeatTimer != null) {
                heartbeatTimer.cancel();
            }
            
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException e) {
                System.err.println("关闭连接时出错: " + e.getMessage());
            }
            
            messageProcessor.shutdown();
            
            System.out.println("已断开与服务器的连接");
        }
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return isConnected;
    }
    
    /**
     * 获取玩家ID
     */
    public String getPlayerId() {
        return playerId;
    }
    
    /**
     * 获取玩家名称
     */
    public String getPlayerName() {
        return playerName;
    }
}