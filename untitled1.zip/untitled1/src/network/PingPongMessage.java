package network;

/**
 * 心跳消息类
 * 用于客户端和服务器之间的连接保活
 */
public class PingPongMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public PingPongMessage(MessageType type, String playerId) {
        super(type, playerId);
    }
}