package network;

/**
 * 玩家位置同步消息
 * 用于在多人游戏中同步玩家的位置和移动状态
 */
public class PlayerPositionMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public double worldX;
    public double worldY;
    public double velocityX;
    public double velocityY;
    public boolean isMoving;
    public boolean isJumping;
    public boolean isFalling;
    public String direction; // "left", "right", "idle"
    public String animationState; // "walking", "jumping", "idle", "attacking"
    
    public PlayerPositionMessage(String playerId, double worldX, double worldY, 
                               double velocityX, double velocityY, boolean isMoving, 
                               boolean isJumping, boolean isFalling, String direction, 
                               String animationState) {
        super(MessageType.PLAYER_POSITION, playerId);
        this.worldX = worldX;
        this.worldY = worldY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.isMoving = isMoving;
        this.isJumping = isJumping;
        this.isFalling = isFalling;
        this.direction = direction;
        this.animationState = animationState;
    }
}