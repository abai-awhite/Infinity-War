package network;

/**
 * 玩家攻击消息
 * 同步玩家的攻击动作
 */
public class PlayerAttackMessage extends GameActionMessage {
    private static final long serialVersionUID = 1L;
    
    public double attackX;
    public double attackY;
    public double swordAngle;
    public int damage;
    public boolean isChargedAttack;
    public float chargeMultiplier;
    
    public PlayerAttackMessage(String playerId, double attackX, double attackY, 
                             double swordAngle, int damage, boolean isChargedAttack, 
                             float chargeMultiplier) {
        super(MessageType.PLAYER_ATTACK, playerId);
        this.attackX = attackX;
        this.attackY = attackY;
        this.swordAngle = swordAngle;
        this.damage = damage;
        this.isChargedAttack = isChargedAttack;
        this.chargeMultiplier = chargeMultiplier;
    }
}