package network;

import java.util.Scanner;

/**
 * 简单的Echo测试类
 * 用于测试客户端和服务器之间的Echo对接功能
 */
public class SimpleEchoTest {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Echo对接测试程序 ===");
        System.out.println("1. 启动服务器");
        System.out.println("2. 启动客户端");
        System.out.print("请选择: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine(); // 消耗换行符
        
        if (choice == 1) {
            // 启动服务器
            startServer(scanner);
        } else if (choice == 2) {
            // 启动客户端
            startClient(scanner);
        } else {
            System.out.println("无效选择!");
        }
    }
    
    /**
     * 启动服务器
     */
    private static void startServer(Scanner scanner) {
        System.out.print("请输入服务器端口 (默认12345): ");
        String portStr = scanner.nextLine().trim();
        int port = portStr.isEmpty() ? 12345 : Integer.parseInt(portStr);
        
        try {
            // 创建并启动服务器
            GameServer server = new GameServer(port);
            Thread serverThread = new Thread(() -> {
                server.start();
            });
            serverThread.start();
            
            System.out.println("服务器已启动，监听端口: " + port);
            System.out.println("输入 'exit' 停止服务器");
            
            // 等待用户输入exit停止服务器
            while (true) {
                String command = scanner.nextLine();
                if ("exit".equalsIgnoreCase(command)) {
                    server.stop();
                    break;
                }
            }
            
        } catch (Exception e) {
            System.err.println("启动服务器失败: " + e.getMessage());
        }
    }
    
    /**
     * 启动客户端
     */
    private static void startClient(Scanner scanner) {
        System.out.print("请输入服务器地址 (默认localhost): ");
        String serverAddress = scanner.nextLine().trim();
        if (serverAddress.isEmpty()) {
            serverAddress = "localhost";
        }
        
        System.out.print("请输入服务器端口 (默认12345): ");
        String portStr = scanner.nextLine().trim();
        int port = portStr.isEmpty() ? 12345 : Integer.parseInt(portStr);
        
        System.out.print("请输入玩家名称: ");
        String playerName = scanner.nextLine().trim();
        if (playerName.isEmpty()) {
            playerName = "Player" + System.currentTimeMillis() % 1000;
        }
        
        // 创建并连接客户端
        SimpleEchoClient client = new SimpleEchoClient();
        boolean connected = client.connect(serverAddress, port, playerName);
        
        if (connected) {
            System.out.println("已连接到服务器，可以开始发送Echo消息");
            System.out.println("输入消息内容发送Echo，输入 'exit' 退出");
            
            // 循环发送Echo消息
            while (client.isConnected()) {
                String message = scanner.nextLine();
                if ("exit".equalsIgnoreCase(message)) {
                    client.disconnect();
                    break;
                } else {
                    client.sendEcho(message);
                }
            }
        }
    }
}