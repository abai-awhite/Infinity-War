package network;

/**
 * 游戏动作消息基类
 * 用于同步各种游戏动作
 */
public class GameActionMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public GameActionMessage(MessageType type, String playerId) {
        super(type, playerId);
    }
}