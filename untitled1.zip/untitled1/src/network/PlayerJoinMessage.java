package network;

/**
 * 玩家加入游戏消息
 * 当新玩家连接到服务器时发送
 */
public class PlayerJoinMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public String playerName;
    public double spawnX;
    public double spawnY;
    public int health;
    public int maxHealth;
    
    public PlayerJoinMessage(String playerId, String playerName, double spawnX, double spawnY, int health, int maxHealth) {
        super(MessageType.PLAYER_JOIN, playerId);
        this.playerName = playerName;
        this.spawnX = spawnX;
        this.spawnY = spawnY;
        this.health = health;
        this.maxHealth = maxHealth;
    }
}