package network;

import main.GamePanel;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * 网络客户端管理器
 * 处理与游戏服务器的连接和通信
 */
public class NetworkClient implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private transient Socket socket;
    private transient ObjectInputStream inputStream;
    private transient ObjectOutputStream outputStream;
    private boolean isConnected = false;
    private String playerId;
    private String playerName;
    private transient GamePanel gamePanel;
    private transient ExecutorService messageProcessor;
    private transient Timer heartbeatTimer;
    
    // Echo消息相关
    private String lastEchoMessage = "";
    private boolean hasNewEchoMessage = false;
    
    // 其他玩家状态管理
    private transient Map<String, RemotePlayer> remotePlayers;
    private transient Object remotePlayersLock = new Object();
    
    public NetworkClient(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        this.remotePlayers = new ConcurrentHashMap<>();
        this.messageProcessor = Executors.newSingleThreadExecutor();
    }
    
    /**
     * 连接到服务器
     */
    public boolean connect(String serverAddress, int port, String playerName) {
        try {
            this.playerName = playerName;
            socket = new Socket(serverAddress, port);
            
            // 创建输入输出流
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            outputStream.flush();
            inputStream = new ObjectInputStream(socket.getInputStream());
            
            isConnected = true;
            
            // 发送玩家加入消息
            playerId = UUID.randomUUID().toString();
            PlayerJoinMessage joinMessage = new PlayerJoinMessage(
                playerId, playerName, 
                gamePanel.player.worldx, gamePanel.player.worldy,
                gamePanel.player.health, gamePanel.player.maxHealth
            );
            sendMessage(joinMessage);
            
            // 启动消息接收线程
            startMessageReceiver();
            
            // 启动心跳
            startHeartbeat();
            
            System.out.println("成功连接到服务器: " + serverAddress + ":" + port);
            return true;
            
        } catch (IOException e) {
            System.err.println("连接服务器失败: " + e.getMessage());
            disconnect();
            return false;
        }
    }
    
    /**
     * 启动消息接收线程
     */
    private void startMessageReceiver() {
        messageProcessor.execute(() -> {
            try {
                while (isConnected && !socket.isClosed()) {
                    try {
                        NetworkMessage message = (NetworkMessage) inputStream.readObject();
                        if (message != null) {
                            handleMessage(message);
                        }
                    } catch (ClassNotFoundException e) {
                        System.err.println("客户端消息类型错误: " + e.getMessage());
                        e.printStackTrace();
                    } catch (InvalidClassException e) {
                        System.err.println("客户端类序列化版本不匹配: " + e.getMessage());
                        e.printStackTrace();
                        // 继续尝试接收下一条消息
                    } catch (StreamCorruptedException e) {
                        System.err.println("客户端流损坏: " + e.getMessage());
                        e.printStackTrace();
                        // 流已损坏，需要断开连接
                        break;
                    } catch (OptionalDataException e) {
                        System.err.println("客户端通信错误: invalid type code: " + String.format("%02X", e.length));
                        e.printStackTrace();
                        // 继续尝试接收下一条消息
                    } catch (IOException e) {
                        if (e.getMessage() != null && e.getMessage().contains("invalid type code")) {
                            System.err.println("客户端通信错误: " + e.getMessage());
                            // 继续尝试接收下一条消息
                        } else {
                            throw e; // 重新抛出其他IO异常
                        }
                    }
                }
            } catch (EOFException e) {
                System.out.println("服务器断开连接");
            } catch (IOException e) {
                if (isConnected) {
                    System.err.println("接收消息时出错: " + e.getMessage());
                    e.printStackTrace();
                }
            } finally {
                disconnect();
            }
        });
    }
    
    /**
     * 启动心跳机制
     */
    private void startHeartbeat() {
        heartbeatTimer = new Timer();
        heartbeatTimer.scheduleAtFixedRate(new TimerTask() {
            private static final long serialVersionUID = 1L;
            @Override
            public void run() {
                if (isConnected) {
                    // 创建一个静态的心跳消息类，避免匿名内部类序列化问题
                    PongMessage pongMsg = new PongMessage(playerId);
                    sendMessage(pongMsg);
                }
            }
        }, 5000, 5000); // 每5秒发送一次心跳
    }
    
    /**
     * 处理接收到的消息
     */
    private void handleMessage(NetworkMessage message) {
        switch (message.getType()) {
            case PLAYER_JOIN:
                handlePlayerJoin((PlayerJoinMessage) message);
                break;
            case PLAYER_LEAVE:
                handlePlayerLeave((PlayerLeaveMessage) message);
                break;
            case PLAYER_POSITION:
                handlePlayerPosition((PlayerPositionMessage) message);
                break;
            case PLAYER_HEALTH:
                handlePlayerHealth((PlayerHealthMessage) message);
                break;
            case PLAYER_ATTACK:
                handlePlayerAttack((PlayerAttackMessage) message);
                break;
            case ARROW_SHOOT:
                handleArrowShoot((ArrowShootMessage) message);
                break;
            case BOMB_PLACE:
                handleBombPlace((BombPlaceMessage) message);
                break;
            case BLOCK_PLACE:
                handleBlockPlace((BlockActionMessage) message);
                break;
            case MAP_SYNC:
                handleMapSync((MapSyncMessage) message);
                break;
            case ECHO:
                handleEcho((EchoMessage) message);
                break;
            case PING:
                // 服务器心跳，发送响应
                PongMessage pongMsg = new PongMessage(playerId);
                sendMessage(pongMsg);
                break;
            default:
                System.out.println("收到未处理的消息类型: " + message.getType());
                break;
        }
    }
    
    /**
     * 处理玩家加入
     */
    private void handlePlayerJoin(PlayerJoinMessage message) {
        if (!message.getPlayerId().equals(playerId)) {
            synchronized (remotePlayersLock) {
                RemotePlayer remotePlayer = new RemotePlayer(
                    message.getPlayerId(), message.playerName,
                    message.spawnX, message.spawnY,
                    message.health, message.maxHealth
                );
                remotePlayers.put(message.getPlayerId(), remotePlayer);
            }
            System.out.println("玩家 " + message.playerName + " 加入游戏");
        }
    }
    
    /**
     * 处理玩家离开
     */
    private void handlePlayerLeave(PlayerLeaveMessage message) {
        synchronized (remotePlayersLock) {
            RemotePlayer removedPlayer = remotePlayers.remove(message.getPlayerId());
            if (removedPlayer != null) {
                System.out.println("玩家 " + removedPlayer.playerName + " 离开游戏");
            }
        }
    }
    
    /**
     * 处理玩家位置更新
     */
    private void handlePlayerPosition(PlayerPositionMessage message) {
        synchronized (remotePlayersLock) {
            RemotePlayer remotePlayer = remotePlayers.get(message.getPlayerId());
            if (remotePlayer != null) {
                remotePlayer.updatePosition(message.worldX, message.worldY, message.velocityX, message.velocityY);
                remotePlayer.updateState(message.isMoving, message.isJumping, message.isFalling, 
                                       message.direction, message.animationState);
            }
        }
    }
    
    /**
     * 处理玩家生命值更新
     */
    private void handlePlayerHealth(PlayerHealthMessage message) {
        synchronized (remotePlayersLock) {
            RemotePlayer player = remotePlayers.get(message.getPlayerId());
            if (player != null) {
                // 更新玩家生命值
                player.updateHealth(message.health, message.maxHealth);
                System.out.println("玩家 " + player.playerName + " 生命值更新: " + message.health + "/" + message.maxHealth);
            }
        }
    }
    
    /**
     * 处理玩家攻击
     */
    private void handlePlayerAttack(PlayerAttackMessage message) {
        // 在游戏中显示其他玩家的攻击动画
        // 这里可以添加攻击效果的显示逻辑
        System.out.println("玩家 " + message.getPlayerId() + " 发起攻击");
    }
    
    /**
     * 处理箭矢发射
     */
    private void handleArrowShoot(ArrowShootMessage message) {
        // 在游戏中创建其他玩家射出的箭矢
        entity.Arrow arrow = new entity.Arrow(
            message.startX, message.startY,
            message.velocityX, message.velocityY,
            message.damage, 2000, gamePanel
        );
        
        // 将箭矢添加到游戏面板的箭矢列表中
        synchronized(gamePanel.arrows) {
            gamePanel.arrows.add(arrow);
        }
        
        System.out.println("玩家 " + message.getPlayerId() + " 射出箭矢");
    }
    
    /**
     * 处理炸弹放置
     */
    private void handleBombPlace(BombPlaceMessage message) {
        // 在游戏中创建其他玩家放置的炸弹
        entity.Bomb bomb = new entity.Bomb(
            message.worldX, message.worldY,
            message.velocityX, message.velocityY,
            message.damage, message.explosionRadius,
            message.fuseTime, gamePanel
        );
        bomb.bombId = message.bombId;
        
        // 将炸弹添加到游戏面板的炸弹列表中
        synchronized(gamePanel.bombs) {
            gamePanel.bombs.add(bomb);
        }
        
        System.out.println("玩家 " + message.getPlayerId() + " 放置炸弹");
    }
    
    /**
     * 处理方块放置
     */
    private void handleBlockPlace(BlockActionMessage message) {
        // 在游戏地图中放置或移除方块
        if (gamePanel.tilemanager != null && gamePanel.tilemanager.mapnum != null) {
            if (message.tileX >= 0 && message.tileX < gamePanel.maxworldcol &&
                message.tileY >= 0 && message.tileY < gamePanel.maxworldrow) {
                gamePanel.tilemanager.mapnum[message.tileX][message.tileY] = message.blockType;
                System.out.println("玩家 " + message.getPlayerId() + " 在 (" + message.tileX + "," + message.tileY + ") 放置方块");
            }
        }
    }
    
    /**
     * 处理地图同步
     */
    private void handleMapSync(MapSyncMessage message) {
        try {
            // 接收并更新地图数据
            if (gamePanel.tilemanager != null) {
                int mapWidth = message.getMapWidth();
                int mapHeight = message.getMapHeight();
                int[] changedTiles = message.getChangedTiles();
                int[] changedValues = message.getChangedValues();
                int changedCount = message.getChangedCount();
                
                if (changedTiles == null || changedValues == null) {
                    System.err.println("接收到无效的地图数据");
                    return;
                }
                
                // 检查是否是来自服务器的完整地图数据
                if (message.getPlayerId() != null && message.getPlayerId().equals("server")) {
                    System.out.println("接收到服务器生成的地形数据");
                    
                    // 创建二维地图数组
                    int[][] mapData = new int[mapWidth][mapHeight];
                    
                    // 将一维数据转换为二维地图数据
                    for (int i = 0; i < changedCount && i < changedTiles.length && i < changedValues.length; i++) {
                        int index = changedTiles[i];
                        int value = changedValues[i];
                        
                        int y = index / mapWidth;
                        int x = index % mapWidth;
                        
                        if (x >= 0 && x < mapWidth && y >= 0 && y < mapHeight) {
                            mapData[x][y] = value;
                        }
                    }
                    
                    // 使用tilemanager的updateMapData方法更新完整地图
                    gamePanel.tilemanager.updateMapData(mapData, mapWidth, mapHeight);
                    System.out.println("已应用服务器生成的地形数据，地图大小: " + mapWidth + "x" + mapHeight);
                } else {
                    // 处理部分地图更新
                    // 使用tilemanager的updateMapTiles方法更新地图数据
                    gamePanel.tilemanager.updateMapTiles(changedTiles, changedValues, changedCount);
                    System.out.println("已接收地图同步数据，地图大小: " + mapWidth + "x" + mapHeight + ", 更新了 " + changedCount + " 个图块");
                }
            }
        } catch (Exception e) {
            System.err.println("处理地图同步消息时出错: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 处理Echo消息
     */
    private void handleEcho(EchoMessage message) {
        System.out.println("收到Echo消息: " + message.getMessage());
        // 保存最后收到的Echo消息
        lastEchoMessage = message.getMessage();
        hasNewEchoMessage = true;
        // 回复相同的Echo消息
        sendEcho(message.getMessage());
    }
    
    /**
     * 发送玩家位置更新
     */
    public void sendPlayerPosition() {
        if (isConnected && gamePanel.player != null) {
            PlayerPositionMessage message = new PlayerPositionMessage(
                playerId,
                gamePanel.player.worldx, gamePanel.player.worldy,
                gamePanel.player.velocityx, gamePanel.player.velocityy,
                gamePanel.player.isMoving, gamePanel.player.isJumping, gamePanel.player.isFalling,
                gamePanel.player.direction, "idle" // 简化的动画状态
            );
            sendMessage(message);
        }
    }
    
    /**
     * 发送玩家攻击
     */
    public void sendPlayerAttack(double attackX, double attackY, double swordAngle, int damage, boolean isCharged, float chargeMultiplier) {
        if (isConnected) {
            PlayerAttackMessage message = new PlayerAttackMessage(
                playerId, attackX, attackY, swordAngle, damage, isCharged, chargeMultiplier
            );
            sendMessage(message);
        }
    }
    
    /**
     * 发送玩家生命值更新消息
     */
    public void sendPlayerHealth(int health, int maxHealth) {
        if (isConnected) {
            PlayerHealthMessage message = new PlayerHealthMessage(playerId, health, maxHealth);
            sendMessage(message);
        }
    }
    
    /**
     * 发送地图同步消息
     * @param mapData 地图数据
     * @param mapWidth 地图宽度
     * @param mapHeight 地图高度
     */
    public void sendMapSync(int[][] mapData, int mapWidth, int mapHeight) {
        if (isConnected) {
            MapSyncMessage message = new MapSyncMessage(playerId, mapData, mapWidth, mapHeight);
            sendMessage(message);
            System.out.println("已发送地图同步消息，地图大小: " + mapWidth + "x" + mapHeight);
        }
    }
    
    /**
     * 发送箭矢射击
     */
    public void sendArrowShoot(double startX, double startY, double targetX, double targetY, 
                              double velocityX, double velocityY, int damage, String arrowId) {
        if (isConnected) {
            ArrowShootMessage message = new ArrowShootMessage(
                playerId, startX, startY, targetX, targetY, velocityX, velocityY, damage, arrowId
            );
            sendMessage(message);
        }
    }
    
    /**
     * 发送炸弹放置消息
     */
    public void sendBombPlace(entity.Bomb bomb) {
        if (isConnected) {
            BombPlaceMessage message = new BombPlaceMessage(
                playerId, 
                bomb.worldx, 
                bomb.worldy, 
                bomb.velocityX, 
                bomb.velocityY, 
                bomb.damage, 
                bomb.explosionRadius, 
                bomb.fuseTime, 
                bomb.bombId
            );
            sendMessage(message);
        }
    }
    
    /**
     * 发送方块放置
     */
    public void sendBlockPlace(int tileX, int tileY, int blockType) {
        if (isConnected) {
            BlockActionMessage message = new BlockActionMessage(playerId, tileX, tileY, blockType);
            sendMessage(message);
        }
    }
    
    /**
     * 发送Echo消息
     */
    public void sendEcho(String message) {
        if (isConnected) {
            EchoMessage echoMessage = new EchoMessage(playerId, message);
            sendMessage(echoMessage);
            System.out.println("已发送Echo消息: " + message);
        }
    }
    
    /**
     * 发送消息到服务器
     */
    private void sendMessage(NetworkMessage message) {
        if (isConnected && outputStream != null) {
            try {
                outputStream.writeObject(message);
                outputStream.flush();
            } catch (IOException e) {
                System.err.println("发送消息失败: " + e.getMessage());
                disconnect();
            }
        }
    }
    
    /**
     * 断开连接
     */
    public void disconnect() {
        if (isConnected) {
            isConnected = false;
            
            if (heartbeatTimer != null) {
                heartbeatTimer.cancel();
            }
            
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException e) {
                System.err.println("关闭连接时出错: " + e.getMessage());
            }
            
            messageProcessor.shutdown();
            
            synchronized (remotePlayersLock) {
                remotePlayers.clear();
            }
            
            System.out.println("已断开与服务器的连接");
        }
    }
    
    /**
     * 获取其他玩家列表
     */
    public Map<String, RemotePlayer> getRemotePlayers() {
        synchronized (remotePlayersLock) {
            return new HashMap<>(remotePlayers);
        }
    }
    
    /**
     * 检查是否已连接
     */
    public boolean isConnected() {
        return isConnected;
    }
    
    /**
     * 获取玩家ID
     */
    public String getPlayerId() {
        return playerId;
    }
    
    /**
     * 获取玩家名称
     */
    public String getPlayerName() {
        return playerName;
    }
    
    /**
     * 检查是否有新的Echo消息
     */
    public boolean hasNewEchoMessage() {
        if (hasNewEchoMessage) {
            hasNewEchoMessage = false;
            return true;
        }
        return false;
    }
    
    /**
     * 获取最后收到的Echo消息
     */
    public String getLastEchoMessage() {
        return lastEchoMessage;
    }
}