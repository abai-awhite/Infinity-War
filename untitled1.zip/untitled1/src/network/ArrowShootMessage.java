package network;

/**
 * 箭矢发射消息
 * 同步弓箭射击
 */
public class ArrowShootMessage extends GameActionMessage {
    private static final long serialVersionUID = 1L;
    
    public double startX;
    public double startY;
    public double targetX;
    public double targetY;
    public double velocityX;
    public double velocityY;
    public int damage;
    public String arrowId;
    
    public ArrowShootMessage(String playerId, double startX, double startY, 
                           double targetX, double targetY, double velocityX, 
                           double velocityY, int damage, String arrowId) {
        super(MessageType.ARROW_SHOOT, playerId);
        this.startX = startX;
        this.startY = startY;
        this.targetX = targetX;
        this.targetY = targetY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.damage = damage;
        this.arrowId = arrowId;
    }
}