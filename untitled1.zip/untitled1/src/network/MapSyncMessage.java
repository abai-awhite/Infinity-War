package network;

import java.io.Serializable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * 地图同步消息
 * 用于向新连接的客户端发送完整的地图数据
 */
public class MapSyncMessage extends NetworkMessage {
    private static final long serialVersionUID = 2L; // 更新序列化版本号
    
    // 使用transient标记大型数据，避免序列化整个地图
    private transient int[][] fullMapData;
    private int[] changedTiles; // 存储变化的图块索引
    private int[] changedValues; // 存储变化的图块值
    private int changedCount; // 变化的图块数量
    private int mapWidth; // 改为private，使用getter/setter
    private int mapHeight; // 改为private，使用getter/setter
    
    /**
     * 构造函数 - 用于发送完整地图
     * @param playerId 发送者玩家ID
     * @param mapData 地图数据二维数组
     * @param mapWidth 地图宽度
     * @param mapHeight 地图高度
     */
    public MapSyncMessage(String playerId, int[][] mapData, int mapWidth, int mapHeight) {
        super(MessageType.MAP_SYNC, playerId);
        this.fullMapData = mapData;
        this.mapWidth = mapWidth;
        this.mapHeight = mapHeight;
        
        // 只发送前50行和50列的数据作为初始同步，减少数据量
        int limitedWidth = Math.min(50, mapWidth);
        int limitedHeight = Math.min(50, mapHeight);
        
        // 创建变化数组
        changedCount = limitedWidth * limitedHeight;
        changedTiles = new int[changedCount];
        changedValues = new int[changedCount];
        
        // 填充变化数组，确保数组索引不越界
        int index = 0;
        for (int y = 0; y < limitedHeight; y++) {
            for (int x = 0; x < limitedWidth; x++) {
                if (x < mapWidth && y < mapHeight && index < changedCount) {
                    changedTiles[index] = y * mapWidth + x; // 计算一维索引
                    changedValues[index] = mapData[x][y];
                    index++;
                }
            }
        }
    }
    
    /**
     * 获取变化的图块索引
     * @return 变化的图块索引数组
     */
    public int[] getChangedTiles() {
        return changedTiles;
    }
    
    /**
     * 获取变化的图块值
     * @return 变化的图块值数组
     */
    public int[] getChangedValues() {
        return changedValues;
    }
    
    /**
     * 获取变化的图块数量
     * @return 变化的图块数量
     */
    public int getChangedCount() {
        return changedCount;
    }
    
    /**
     * 获取地图宽度
     * @return 地图宽度
     */
    public int getMapWidth() {
        return mapWidth;
    }
    
    /**
     * 获取地图高度
     * @return 地图高度
     */
    public int getMapHeight() {
        return mapHeight;
    }
    
    /**
     * 设置地图宽度
     * @param mapWidth 地图宽度
     */
    public void setMapWidth(int mapWidth) {
        this.mapWidth = mapWidth;
    }
    
    /**
     * 设置地图高度
     * @param mapHeight 地图高度
     */
    public void setMapHeight(int mapHeight) {
        this.mapHeight = mapHeight;
    }
    
    /**
     * 自定义序列化方法
     */
    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject(); // 先调用默认序列化
    }
    
    /**
     * 自定义反序列化方法
     */
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject(); // 先调用默认反序列化
    }
}