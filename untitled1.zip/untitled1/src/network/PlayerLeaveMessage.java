package network;

/**
 * 玩家离开游戏消息
 * 当玩家断开连接时发送
 */
public class PlayerLeaveMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public String reason; // "disconnect", "timeout", "kicked"
    
    public PlayerLeaveMessage(String playerId, String reason) {
        super(MessageType.PLAYER_LEAVE, playerId);
        this.reason = reason;
    }
}