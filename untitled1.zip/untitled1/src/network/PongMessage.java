package network;

/**
 * 心跳响应消息
 * 用于维持客户端与服务器的连接
 */
public class PongMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public PongMessage(String playerId) {
        super(MessageType.PONG, playerId);
    }
}