package network;

/**
 * 方块放置消息
 * 同步方块的放置和破坏
 */
public class BlockActionMessage extends GameActionMessage {
    private static final long serialVersionUID = 1L;
    
    public int tileX;
    public int tileY;
    public int blockType; // 0 = 空气(破坏), 1 = 石头(放置)
    
    public BlockActionMessage(String playerId, int tileX, int tileY, int blockType) {
        super(MessageType.BLOCK_PLACE, playerId);
        this.tileX = tileX;
        this.tileY = tileY;
        this.blockType = blockType;
    }
}