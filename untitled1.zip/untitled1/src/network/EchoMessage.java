package network;

/**
 * Echo消息
 * 用于客户端和服务器之间的echo对接测试
 */
public class EchoMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    private String message;
    
    public EchoMessage(String playerId, String message) {
        super(MessageType.ECHO, playerId);
        this.message = message;
    }
    
    public String getMessage() {
        return message;
    }
}