package network;

/**
 * 炸弹放置消息
 * 用于同步炸弹的放置和爆炸
 */
public class BombPlaceMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public double worldX;
    public double worldY;
    public double velocityX;
    public double velocityY;
    public int damage;
    public int explosionRadius;
    public int fuseTime;
    public String bombId;
    
    public BombPlaceMessage(String playerId, double worldX, double worldY, 
                          double velocityX, double velocityY, int damage, 
                          int explosionRadius, int fuseTime, String bombId) {
        super(MessageType.BOMB_PLACE, playerId);
        this.worldX = worldX;
        this.worldY = worldY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.damage = damage;
        this.explosionRadius = explosionRadius;
        this.fuseTime = fuseTime;
        this.bombId = bombId;
    }
}