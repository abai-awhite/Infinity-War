package network;

import java.util.Scanner;

/**
 * Echo对接测试类
 * 用于测试客户端和服务器之间的Echo通信
 */
public class EchoTest {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请选择启动模式：");
        System.out.println("1. 服务器");
        System.out.println("2. 客户端");
        int choice = scanner.nextInt();
        scanner.nextLine(); // 消耗换行符
        
        if (choice == 1) {
            // 启动服务器
            startServer();
        } else if (choice == 2) {
            // 启动客户端
            System.out.print("请输入服务器地址: ");
            String serverAddress = scanner.nextLine();
            System.out.print("请输入玩家名称: ");
            String playerName = scanner.nextLine();
            startClient(serverAddress, playerName, scanner);
        } else {
            System.out.println("无效选择");
        }
        
        scanner.close();
    }
    
    /**
     * 启动服务器
     */
    private static void startServer() {
        System.out.println("启动Echo服务器...");
        GameServer server = new GameServer(12345);
        
        // 添加关闭钩子
        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
        
        // 启动服务器（这会阻塞当前线程）
        server.start();
    }
    
    /**
     * 启动客户端
     */
    private static void startClient(String serverAddress, String playerName, Scanner scanner) {
        System.out.println("连接到Echo服务器...");
        
        // 使用SimpleEchoClient，不依赖于GamePanel
        SimpleEchoClient client = new SimpleEchoClient();
        
        // 连接到服务器
        boolean connected = client.connect(serverAddress, 12345, playerName);
        
        if (connected) {
            System.out.println("成功连接到服务器!");
            System.out.println("输入消息进行Echo测试，输入'exit'退出");
            
            String input;
            while (true) {
                input = scanner.nextLine();
                if ("exit".equalsIgnoreCase(input)) {
                    break;
                }
                
                // 发送Echo消息
                client.sendEcho(input);
            }
            
            // 断开连接
            client.disconnect();
        } else {
            System.out.println("连接服务器失败");
        }
    }
    
    // 移除未使用的MockGamePanel类，因为我们使用SimpleEchoClient进行测试
}