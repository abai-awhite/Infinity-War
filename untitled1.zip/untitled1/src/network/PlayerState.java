package network;

/**
 * 服务器端玩家状态类
 * 存储和管理玩家在服务器端的状态信息
 */
public class PlayerState {
    public String playerId;
    public String playerName;
    
    // 位置和移动
    public double worldX;
    public double worldY;
    public double velocityX;
    public double velocityY;
    
    // 状态
    public boolean isMoving;
    public boolean isJumping;
    public boolean isFalling;
    public String direction; // "left", "right", "idle"
    public String animationState; // "walking", "jumping", "idle", "attacking"
    
    // 生命值
    public int health;
    public int maxHealth;
    
    // 时间戳
    public long lastUpdateTime;
    
    public PlayerState(String playerId, String playerName, double spawnX, double spawnY) {
        this.playerId = playerId;
        this.playerName = playerName;
        this.worldX = spawnX;
        this.worldY = spawnY;
        this.velocityX = 0;
        this.velocityY = 0;
        this.isMoving = false;
        this.isJumping = false;
        this.isFalling = false;
        this.direction = "idle";
        this.animationState = "idle";
        this.health = 100;
        this.maxHealth = 100;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新玩家位置
     */
    public void updatePosition(double worldX, double worldY, double velocityX, double velocityY) {
        this.worldX = worldX;
        this.worldY = worldY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新玩家状态
     */
    public void updateState(boolean isMoving, boolean isJumping, boolean isFalling, 
                          String direction, String animationState) {
        this.isMoving = isMoving;
        this.isJumping = isJumping;
        this.isFalling = isFalling;
        this.direction = direction;
        this.animationState = animationState;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 更新生命值
     */
    public void updateHealth(int health) {
        this.health = Math.max(0, Math.min(maxHealth, health));
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    /**
     * 检查玩家是否超时（用于清理断线玩家）
     */
    public boolean isTimeout(long timeoutMs) {
        return System.currentTimeMillis() - lastUpdateTime > timeoutMs;
    }
    
    /**
     * 获取玩家状态的字符串表示
     */
    @Override
    public String toString() {
        return String.format("PlayerState{id='%s', name='%s', pos=(%.1f,%.1f), health=%d/%d, state='%s'}",
                playerId, playerName, worldX, worldY, health, maxHealth, animationState);
    }
}