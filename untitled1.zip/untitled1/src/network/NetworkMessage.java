package network;

import java.io.Serializable;

/**
 * 网络消息基类
 * 定义所有网络通信消息的基础结构
 */
public abstract class NetworkMessage implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 统一的网络消息类型枚举
     * 所有网络通信消息类型都在这里定义
     */
    public enum MessageType {
        // 连接相关
        PLAYER_JOIN(100),        // 玩家加入
        PLAYER_LEAVE(101),       // 玩家离开
        PLAYER_LIST(102),        // 玩家列表
        
        // 玩家状态同步
        PLAYER_POSITION(200),    // 玩家位置更新
        PLAYER_HEALTH(201),      // 玩家生命值更新
        PLAYER_ATTACK(202),      // 玩家攻击动作
        PLAYER_ANIMATION(203),   // 玩家动画状态
        
        // 游戏实体同步
        ENEMY_SPAWN(300),        // 敌人生成
        ENEMY_UPDATE(301),       // 敌人状态更新
        ENEMY_DEATH(302),        // 敌人死亡
        
        // 物品和武器
        ARROW_SHOOT(400),        // 箭矢发射
        ARROW_UPDATE(401),       // 箭矢位置更新
        BOMB_PLACE(402),         // 炸弹放置
        BOMB_EXPLODE(403),       // 炸弹爆炸
        BLOCK_PLACE(404),        // 方块放置
        BLOCK_DESTROY(405),      // 方块破坏
        
        // 游戏状态
        GAME_START(500),         // 游戏开始
        GAME_PAUSE(501),         // 游戏暂停
        GAME_RESUME(502),        // 游戏恢复
        MAP_SYNC(503),           // 地图同步
        
        // 系统消息
        PING(900),               // 心跳包
        PONG(901),               // 心跳响应
        ECHO(902),               // Echo消息
        ERROR(999),              // 错误消息
        DISCONNECT(998);         // 断开连接
        
        private final int code;
        
        MessageType(int code) {
            this.code = code;
        }
        
        public int getCode() {
            return code;
        }
        
        public static MessageType fromCode(int code) {
            for (MessageType type : values()) {
                if (type.code == code) {
                    return type;
                }
            }
            throw new IllegalArgumentException("未知的消息类型代码: " + code);
        }
    }
    
    public MessageType type;
    public long timestamp;
    public String playerId;
    
    public NetworkMessage(MessageType type, String playerId) {
        this.type = type;
        this.playerId = playerId;
        this.timestamp = System.currentTimeMillis();
    }
    
    public MessageType getType() {
        return type;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public String getPlayerId() {
        return playerId;
    }
}