package network;

/**
 * 玩家生命值同步消息
 * 用于在多人游戏中同步玩家的生命值状态
 */
public class PlayerHealthMessage extends NetworkMessage {
    private static final long serialVersionUID = 1L;
    
    public int health;
    public int maxHealth;
    
    public PlayerHealthMessage(String playerId, int health, int maxHealth) {
        super(MessageType.PLAYER_HEALTH, playerId);
        this.health = health;
        this.maxHealth = maxHealth;
    }
}