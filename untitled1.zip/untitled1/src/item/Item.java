package item;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * 物品基类
 * 定义所有物品的基本属性和行为
 */
public abstract class Item {
    protected String name;              // 物品名称
    protected String description;       // 物品描述
    protected BufferedImage icon;       // 物品图标
    protected ItemType type;            // 物品类型
    protected int stackSize;            // 最大堆叠数量
    protected boolean consumable;       // 是否可消耗
    
    /**
     * 物品类型枚举
     */
    public enum ItemType {
        WEAPON,     // 武器
        CONSUMABLE, // 消耗品
        MATERIAL,   // 材料
        TOOL        // 工具
    }
    
    /**
     * 构造函数
     */
    public Item(String name, String description, ItemType type, int stackSize, boolean consumable) {
        this.name = name;
        this.description = description;
        this.type = type;
        this.stackSize = stackSize;
        this.consumable = consumable;
    }
    
    /**
     * 使用物品
     */
    public abstract void use();
    
    /**
     * 检查物品是否可以使用
     * 默认实现返回true，子类可以重写此方法
     */
    public boolean canUse() {
        return true;
    }
    
    /**
     * 绘制物品图标
     */
    public void drawIcon(Graphics2D g2, int x, int y, int size) {
        if (icon != null) {
            g2.drawImage(icon, x, y, size, size, null);
        } else {
            // 如果没有图标，绘制默认矩形
            g2.setColor(Color.GRAY);
            g2.fillRect(x, y, size, size);
            g2.setColor(Color.BLACK);
            g2.drawRect(x, y, size, size);
        }
    }
    
    // Getters
    public String getName() { return name; }
    public String getDescription() { return description; }
    public BufferedImage getIcon() { return icon; }
    public ItemType getType() { return type; }
    public int getStackSize() { return stackSize; }
    public boolean isConsumable() { return consumable; }
    
    // Setters
    public void setIcon(BufferedImage icon) { this.icon = icon; }
}