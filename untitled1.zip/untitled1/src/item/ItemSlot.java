package item;

/**
 * 物品栏槽位类
 * 管理单个槽位的物品和数量
 */
public class ItemSlot {
    private Item item;          // 槽位中的物品
    private int quantity;       // 物品数量
    private int maxQuantity;    // 最大数量（基于物品的堆叠大小）
    
    /**
     * 构造函数 - 空槽位
     */
    public ItemSlot() {
        this.item = null;
        this.quantity = 0;
        this.maxQuantity = 0;
    }
    
    /**
     * 构造函数 - 带物品的槽位
     */
    public ItemSlot(Item item, int quantity) {
        this.item = item;
        this.quantity = Math.min(quantity, item != null ? item.getStackSize() : 0);
        this.maxQuantity = item != null ? item.getStackSize() : 0;
    }
    
    /**
     * 添加物品到槽位
     * @param newItem 要添加的物品
     * @param amount 添加数量
     * @return 实际添加的数量
     */
    public int addItem(Item newItem, int amount) {
        if (isEmpty()) {
            // 空槽位，直接添加
            this.item = newItem;
            this.maxQuantity = newItem.getStackSize();
            this.quantity = Math.min(amount, maxQuantity);
            return this.quantity;
        } else if (canStackWith(newItem)) {
            // 可以堆叠
            int spaceLeft = maxQuantity - quantity;
            int actualAdd = Math.min(amount, spaceLeft);
            this.quantity += actualAdd;
            return actualAdd;
        }
        return 0; // 无法添加
    }
    
    /**
     * 从槽位移除物品
     * @param amount 移除数量
     * @return 实际移除的数量
     */
    public int removeItem(int amount) {
        if (isEmpty()) {
            return 0;
        }
        
        int actualRemove = Math.min(amount, quantity);
        quantity -= actualRemove;
        
        if (quantity <= 0) {
            clear();
        }
        
        return actualRemove;
    }
    
    /**
     * 检查是否可以与指定物品堆叠
     */
    public boolean canStackWith(Item otherItem) {
        return !isEmpty() && 
               item.getClass().equals(otherItem.getClass()) && 
               item.getName().equals(otherItem.getName()) &&
               quantity < maxQuantity;
    }
    
    /**
     * 清空槽位
     */
    public void clear() {
        this.item = null;
        this.quantity = 0;
        this.maxQuantity = 0;
    }
    
    /**
     * 检查槽位是否为空
     */
    public boolean isEmpty() {
        return item == null || quantity <= 0;
    }
    
    /**
     * 检查槽位是否已满
     */
    public boolean isFull() {
        return !isEmpty() && quantity >= maxQuantity;
    }
    
    /**
     * 获取剩余空间
     */
    public int getSpaceLeft() {
        return isEmpty() ? 0 : maxQuantity - quantity;
    }
    
    // Getters
    public Item getItem() { return item; }
    public int getQuantity() { return quantity; }
    public int getMaxQuantity() { return maxQuantity; }
    
    // Setters
    public void setItem(Item item) { 
        this.item = item;
        this.maxQuantity = item != null ? item.getStackSize() : 0;
        if (item == null) {
            this.quantity = 0;
        }
    }
    
    public void setQuantity(int quantity) { 
        this.quantity = Math.max(0, Math.min(quantity, maxQuantity));
        if (this.quantity <= 0) {
            clear();
        }
    }
    
    /**
     * 设置物品和数量
     * @param item 物品
     * @param quantity 数量
     */
    public void setItem(Item item, int quantity) {
        this.item = item;
        this.maxQuantity = item != null ? item.getStackSize() : 0;
        this.quantity = item != null ? Math.max(0, Math.min(quantity, maxQuantity)) : 0;
        if (this.quantity <= 0) {
            clear();
        }
    }
}