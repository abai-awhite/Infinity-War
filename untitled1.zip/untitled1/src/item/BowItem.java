package item;

import entity.player;
import entity.Arrow;
import main.GamePanel;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import javax.imageio.ImageIO;
import java.io.IOException;

/**
 * 弓箭武器类
 * 继承自Item，实现远程攻击功能
 */
public class BowItem extends Item {
    private int damage;                 // 弓箭基础伤害
    private int range;                  // 射程
    private int cooldown;               // 冷却时间（帧数）
    private int arrowSpeed;             // 箭矢速度
    private player owner;               // 弓的持有者
    private GamePanel gamePanel;        // 游戏面板引用
    private float chargeMultiplier = 1.0f; // 蓄力伤害倍数
    
    /**
     * 构造函数
     */
    public BowItem(String name, int damage, int range, int cooldown, int arrowSpeed) {
        super(name, "一把可以发射箭矢的弓", ItemType.WEAPON, 1, false);
        this.damage = damage;
        this.range = range;
        this.cooldown = cooldown;
        this.arrowSpeed = arrowSpeed;
        
        loadBowImage();
    }
    
    /**
     * 加载弓的图像
     */
    private void loadBowImage() {
        try {
            // 创建一个简单的弓图标（如果没有图片资源）
            icon = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = icon.createGraphics();
            
            // 绘制简单的弓形状
            g2.setColor(new java.awt.Color(139, 69, 19)); // 棕色
            g2.fillRect(14, 2, 4, 28);  // 弓身
            
            g2.setColor(java.awt.Color.GRAY);
            g2.drawArc(6, 4, 8, 24, 90, 180);   // 左弓臂
            g2.drawArc(18, 4, 8, 24, 270, 180); // 右弓臂
            
            g2.dispose();
        } catch (Exception e) {
            System.err.println("Failed to create bow icon: " + e.getMessage());
        }
    }
    
    /**
     * 设置弓的持有者和游戏面板
     */
    public void setOwner(player owner, GamePanel gamePanel) {
        this.owner = owner;
        this.gamePanel = gamePanel;
    }
    
    /**
     * 使用弓箭（发射箭矢）
     */
    @Override
    public void use() {
        if (owner == null || gamePanel == null) {
            return;
        }
        
        // 检查冷却时间
        if (owner.attackCooldown > 0) {
            return;
        }
        
        // 发射箭矢
        shootArrow();
        
        // 设置冷却时间
        owner.attackCooldown = cooldown;
        
        System.out.println("Bow fired! Arrow shot towards mouse position.");
    }
    
    /**
     * 发射箭矢
     */
    private void shootArrow() {
        // 获取玩家位置
        int playerCenterX = owner.worldx + gamePanel.tileSize / 2;
        int playerCenterY = owner.worldy + gamePanel.tileSize / 2;
        
        // 获取鼠标在屏幕上的位置
        int mouseScreenX = owner.KB.mouseX;
        int mouseScreenY = owner.KB.mouseY;
        
        // 转换为世界坐标
        int mouseWorldX = mouseScreenX + owner.worldx - owner.screenx;
        int mouseWorldY = mouseScreenY + owner.worldy - owner.screeny;
        
        // 计算方向向量
        double deltaX = mouseWorldX - playerCenterX;
        double deltaY = mouseWorldY - playerCenterY;
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        if (distance > 0) {
            // 标准化方向向量
            double dirX = deltaX / distance;
            double dirY = deltaY / distance;
            
            // 计算实际伤害（基础伤害 * 蓄力倍数）
            int actualDamage = (int)(damage * chargeMultiplier);
            
            // 创建箭矢
            Arrow arrow = new Arrow(
                playerCenterX,
                playerCenterY,
                dirX * arrowSpeed,
                dirY * arrowSpeed,
                actualDamage,
                range,
                gamePanel
            );
            
            // 添加到游戏中
            gamePanel.arrows.add(arrow);
        }
    }
    
    /**
     * 检查是否可以使用弓箭
     */
    public boolean canUse() {
        return owner != null && owner.attackCooldown <= 0;
    }
    
    /**
     * 设置蓄力伤害倍数
     */
    public void setChargeMultiplier(float multiplier) {
        this.chargeMultiplier = multiplier;
    }
    
    /**
     * 获取当前实际伤害（基础伤害 * 蓄力倍数）
     */
    public int getActualDamage() {
        return (int)(damage * chargeMultiplier);
    }
    
    // Getters
    public int getDamage() { return damage; }
    public int getRange() { return range; }
    public int getCooldown() { return cooldown; }
    public int getArrowSpeed() { return arrowSpeed; }
    
    // Setters
    public void setDamage(int damage) { this.damage = damage; }
    public void setRange(int range) { this.range = range; }
    public void setCooldown(int cooldown) { this.cooldown = cooldown; }
    public void setArrowSpeed(int arrowSpeed) { this.arrowSpeed = arrowSpeed; }
}