package item;

import entity.player;
import entity.Bomb;
import main.GamePanel;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;

/**
 * 炸弹物品类
 * 继承自Item，实现投掷炸弹功能
 */
public class BombItem extends Item {
    private int damage;                 // 爆炸伤害
    private int explosionRadius;        // 爆炸半径
    private int fuseTime;              // 引信时间（帧数）
    private int throwRange;            // 投掷距离
    private player owner;              // 炸弹的持有者
    private GamePanel gamePanel;       // 游戏面板引用
    
    /**
     * 构造函数
     */
    public BombItem(String name, int damage, int explosionRadius, int fuseTime, int throwRange) {
        super(name, "一个可以投掷的爆炸装置，能够破坏方块", ItemType.CONSUMABLE, 10, true);
        this.damage = damage;
        this.explosionRadius = explosionRadius;
        this.fuseTime = fuseTime;
        this.throwRange = throwRange;
        
        loadBombImage();
    }
    
    /**
     * 加载炸弹的图像
     */
    private void loadBombImage() {
        try {
            // 创建一个简单的炸弹图标
            icon = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = icon.createGraphics();
            
            // 绘制炸弹主体（黑色圆形）
            g2.setColor(Color.BLACK);
            g2.fillOval(6, 10, 20, 20);
            
            // 绘制引信（棕色线条）
            g2.setColor(new Color(139, 69, 19));
            g2.setStroke(new java.awt.BasicStroke(2));
            g2.drawLine(16, 10, 16, 4);
            
            // 绘制火花（红色点）
            g2.setColor(Color.RED);
            g2.fillOval(14, 2, 4, 4);
            
            g2.dispose();
        } catch (Exception e) {
            System.err.println("Failed to create bomb icon: " + e.getMessage());
        }
    }
    
    /**
     * 设置炸弹的持有者和游戏面板
     */
    public void setOwner(player owner, GamePanel gamePanel) {
        this.owner = owner;
        this.gamePanel = gamePanel;
    }
    
    /**
     * 使用炸弹（投掷）
     */
    @Override
    public void use() {
        if (owner == null || gamePanel == null) {
            return;
        }
        
        throwBomb();
    }
    
    /**
     * 投掷炸弹
     */
    private void throwBomb() {
        // 获取鼠标位置
        int mouseX = gamePanel.KB.mouseX;
        int mouseY = gamePanel.KB.mouseY;
        
        // 计算玩家屏幕位置
        int playerScreenX = gamePanel.screenWidth / 2;
        int playerScreenY = gamePanel.screenHeight / 2;
        
        // 计算方向向量
        double deltaX = mouseX - playerScreenX;
        double deltaY = mouseY - playerScreenY;
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        if (distance > 0) {
            // 标准化方向向量
            double dirX = deltaX / distance;
            double dirY = deltaY / distance;
            
            // 创建炸弹在玩家位置
            Bomb bomb = new Bomb(owner.worldx, owner.worldy, damage, explosionRadius, fuseTime, gamePanel);
            
            // 设置投掷速度（基于方向和投掷力度）
            double throwPower = Math.min(distance / 120.0, 2.0); // 降低投掷力度
            double velocityX = dirX * throwPower * 5; // 降低水平速度倍数
            double velocityY = dirY * throwPower * 5 - 3; // 降低垂直速度倍数
            
            bomb.setVelocity(velocityX, velocityY);
            
            // 将炸弹添加到游戏中（这里需要游戏面板支持炸弹列表）
            if (gamePanel.bombs != null) {
                gamePanel.bombs.add(bomb);
                System.out.println("炸弹已投掷，初始速度: (" + velocityX + ", " + velocityY + ")");
                
                // 如果是多人游戏模式，发送炸弹放置消息
                if (gamePanel.isMultiplayer && gamePanel.networkClient != null && gamePanel.networkClient.isConnected()) {
                    gamePanel.networkClient.sendBombPlace(bomb);
                }
            }
        } else {
            // 如果鼠标在玩家正中心，默认向右投掷
            Bomb bomb = new Bomb(owner.worldx, owner.worldy, damage, explosionRadius, fuseTime, gamePanel);
            
            // 设置默认向右的投掷速度
            bomb.setVelocity(8, -5); // 向右投掷，带有向上的初始速度
            
            if (gamePanel.bombs != null) {
                gamePanel.bombs.add(bomb);
                System.out.println("炸弹已向右投掷，初始速度: (8, -5)");
                
                // 如果是多人游戏模式，发送炸弹放置消息
                if (gamePanel.isMultiplayer && gamePanel.networkClient != null && gamePanel.networkClient.isConnected()) {
                    gamePanel.networkClient.sendBombPlace(bomb);
                }
            }
        }
    }
    
    // Getters
    public int getDamage() { return damage; }
    public int getExplosionRadius() { return explosionRadius; }
    public int getFuseTime() { return fuseTime; }
    public int getThrowRange() { return throwRange; }
}