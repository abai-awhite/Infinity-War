package item;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.image.BufferedImage;

/**
 * 方块物品类
 * 表示从地形中破坏获得的方块物品
 */
public class BlockItem extends Item {
    private int tileIndex;  // 对应的图块索引
    
    /**
     * 构造函数
     */
    public BlockItem(String name, int tileIndex) {
        super(name, "从地形中获得的" + name, ItemType.MATERIAL, 64, false);
        this.tileIndex = tileIndex;
        
        createBlockIcon();
    }
    
    /**
     * 创建方块图标
     */
    private void createBlockIcon() {
        icon = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = icon.createGraphics();
        
        // 根据方块类型绘制不同颜色的图标
        Color blockColor = getBlockColor(tileIndex);
        g2.setColor(blockColor);
        g2.fillRect(2, 2, 28, 28);
        
        // 绘制边框
        g2.setColor(Color.BLACK);
        g2.drawRect(2, 2, 28, 28);
        
        // 添加纹理效果
        g2.setColor(blockColor.brighter());
        g2.drawLine(4, 4, 28, 4);
        g2.drawLine(4, 4, 4, 28);
        
        g2.setColor(blockColor.darker());
        g2.drawLine(28, 6, 28, 28);
        g2.drawLine(6, 28, 28, 28);
        
        g2.dispose();
    }
    
    /**
     * 根据图块索引获取颜色
     */
    private Color getBlockColor(int tileIndex) {
        switch (tileIndex) {
            case 1: return Color.GRAY;          // 石头
            case 2: return new Color(139, 69, 19); // 泥土
            case 3: return Color.GREEN;         // 草地
            default: return Color.LIGHT_GRAY;   // 默认
        }
    }
    
    /**
     * 使用方块物品（放置方块）
     */
    @Override
    public void use() {
        // 这里可以实现放置方块的逻辑
        System.out.println("Used " + name + " block item");
    }
    
    /**
     * 获取图块索引
     */
    public int getTileIndex() {
        return tileIndex;
    }
}