package item;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 物品栏管理类
 * 负责管理所有槽位和物品操作
 */
public class Inventory {
    private ItemSlot[] slots;           // 物品槽位数组
    private int size;                   // 物品栏大小
    private int selectedSlot;           // 当前选中的槽位
    private boolean isOpen;             // 物品栏是否打开
    private boolean showFullInventory = false; // 是否显示完整物品栏
    
    // UI相关属性
    private int slotSize = 48;          // 槽位大小
    private int padding = 4;            // 槽位间距
    private int rows = 5;               // 行数
    private int cols = 10;              // 列数
    
    // 鼠标交互相关属性
    private boolean isDragging = false;  // 是否正在拖拽物品
    private Item draggedItem = null;     // 被拖拽的物品
    private int draggedQuantity = 0;     // 被拖拽物品的数量
    private int draggedFromSlot = -1;    // 拖拽物品的原始槽位
    private int mouseX = 0;              // 鼠标X坐标
    private int mouseY = 0;              // 鼠标Y坐标
    
    /**
     * 构造函数
     */
    public Inventory(int size) {
        this.size = size;
        this.slots = new ItemSlot[size];
        this.selectedSlot = 0;
        this.isOpen = false;
        
        // 初始化所有槽位
        for (int i = 0; i < size; i++) {
            slots[i] = new ItemSlot();
        }
    }
    
    /**
     * 添加物品到物品栏
     * @param item 要添加的物品
     * @param quantity 数量
     * @return 实际添加的数量
     */
    public int addItem(Item item, int quantity) {
        int remaining = quantity;
        
        // 首先尝试添加到现有的相同物品槽位
        for (int i = 0; i < size && remaining > 0; i++) {
            if (slots[i].canStackWith(item)) {
                int added = slots[i].addItem(item, remaining);
                remaining -= added;
            }
        }
        
        // 然后尝试添加到空槽位
        for (int i = 0; i < size && remaining > 0; i++) {
            if (slots[i].isEmpty()) {
                int added = slots[i].addItem(item, remaining);
                remaining -= added;
            }
        }
        
        return quantity - remaining; // 返回实际添加的数量
    }
    
    /**
     * 从物品栏移除物品
     * @param slotIndex 槽位索引
     * @param quantity 移除数量
     * @return 实际移除的数量
     */
    public int removeItem(int slotIndex, int quantity) {
        if (slotIndex < 0 || slotIndex >= size) {
            return 0;
        }
        return slots[slotIndex].removeItem(quantity);
    }
    
    /**
     * 获取指定槽位的物品
     */
    public Item getItem(int slotIndex) {
        if (slotIndex < 0 || slotIndex >= size) {
            return null;
        }
        return slots[slotIndex].getItem();
    }
    
    /**
     * 获取指定槽位的数量
     */
    public int getQuantity(int slotIndex) {
        if (slotIndex < 0 || slotIndex >= size) {
            return 0;
        }
        return slots[slotIndex].getQuantity();
    }
    
    /**
     * 检查是否有指定物品
     */
    public boolean hasItem(Class<? extends Item> itemClass) {
        for (ItemSlot slot : slots) {
            if (!slot.isEmpty() && itemClass.isInstance(slot.getItem())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 获取指定物品的总数量
     */
    public int getItemCount(Class<? extends Item> itemClass) {
        int count = 0;
        for (ItemSlot slot : slots) {
            if (!slot.isEmpty() && itemClass.isInstance(slot.getItem())) {
                count += slot.getQuantity();
            }
        }
        return count;
    }
    
    /**
     * 使用当前选中槽位的物品
     */
    public void useSelectedItem() {
        if (selectedSlot >= 0 && selectedSlot < size) {
            ItemSlot slot = slots[selectedSlot];
            if (!slot.isEmpty()) {
                Item item = slot.getItem();
                item.use();
                
                // 如果是消耗品，使用后减少数量
                if (item.isConsumable()) {
                    slot.removeItem(1);
                }
            }
        }
    }
    
    /**
     * 切换物品栏开关状态
     */
    public void toggleInventory() {
        isOpen = !isOpen;
    }
    
    /**
     * 选择下一个槽位
     */
    public void selectNextSlot() {
        selectedSlot = (selectedSlot + 1) % size;
    }
    
    /**
     * 选择上一个槽位
     */
    public void selectPreviousSlot() {
        selectedSlot = (selectedSlot - 1 + size) % size;
    }
    
    /**
     * 设置选中的槽位
     */
    public void setSelectedSlot(int slot) {
        if (slot >= 0 && slot < size) {
            selectedSlot = slot;
        }
    }
    
    /**
     * 切换完整物品栏显示状态
     */
    public void toggleFullInventoryDisplay() {
        showFullInventory = !showFullInventory;
    }
    
    /**
     * 选择指定槽位
     * @param slotIndex 槽位索引（0-9）
     */
    public void selectSlot(int slotIndex) {
        if (slotIndex >= 0 && slotIndex < 10) {
            selectedSlot = slotIndex;
        }
    }
    
    /**
     * 获取当前选中槽位的物品
     * @return 当前选中的物品，如果槽位为空则返回null
     */
    public Item getSelectedItem() {
        if (selectedSlot >= 0 && selectedSlot < slots.length) {
            return slots[selectedSlot].getItem();
        }
        return null;
    }
    
    /**
     * 绘制物品栏UI
     * @param g2 Graphics2D对象
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     */
    public void draw(Graphics2D g2, int screenWidth, int screenHeight) {
        // 绘制快捷栏（总是显示）
        drawHotbar(g2, screenWidth, screenHeight);
        
        // 如果显示完整物品栏，则绘制完整物品栏
        if (showFullInventory) {
            drawFullInventory(g2, screenWidth, screenHeight);
        }
        
        // 绘制拖拽中的物品
        if (isDragging && draggedItem != null) {
            drawDraggedItem(g2);
        }
    }
    
    /**
     * 绘制物品栏UI（带玩家位置）
     * @param g2 Graphics2D对象
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     * @param playerScreenX 玩家屏幕X坐标
     * @param playerScreenY 玩家屏幕Y坐标
     */
    public void draw(Graphics2D g2, int screenWidth, int screenHeight, int playerScreenX, int playerScreenY) {
        // 绘制缩小的快捷栏在玩家头顶
        drawCompactHotbar(g2, playerScreenX, playerScreenY);
        
        // 如果显示完整物品栏，则绘制完整物品栏
        if (showFullInventory) {
            drawFullInventory(g2, screenWidth, screenHeight);
        }
    }
    
    /**
     * 绘制快捷栏
     */
    private void drawHotbar(Graphics2D g2, int screenWidth, int screenHeight) {
        int hotbarSlots = Math.min(cols, size);
        int totalWidth = hotbarSlots * slotSize + (hotbarSlots - 1) * padding;
        int startX = (screenWidth - totalWidth) / 2;
        int startY = screenHeight - slotSize - 20;
        
        for (int i = 0; i < hotbarSlots; i++) {
            int x = startX + i * (slotSize + padding);
            int y = startY;
            
            drawSlot(g2, x, y, i, i == selectedSlot);
        }
    }
    
    /**
     * 绘制缩小的快捷栏在玩家头顶
     */
    private void drawCompactHotbar(Graphics2D g2, int playerScreenX, int playerScreenY) {
        int compactSlotSize = 24; // 缩小的槽位大小
        int compactPadding = 2;   // 缩小的间距
        int hotbarSlots = Math.min(10, size); // 显示前10个槽位
        int totalWidth = hotbarSlots * compactSlotSize + (hotbarSlots - 1) * compactPadding;
        
        // 计算起始位置（玩家头顶居中）
        int startX = playerScreenX + 32 - totalWidth / 2; // 32是玩家宽度的一半
        int startY = playerScreenY - 40; // 在玩家头顶上方40像素
        
        // 绘制半透明背景
        g2.setColor(new Color(0, 0, 0, 120));
        g2.fillRoundRect(startX - 4, startY - 4, totalWidth + 8, compactSlotSize + 8, 8, 8);
        
        // 绘制边框
        g2.setColor(new Color(255, 255, 255, 150));
        g2.drawRoundRect(startX - 4, startY - 4, totalWidth + 8, compactSlotSize + 8, 8, 8);
        
        for (int i = 0; i < hotbarSlots; i++) {
            int x = startX + i * (compactSlotSize + compactPadding);
            int y = startY;
            
            drawCompactSlot(g2, x, y, i, i == selectedSlot, compactSlotSize);
        }
    }
    
    /**
     * 绘制完整物品栏
     */
    private void drawFullInventory(Graphics2D g2, int screenWidth, int screenHeight) {
        int totalWidth = cols * slotSize + (cols - 1) * padding;
        int totalHeight = rows * slotSize + (rows - 1) * padding;
        int startX = (screenWidth - totalWidth) / 2;
        int startY = (screenHeight - totalHeight) / 2;
        
        // 绘制背景
        g2.setColor(new Color(0, 0, 0, 180));
        g2.fillRect(startX - 20, startY - 20, totalWidth + 40, totalHeight + 40);
        
        // 绘制边框
        g2.setColor(Color.WHITE);
        g2.drawRect(startX - 20, startY - 20, totalWidth + 40, totalHeight + 40);
        
        // 绘制所有槽位
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int slotIndex = row * cols + col;
                if (slotIndex >= size) break;
                
                int x = startX + col * (slotSize + padding);
                int y = startY + row * (slotSize + padding);
                
                drawSlot(g2, x, y, slotIndex, slotIndex == selectedSlot);
            }
        }
    }
    
    /**
     * 绘制缩小的单个槽位
     */
    private void drawCompactSlot(Graphics2D g2, int x, int y, int slotIndex, boolean selected, int size) {
        ItemSlot slot = slots[slotIndex];
        
        // 绘制槽位背景
        if (selected) {
            g2.setColor(new Color(255, 255, 0, 150)); // 黄色高亮
        } else {
            g2.setColor(new Color(64, 64, 64, 200));
        }
        g2.fillRoundRect(x, y, size, size, 4, 4);
        
        // 绘制槽位边框
        g2.setColor(selected ? Color.YELLOW : Color.LIGHT_GRAY);
        g2.drawRoundRect(x, y, size, size, 4, 4);
        
        // 绘制物品
        if (!slot.isEmpty()) {
            Item item = slot.getItem();
            item.drawIcon(g2, x + 1, y + 1, size - 2);
            
            // 绘制数量（如果大于1）
            if (slot.getQuantity() > 1) {
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 8)); // 更小的字体
                String quantityText = String.valueOf(slot.getQuantity());
                FontMetrics fm = g2.getFontMetrics();
                int textX = x + size - fm.stringWidth(quantityText) - 1;
                int textY = y + size - 1;
                g2.drawString(quantityText, textX, textY);
            }
        }
    }
    
    /**
     * 绘制单个槽位
     */
    private void drawSlot(Graphics2D g2, int x, int y, int slotIndex, boolean selected) {
        ItemSlot slot = slots[slotIndex];
        
        // 绘制槽位背景
        if (selected) {
            g2.setColor(new Color(255, 255, 0, 100)); // 黄色高亮
        } else {
            g2.setColor(new Color(64, 64, 64, 180));
        }
        g2.fillRect(x, y, slotSize, slotSize);
        
        // 绘制槽位边框
        g2.setColor(selected ? Color.YELLOW : Color.GRAY);
        g2.drawRect(x, y, slotSize, slotSize);
        
        // 绘制物品
        if (!slot.isEmpty()) {
            Item item = slot.getItem();
            item.drawIcon(g2, x + 2, y + 2, slotSize - 4);
            
            // 绘制数量
            if (slot.getQuantity() > 1) {
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 12));
                String quantityText = String.valueOf(slot.getQuantity());
                FontMetrics fm = g2.getFontMetrics();
                int textX = x + slotSize - fm.stringWidth(quantityText) - 2;
                int textY = y + slotSize - 2;
                g2.drawString(quantityText, textX, textY);
            }
        }
    }
    
    // Getters
    public int getSize() { return size; }
    public int getSelectedSlot() { return selectedSlot; }
    public boolean isOpen() { return isOpen; }
    public ItemSlot[] getSlots() { return slots; }
    public boolean isShowingFullInventory() { return showFullInventory; }
    
    // Setters
    public void setOpen(boolean open) { isOpen = open; }
    
    /**
     * 处理鼠标点击事件
     * @param mouseX 鼠标X坐标
     * @param mouseY 鼠标Y坐标
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     */
    public void handleMouseClick(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        if (!showFullInventory) return;
        
        int clickedSlot = getSlotAtPosition(mouseX, mouseY, screenWidth, screenHeight);
        if (clickedSlot != -1) {
            if (isDragging) {
                // 如果正在拖拽，则放置物品
                dropItem(clickedSlot);
            } else {
                // 如果没有拖拽，则开始拖拽
                startDrag(clickedSlot);
            }
        } else if (isDragging) {
            // 点击空白区域，取消拖拽
            cancelDrag();
        }
    }
    
    /**
     * 处理鼠标移动事件
     * @param mouseX 鼠标X坐标
     * @param mouseY 鼠标Y坐标
     */
    public void handleMouseMove(int mouseX, int mouseY) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }
    
    /**
     * 获取指定位置的槽位索引
     * @param mouseX 鼠标X坐标
     * @param mouseY 鼠标Y坐标
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     * @return 槽位索引，如果没有点击到槽位则返回-1
     */
    private int getSlotAtPosition(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        int totalWidth = cols * slotSize + (cols - 1) * padding;
        int totalHeight = rows * slotSize + (rows - 1) * padding;
        int startX = (screenWidth - totalWidth) / 2;
        int startY = (screenHeight - totalHeight) / 2;
        
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int slotIndex = row * cols + col;
                if (slotIndex >= size) break;
                
                int x = startX + col * (slotSize + padding);
                int y = startY + row * (slotSize + padding);
                
                if (mouseX >= x && mouseX <= x + slotSize && 
                    mouseY >= y && mouseY <= y + slotSize) {
                    return slotIndex;
                }
            }
        }
        return -1;
    }
    
    /**
     * 开始拖拽物品
     * @param slotIndex 槽位索引
     */
    private void startDrag(int slotIndex) {
        ItemSlot slot = slots[slotIndex];
        if (!slot.isEmpty()) {
            isDragging = true;
            draggedItem = slot.getItem();
            draggedQuantity = slot.getQuantity();
            draggedFromSlot = slotIndex;
            
            // 从原槽位移除物品
            slot.clear();
            
            System.out.println("Started dragging " + draggedItem.getName() + " x" + draggedQuantity);
        }
    }
    
    /**
     * 放置拖拽的物品
     * @param targetSlot 目标槽位
     */
    private void dropItem(int targetSlot) {
        if (!isDragging || draggedItem == null) return;
        
        ItemSlot slot = slots[targetSlot];
        
        if (slot.isEmpty()) {
            // 目标槽位为空，直接放置
            slot.setItem(draggedItem, draggedQuantity);
            System.out.println("Dropped " + draggedItem.getName() + " x" + draggedQuantity + " to slot " + targetSlot);
        } else if (slot.canStackWith(draggedItem)) {
            // 目标槽位有相同物品，尝试堆叠
            int added = slot.addItem(draggedItem, draggedQuantity);
            int remaining = draggedQuantity - added;
            
            if (remaining > 0) {
                // 如果有剩余，放回原槽位
                slots[draggedFromSlot].setItem(draggedItem, remaining);
                System.out.println("Partially stacked, " + remaining + " returned to original slot");
            }
            System.out.println("Stacked " + added + " " + draggedItem.getName() + " to slot " + targetSlot);
        } else {
            // 目标槽位有不同物品，交换
            Item tempItem = slot.getItem();
            int tempQuantity = slot.getQuantity();
            
            slot.setItem(draggedItem, draggedQuantity);
            slots[draggedFromSlot].setItem(tempItem, tempQuantity);
            
            System.out.println("Swapped items between slots " + draggedFromSlot + " and " + targetSlot);
        }
        
        // 结束拖拽
        endDrag();
    }
    
    /**
     * 取消拖拽，将物品放回原位
     */
    private void cancelDrag() {
        if (isDragging && draggedItem != null) {
            slots[draggedFromSlot].setItem(draggedItem, draggedQuantity);
            System.out.println("Drag cancelled, item returned to original slot");
        }
        endDrag();
    }
    
    /**
     * 结束拖拽状态
     */
    private void endDrag() {
        isDragging = false;
        draggedItem = null;
        draggedQuantity = 0;
        draggedFromSlot = -1;
    }
    
    /**
     * 绘制拖拽中的物品
     * @param g2 Graphics2D对象
     */
    private void drawDraggedItem(Graphics2D g2) {
        if (draggedItem == null) return;
        
        int dragSize = slotSize;
        int x = mouseX - dragSize / 2;
        int y = mouseY - dragSize / 2;
        
        // 绘制半透明背景
        g2.setColor(new Color(255, 255, 255, 100));
        g2.fillRect(x, y, dragSize, dragSize);
        
        // 绘制边框
        g2.setColor(Color.WHITE);
        g2.drawRect(x, y, dragSize, dragSize);
        
        // 绘制物品图标
        draggedItem.drawIcon(g2, x + 2, y + 2, dragSize - 4);
        
        // 绘制数量
        if (draggedQuantity > 1) {
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            String quantityText = String.valueOf(draggedQuantity);
            FontMetrics fm = g2.getFontMetrics();
            int textX = x + dragSize - fm.stringWidth(quantityText) - 2;
            int textY = y + dragSize - 2;
            g2.drawString(quantityText, textX, textY);
        }
    }
}