package item;

import entity.player;
import main.GamePanel;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;

/**
 * 剑武器类
 * 继承自Item，实现近战攻击功能
 */
public class SwordItem extends Item {
    private int damage;                 // 剑的基础伤害
    private int attackRange;            // 攻击范围
    private int cooldown;               // 冷却时间（帧数）
    private player owner;               // 剑的持有者
    private GamePanel gamePanel;        // 游戏面板引用
    private long lastAttackTime = 0;    // 上次攻击时间
    private float chargeMultiplier = 1.0f; // 蓄力伤害倍数
    
    /**
     * 构造函数
     */
    public SwordItem(String name, int damage, int attackRange, int cooldown) {
        super(name, "一把锋利的剑，可以进行近战攻击", ItemType.WEAPON, 1, false);
        this.damage = damage;
        this.attackRange = attackRange;
        this.cooldown = cooldown;
        
        loadSwordImage();
    }
    
    /**
     * 加载剑的图像
     */
    private void loadSwordImage() {
        // 创建一个简单的剑图标
        icon = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = icon.createGraphics();
        
        // 绘制剑柄
        g2.setColor(new Color(139, 69, 19)); // 棕色剑柄
        g2.fillRect(13, 20, 6, 10);
        
        // 绘制护手
        g2.setColor(Color.GRAY);
        g2.fillRect(10, 18, 12, 3);
        
        // 绘制剑身
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillRect(14, 2, 4, 18);
        
        // 绘制剑尖
        int[] xPoints = {16, 14, 18};
        int[] yPoints = {2, 6, 6};
        g2.fillPolygon(xPoints, yPoints, 3);
        
        g2.dispose();
    }
    
    /**
     * 设置剑的持有者
     */
    public void setOwner(player owner, GamePanel gamePanel) {
        this.owner = owner;
        this.gamePanel = gamePanel;
    }
    
    /**
     * 使用剑进行攻击
     */
    @Override
    public void use() {
        if (owner != null && canUse()) {
            performAttack();
            lastAttackTime = System.currentTimeMillis();
        }
    }
    
    /**
     * 执行攻击
     */
    private void performAttack() {
        if (gamePanel == null || owner == null) {
            return;
        }
        
        // 获取玩家位置
        int playerX = owner.worldx + owner.solidarea.x + owner.solidarea.width / 2;
        int playerY = owner.worldy + owner.solidarea.y + owner.solidarea.height / 2;
        
        // 计算实际伤害（基础伤害 * 蓄力倍数）
        int actualDamage = getActualDamage();
        
        // 检查攻击范围内的敌人
        for (int i = 0; i < gamePanel.enemies.size(); i++) {
            entity.enemy enemy = gamePanel.enemies.get(i);
            if (enemy != null) {
                // 计算与敌人的距离
                int enemyX = enemy.worldx + enemy.solidarea.x + enemy.solidarea.width / 2;
                int enemyY = enemy.worldy + enemy.solidarea.y + enemy.solidarea.height / 2;
                
                double distance = Math.sqrt(Math.pow(playerX - enemyX, 2) + Math.pow(playerY - enemyY, 2));
                
                // 如果在攻击范围内，造成伤害
                if (distance <= attackRange) {
                    enemy.takeDamage(actualDamage);
                    System.out.println("剑攻击命中敌人，造成 " + actualDamage + " 点伤害！");
                }
            }
        }
    }
    
    /**
     * 检查是否可以使用剑
     */
    public boolean canUse() {
        return System.currentTimeMillis() - lastAttackTime >= cooldown;
    }
    
    /**
     * 设置蓄力伤害倍数
     */
    public void setChargeMultiplier(float multiplier) {
        this.chargeMultiplier = multiplier;
    }
    
    /**
     * 获取当前实际伤害（基础伤害 * 蓄力倍数）
     */
    public int getActualDamage() {
        return (int)(damage * chargeMultiplier);
    }
    
    // Getters
    public int getDamage() { return damage; }
    public int getAttackRange() { return attackRange; }
    public int getCooldown() { return cooldown; }
}