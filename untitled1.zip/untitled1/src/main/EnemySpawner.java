package main;

import entity.enemy;
import java.util.ArrayList;
import java.util.Random;

/**
 * 怪物生成管理器类
 * 负责自动生成和管理游戏中的怪物
 * 包括生成时间控制、位置选择、数量限制等功能
 */
public class EnemySpawner {
    private GamePanel gp;
    private Random random;
    
    // 生成参数
    private int maxEnemies = 6;             // 最大怪物数量
    private int spawnInterval = 120;         // 生成间隔（帧数，约2秒）
    private int spawnTimer = 0;              // 生成计时器
    private int minDistanceFromPlayer = 500; // 与玩家的最小距离（缩短）
    private int maxDistanceFromPlayer = 1000; // 与玩家的最大距离（缩短）
    private int despawnDistance = 3000;       // 敌人被清理的距离阈值
    
    // 地图边界设置
    private int spawnMargin = 100;           // 距离地图边缘的最小距离（缩短）
    
    /**
     * 构造函数
     * @param gp 游戏面板引用
     */
    public EnemySpawner(GamePanel gp) {
        this.gp = gp;
        this.random = new Random();
    }
    
    /**
     * 更新生成器状态
     * 在每帧中调用，处理怪物生成逻辑
     * 使用概率刷怪机制
     */
    public void update() {
        // 清理距离玩家太远的敌人
        cleanupDistantEnemies();
        
        // 检查是否需要生成新怪物
        if (gp.enemies.size() < maxEnemies) {
            // 概率刷怪：每帧有一定概率生成怪物
            // 基础概率为0.1%，当怪物数量较少时概率增加
            double baseSpawnChance = 0.001; // 0.1%基础概率
            double enemyCountFactor = 1.0 - ((double)gp.enemies.size() / maxEnemies);
            double finalSpawnChance = baseSpawnChance * (1.0 + enemyCountFactor * 2.0);
            
            // 随机判断是否生成怪物
            if (random.nextDouble() < finalSpawnChance) {
                spawnEnemy();
            }
        }
    }
    
    /**
     * 清理距离玩家太远的敌人
     */
    private void cleanupDistantEnemies() {
        synchronized (gp.enemies) {
            gp.enemies.removeIf(enemy -> {
                double distance = getDistanceToPlayer(enemy.worldx, enemy.worldy);
                return distance > despawnDistance;
            });
        }
    }
    
    /**
     * 生成一个新怪物
     */
    private void spawnEnemy() {
        int attempts = 0;
        int maxAttempts = 20; // 减少尝试次数，提高效率
        
        while (attempts < maxAttempts) {
            // 生成随机位置（在玩家附近）
            int spawnX = generateRandomXNearPlayer();
            int spawnY = generateRandomYNearPlayer();
            
            // 检查位置是否合适
            if (isValidSpawnPosition(spawnX, spawnY)) {
                // 创建新怪物并添加到列表
                enemy newEnemy = new enemy(gp, spawnX, spawnY);
                synchronized(gp.enemies) {
                    gp.enemies.add(newEnemy);
                }
                
                System.out.println("Enemy spawned at (" + spawnX + ", " + spawnY + "). Total enemies: " + gp.enemies.size());
                return;
            }
            
            attempts++;
        }
        
        // 如果多次尝试都失败，强制在玩家附近生成
        forceSpawnNearPlayer();
    }
    
    /**
     * 在玩家附近生成随机X坐标
     */
    private int generateRandomXNearPlayer() {
        int playerX = gp.player.worldx;
        int range = maxDistanceFromPlayer - minDistanceFromPlayer;
        int offset = minDistanceFromPlayer + random.nextInt(range);
        
        // 随机选择在玩家左边或右边
        if (random.nextBoolean()) {
            return playerX + offset;
        } else {
            return playerX - offset;
        }
    }
    
    /**
     * 在玩家附近生成随机Y坐标
     */
    private int generateRandomYNearPlayer() {
        int playerY = gp.player.worldy;
        int range = 300; // Y轴范围
        // 只在玩家上方生成，避免生成在地面或墙体中
        return playerY - (50 + random.nextInt(range));
    }
    
    /**
     * 强制在玩家附近生成怪物
     */
    private void forceSpawnNearPlayer() {
        int playerX = gp.player.worldx;
        int playerY = gp.player.worldy;
        
        // 在玩家右侧上方生成
        int spawnX = playerX + minDistanceFromPlayer + 50;
        int spawnY = playerY - 100; // 在玩家上方生成
        
        // 确保在地图范围内
        spawnX = Math.max(spawnMargin, Math.min(spawnX, gp.worldwidth - spawnMargin));
        spawnY = Math.max(spawnMargin, Math.min(spawnY, gp.worldheight - spawnMargin));
        
        enemy newEnemy = new enemy(gp, spawnX, spawnY);
        synchronized(gp.enemies) {
            gp.enemies.add(newEnemy);
        }
        
        System.out.println("Enemy force spawned at (" + spawnX + ", " + spawnY + "). Total enemies: " + gp.enemies.size());
    }
    
    /**
     * 检查生成位置是否有效
     * @param x X坐标
     * @param y Y坐标
     * @return 是否为有效位置
     */
    private boolean isValidSpawnPosition(int x, int y) {
        // 检查与玩家的距离
        double distanceToPlayer = getDistanceToPlayer(x, y);
        if (distanceToPlayer < minDistanceFromPlayer || distanceToPlayer > maxDistanceFromPlayer) {
            return false;
        }
        
        // 检查是否与现有怪物重叠
        for (enemy existingEnemy : gp.enemies) {
            double distanceToEnemy = getDistance(x, y, existingEnemy.worldx, existingEnemy.worldy);
            if (distanceToEnemy < 80) { // 怪物之间最小距离
                return false;
            }
        }
        
        // 检查是否在地图范围内
        if (x < spawnMargin || y < spawnMargin || 
            x > gp.worldwidth - spawnMargin || y > gp.worldheight - spawnMargin) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 计算与玩家的距离
     */
    private double getDistanceToPlayer(int x, int y) {
        int dx = gp.player.worldx - x;
        int dy = gp.player.worldy - y;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * 计算两点之间的距离
     */
    private double getDistance(int x1, int y1, int x2, int y2) {
        int dx = x2 - x1;
        int dy = y2 - y1;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * 设置最大怪物数量
     */
    public void setMaxEnemies(int maxEnemies) {
        this.maxEnemies = Math.max(1, maxEnemies);
    }
    
    /**
     * 设置生成间隔
     */
    public void setSpawnInterval(int frames) {
        this.spawnInterval = Math.max(30, frames); // 最小0.5秒
    }
    
    /**
     * 设置与玩家的距离范围
     */
    public void setPlayerDistanceRange(int minDistance, int maxDistance) {
        this.minDistanceFromPlayer = Math.max(50, minDistance);
        this.maxDistanceFromPlayer = Math.max(minDistance + 50, maxDistance);
    }
    
    /**
     * 获取当前怪物数量
     */
    public int getCurrentEnemyCount() {
        return gp.enemies.size();
    }
    
    /**
     * 获取最大怪物数量
     */
    public int getMaxEnemies() {
        return maxEnemies;
    }
    
    /**
     * 立即生成一个怪物（用于测试或特殊情况）
     */
    public void forceSpawn() {
        if (gp.enemies.size() < maxEnemies) {
            forceSpawnNearPlayer();
        }
    }
    
    /**
     * 清除所有怪物
     */
    public void clearAllEnemies() {
        gp.enemies.clear();
        System.out.println("All enemies cleared");
    }
}