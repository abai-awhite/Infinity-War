package main;

import javax.swing.*;
import java.awt.*;

/**
 * 游戏主类
 * 程序的入口点，负责创建和配置游戏窗口
 * 初始化游戏面板并启动游戏循环
 */
public class Main {
    /**
     * 程序入口方法
     * 创建游戏窗口，设置窗口属性，添加游戏面板并启动游戏
     * @param args 命令行参数（未使用）
     */
    public static void main(String[] args){
        // 创建主窗口
        JFrame window = new JFrame();
        
        // 设置窗口关闭操作（点击X按钮时退出程序）
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // 禁用窗口大小调整（注释掉，允许调整大小）
        //window.setResizable(false);
        
        // 设置窗口标题
        window.setTitle("无限战争");

        // 创建游戏面板实例
        GamePanel gamePanel = new GamePanel();
        
        // 将游戏面板添加到窗口中
        window.add(gamePanel);

        // 调整窗口大小以适应游戏面板的首选尺寸
        window.pack();

        // 将窗口居中显示在屏幕上
        window.setLocationRelativeTo(null);
        
        // 显示窗口
        window.setVisible(true);

        // 启动游戏主循环线程
        gamePanel.startGameThread();
    }
}