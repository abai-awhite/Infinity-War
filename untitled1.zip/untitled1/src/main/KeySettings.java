package main;

import java.awt.event.KeyEvent;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 按键设置管理类
 * 负责管理游戏中所有按键绑定的配置、保存和加载
 */
public class KeySettings {
    private static KeySettings instance;
    private Map<String, Integer> keyBindings;
    private final String CONFIG_FILE = "keysettings.properties";
    
    // 按键动作常量
    public static final String MOVE_UP = "move_up";
    public static final String MOVE_DOWN = "move_down";
    public static final String MOVE_LEFT = "move_left";
    public static final String MOVE_RIGHT = "move_right";
    public static final String JUMP = "jump";
    public static final String RUN = "run";
    public static final String SPRINT = "sprint";
    public static final String INVENTORY = "inventory";
    public static final String MENU_UP = "menu_up";
    public static final String MENU_DOWN = "menu_down";
    public static final String CONFIRM = "confirm";
    public static final String ITEM_1 = "item_1";
    public static final String ITEM_2 = "item_2";
    public static final String ITEM_3 = "item_3";
    public static final String ITEM_4 = "item_4";
    public static final String ITEM_5 = "item_5";
    public static final String ITEM_6 = "item_6";
    public static final String ITEM_7 = "item_7";
    public static final String ITEM_8 = "item_8";
    public static final String ITEM_9 = "item_9";
    
    private KeySettings() {
        keyBindings = new HashMap<>();
        setDefaultKeyBindings();
        loadSettings();
    }
    
    /**
     * 获取单例实例
     */
    public static KeySettings getInstance() {
        if (instance == null) {
            instance = new KeySettings();
        }
        return instance;
    }
    
    /**
     * 设置默认按键绑定
     */
    private void setDefaultKeyBindings() {
        keyBindings.put(MOVE_UP, KeyEvent.VK_W);
        keyBindings.put(MOVE_DOWN, KeyEvent.VK_S);
        keyBindings.put(MOVE_LEFT, KeyEvent.VK_A);
        keyBindings.put(MOVE_RIGHT, KeyEvent.VK_D);
        keyBindings.put(JUMP, KeyEvent.VK_SPACE);
        keyBindings.put(RUN, KeyEvent.VK_SHIFT);
        keyBindings.put(SPRINT, KeyEvent.VK_CONTROL);
        keyBindings.put(INVENTORY, KeyEvent.VK_E);
        keyBindings.put(MENU_UP, KeyEvent.VK_UP);
        keyBindings.put(MENU_DOWN, KeyEvent.VK_DOWN);
        keyBindings.put(CONFIRM, KeyEvent.VK_ENTER);
        keyBindings.put(ITEM_1, KeyEvent.VK_1);
        keyBindings.put(ITEM_2, KeyEvent.VK_2);
        keyBindings.put(ITEM_3, KeyEvent.VK_3);
        keyBindings.put(ITEM_4, KeyEvent.VK_4);
        keyBindings.put(ITEM_5, KeyEvent.VK_5);
        keyBindings.put(ITEM_6, KeyEvent.VK_6);
        keyBindings.put(ITEM_7, KeyEvent.VK_7);
        keyBindings.put(ITEM_8, KeyEvent.VK_8);
        keyBindings.put(ITEM_9, KeyEvent.VK_9);
    }
    
    /**
     * 获取指定动作的按键码
     */
    public int getKeyCode(String action) {
        return keyBindings.getOrDefault(action, KeyEvent.VK_UNDEFINED);
    }
    
    /**
     * 设置指定动作的按键码
     */
    public void setKeyCode(String action, int keyCode) {
        keyBindings.put(action, keyCode);
    }
    
    /**
     * 获取按键码对应的动作名称
     */
    public String getActionForKey(int keyCode) {
        for (Map.Entry<String, Integer> entry : keyBindings.entrySet()) {
            if (entry.getValue() == keyCode) {
                return entry.getKey();
            }
        }
        return null;
    }
    
    /**
     * 检查按键是否已被绑定
     */
    public boolean isKeyBound(int keyCode) {
        return keyBindings.containsValue(keyCode);
    }
    
    /**
     * 获取按键的显示名称
     */
    public String getKeyDisplayName(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_SPACE: return "空格";
            case KeyEvent.VK_SHIFT: return "Shift";
            case KeyEvent.VK_CONTROL: return "Ctrl";
            case KeyEvent.VK_TAB: return "Tab";
            case KeyEvent.VK_ENTER: return "回车";
            case KeyEvent.VK_UP: return "↑";
            case KeyEvent.VK_DOWN: return "↓";
            case KeyEvent.VK_LEFT: return "←";
            case KeyEvent.VK_RIGHT: return "→";
            case KeyEvent.VK_1: return "1";
            case KeyEvent.VK_2: return "2";
            case KeyEvent.VK_3: return "3";
            case KeyEvent.VK_4: return "4";
            case KeyEvent.VK_5: return "5";
            case KeyEvent.VK_6: return "6";
            case KeyEvent.VK_7: return "7";
            case KeyEvent.VK_8: return "8";
            case KeyEvent.VK_9: return "9";
            default:
                if (keyCode >= KeyEvent.VK_A && keyCode <= KeyEvent.VK_Z) {
                    return String.valueOf((char) keyCode);
                }
                return KeyEvent.getKeyText(keyCode);
        }
    }
    
    /**
     * 获取动作的显示名称
     */
    public String getActionDisplayName(String action) {
        switch (action) {
            case MOVE_UP: return "向上移动";
            case MOVE_DOWN: return "向下移动";
            case MOVE_LEFT: return "向左移动";
            case MOVE_RIGHT: return "向右移动";
            case JUMP: return "跳跃";
            case RUN: return "跑步";
            case SPRINT: return "冲刺";
            case INVENTORY: return "物品栏";
            case MENU_UP: return "菜单向上";
            case MENU_DOWN: return "菜单向下";
            case CONFIRM: return "确认";
            case ITEM_1: return "物品槽1";
            case ITEM_2: return "物品槽2";
            case ITEM_3: return "物品槽3";
            case ITEM_4: return "物品槽4";
            case ITEM_5: return "物品槽5";
            case ITEM_6: return "物品槽6";
            case ITEM_7: return "物品槽7";
            case ITEM_8: return "物品槽8";
            case ITEM_9: return "物品槽9";
            default: return action;
        }
    }
    
    /**
     * 保存设置到文件
     */
    public void saveSettings() {
        Properties props = new Properties();
        for (Map.Entry<String, Integer> entry : keyBindings.entrySet()) {
            props.setProperty(entry.getKey(), entry.getValue().toString());
        }
        
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Key Settings Configuration");
        } catch (IOException e) {
            System.err.println("无法保存按键设置: " + e.getMessage());
        }
    }
    
    /**
     * 从文件加载设置
     */
    public void loadSettings() {
        File configFile = new File(CONFIG_FILE);
        if (!configFile.exists()) {
            return; // 使用默认设置
        }
        
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
            for (String key : props.stringPropertyNames()) {
                try {
                    int keyCode = Integer.parseInt(props.getProperty(key));
                    keyBindings.put(key, keyCode);
                } catch (NumberFormatException e) {
                    System.err.println("无效的按键配置: " + key + " = " + props.getProperty(key));
                }
            }
        } catch (IOException e) {
            System.err.println("无法加载按键设置: " + e.getMessage());
        }
    }
    
    /**
     * 重置为默认设置
     */
    public void resetToDefaults() {
        keyBindings.clear();
        setDefaultKeyBindings();
    }
    
    /**
     * 获取所有按键绑定的副本
     */
    public Map<String, Integer> getAllKeyBindings() {
        return new HashMap<>(keyBindings);
    }
}