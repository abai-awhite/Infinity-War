package main;

import entity.player;
import entity.enemy;
import entity.Arrow;
import entity.Bomb;
import tile.tilemanager;
import main.EnemySpawner;
import item.Inventory;
import item.BowItem;
import item.SwordItem;
import item.BombItem;
import item.BlockItem;
import network.NetworkClient;
import network.RemotePlayer;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/**
 * 游戏主面板类
 * 继承自JPanel并实现Runnable接口，负责游戏的核心逻辑
 * 包括游戏循环、渲染、更新和事件处理
 */
public class GamePanel extends JPanel implements Runnable {
    // 基础图块尺寸设置
    final int originalTileSize = 64; // 原始图块大小为64x64像素
    final int scale = 1; // 缩放比例为1倍（不缩放）

    // 计算实际图块大小（考虑缩放）
    public final int tileSize = originalTileSize * scale;
    // 屏幕可容纳的最大图块列数
    public final int maxScreenCol = 30;
    // 屏幕可容纳的最大图块行数
    public final int maxScreenRow = 17;
    // 计算屏幕宽度（像素）
    public final int screenWidth = tileSize * maxScreenCol;
    // 计算屏幕高度（像素）
    public final int screenHeight = tileSize * maxScreenRow;

    public final int maxworldcol = 999;
    public final int maxworldrow = 999;
    public final int worldwidth = tileSize * maxworldcol;
    public final int worldheight = tileSize * maxworldrow;

    // 帧率设置
    int FPS = 240; // 目标帧率为240帧/秒

    // 游戏管理器实例
    public tilemanager tilemanager = new tilemanager(this);
    // 键盘输入处理器
    public KeyBoard KB = new KeyBoard();
    // 游戏主线程
    Thread gameThread;
    public pengzhuang checker = new pengzhuang(this);
    // AABB碰撞检测系统
    public AABBCollisionSystem aabbCollisionSystem = new AABBCollisionSystem(this);
    // 玩家实例
    public player player = new player(this, KB);
    // 敌人列表
    public ArrayList<enemy> enemies = new ArrayList<>();
    // 箭矢列表
    public ArrayList<Arrow> arrows = new ArrayList<>();
    // 炸弹列表
    public ArrayList<Bomb> bombs = new ArrayList<>();
    // 敌人生成器
    private EnemySpawner enemySpawner;
    // 物品栏系统
    public Inventory inventory = new Inventory(50);
    // 跟踪上次更新时间
    private long lastUpdateTime = System.currentTimeMillis();
    
    // 游戏状态管理
    public enum GameState {
        START_SCREEN,
        PLAYING,
        PAUSED
    }
    
    public GameState gameState = GameState.START_SCREEN;
    private StartScreen startScreen;
    private PauseScreen pauseScreen;
    
    // 网络相关
    public NetworkClient networkClient;
    public boolean isMultiplayer = false;
    private long lastNetworkUpdate = 0;
    private final long NETWORK_UPDATE_INTERVAL = 50; // 每50ms发送一次位置更新
    
    // 服务器相关
    private network.GameServer gameServer;
    
    // 存档管理
    public SaveManager saveManager;

    /**
     * 构造函数：初始化游戏面板
     * 设置面板属性、输入监听和渲染优化
     */
    public GamePanel() {
        // 设置面板首选尺寸
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        // 设置背景颜色为黑色
        this.setBackground(Color.black);
        // 启用双缓冲以减少闪烁
        this.setDoubleBuffered(true);
        // 添加键盘监听器
        this.addKeyListener(KB);
        // 添加鼠标监听器
        this.addMouseListener(KB);
        // 添加鼠标移动监听器
        this.addMouseMotionListener(KB);
        // 添加鼠标滚轮监听器
        this.addMouseWheelListener(KB);
        // 设置面板为可获得焦点，以便接收键盘输入
        this.setFocusable(true);
        
        // 初始化存档管理器
        saveManager = new SaveManager(this);
        
        // 初始化开始页面
        startScreen = new StartScreen(this);
        pauseScreen = new PauseScreen(saveManager);
        
        // 初始化敌人生成器
        enemySpawner = new EnemySpawner(this);
        
        // 初始化物品栏
        initializeInventory();
        
        // 初始化网络客户端
        networkClient = new NetworkClient(this);
    }

    /**
     * /**
     * 启动游戏线程
     */
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    /**
     * 开始游戏（从开始页面切换到游戏状态）
     */
    public void startGame() {
        gameState = GameState.PLAYING;
        // 初始化敌人（延迟到游戏开始时）
        initializeEnemies();
    }
    
    /**
     * 开始联机游戏
     */
    public void startMultiplayerGame(String serverAddress, int port, String playerName) {
        if (networkClient.connect(serverAddress, port, playerName)) {
            isMultiplayer = true;
            gameState = GameState.PLAYING;
            // 联机模式下不生成敌人，由服务器管理
            System.out.println("成功连接到多人游戏服务器");
            
            // 在联机模式下，地形由服务器生成
            // 客户端将等待接收服务器发送的地图数据
            System.out.println("等待接收服务器生成的地形数据...");
        } else {
            System.err.println("连接多人游戏服务器失败");
        }
    }
    
    /**
     * 断开联机连接
     */
    public void disconnectMultiplayer() {
        if (isMultiplayer && networkClient != null) {
            networkClient.disconnect();
            isMultiplayer = false;
            System.out.println("已断开多人游戏连接");
        }
    }
    
    /**
     * 启动游戏服务器
     * @param port 服务器端口
     * @return 是否成功启动服务器
     */
    public boolean startServer(int port) {
        try {
            // 如果已有服务器实例，先停止它
            if (gameServer != null) {
                gameServer.stop();
            }
            
            // 创建新的服务器实例
            gameServer = new network.GameServer(port);
            
            // 在新线程中启动服务器
            Thread serverThread = new Thread(() -> {
                gameServer.start();
            });
            serverThread.setDaemon(true); // 设置为守护线程，这样主程序退出时，服务器线程也会退出
            serverThread.start();
            
            System.out.println("服务器已在端口 " + port + " 上启动（在独立线程中运行）");
            return true;
        } catch (Exception e) {
            System.err.println("启动服务器失败: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 停止游戏服务器
     */
    public void stopServer() {
        if (gameServer != null) {
            gameServer.stop();
            gameServer = null;
            System.out.println("服务器已停止");
        }
    }

    // 游戏主循环
    public void run() {
        // 计算每帧的理想时间（毫秒）
        double drawInterval = (double) 1000 / FPS;
        // 设置下一帧的绘制时间
        double nextDrawTime = System.currentTimeMillis() + drawInterval;

        // 游戏主循环
        while (gameThread != null) {
            // 更新游戏状态
            update();
            // 重绘游戏画面
            repaint();

            try {
                // 计算剩余时间直到下一帧
                double remainingTime = nextDrawTime - System.currentTimeMillis();
                // 确保剩余时间不为负
                if (remainingTime < 0) {
                    remainingTime = 0;
                }
                // 线程休眠，控制帧率
                Thread.sleep((long) remainingTime);
                // 更新下一帧的绘制时间
                nextDrawTime += drawInterval;
            } catch (InterruptedException e) {
                // 异常处理：打印错误信息
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 初始化敌人
     * 在游戏开始时创建敌人实例
     */
    private void initializeEnemies() {
        // 创建少量初始敌人，让EnemySpawner负责后续生成
        enemies.add(new enemy(this, 500, 800));   // 敌人1
        enemies.add(new enemy(this, 1200, 600));  // 敌人2
        
        System.out.println("Initial enemies created: " + enemies.size());
        System.out.println("EnemySpawner will automatically generate more enemies...");
    }
    
    /**
     * 初始化物品栏
     * 添加默认物品
     */
    private void initializeInventory() {
        // 创建一把弓并添加到物品栏
        BowItem bow = new BowItem("基础弓", 5, 2000, 20, 6);
        bow.setOwner(player, this);
        inventory.addItem(bow, 1);
        
        // 创建一把剑并添加到物品栏
        SwordItem sword = new SwordItem("铁剑", 5, 120, 500);
        sword.setOwner(player, this);
        inventory.addItem(sword, 1);
        
        // 创建炸弹并添加到物品栏
        BombItem bomb = new BombItem("炸弹", 50, 3, 1200, 500);
        bomb.setOwner(player, this);
        inventory.addItem(bomb, 5);
        
        // 添加方块物品到物品栏
        item.BlockItem stoneBlock = new item.BlockItem("石头", 1);
        inventory.addItem(stoneBlock, 10);
        
        System.out.println("Inventory initialized with basic bow, iron sword, bombs and blocks");
    }
    
    /**
     * 更新游戏状态
     * 在每一帧中调用，更新所有游戏对象的状态
     */
    public void update() {
        // 处理ESC键暂停功能（在游戏进行状态下）
        if (gameState == GameState.PLAYING && KB.escPressed) {
            gameState = GameState.PAUSED;
            KB.escPressed = false; // 重置ESC键状态
        } else if (gameState == GameState.PAUSED && KB.escPressed) {
            gameState = GameState.PLAYING;
            KB.escPressed = false; // 重置ESC键状态
        }
        
        // 根据游戏状态执行不同的更新逻辑
        switch (gameState) {
            case START_SCREEN:
                // 处理开始页面的键盘输入
                handleStartScreenInput();
                break;
            case PLAYING:
                updateGameplay();
                break;
            case PAUSED:
                // 暂停状态下处理暂停菜单输入
                handlePauseScreenInput();
                break;
        }
    }
    
    /**
     * 更新游戏玩法相关的所有对象
     */
    private void updateGameplay() {
        // 更新玩家状态（位置、动画、碰撞等）
        player.updata();
        
        // 网络同步逻辑
        if (isMultiplayer && networkClient.isConnected()) {
            updateNetworkSync();
        }
        
        // 更新怪物生成器（单机模式）
        if (!isMultiplayer) {
            enemySpawner.update();
        }
        
        // 更新所有敌人状态
        synchronized(enemies) {
            Iterator<enemy> enemyIterator = enemies.iterator();
            while (enemyIterator.hasNext()) {
                enemy currentEnemy = enemyIterator.next();
                currentEnemy.update();
                
                // 移除死亡的敌人
                if (currentEnemy.isDead()) {
                    enemyIterator.remove();
                }
            }
        }
        
        // 更新所有箭矢状态
        synchronized(arrows) {
            Iterator<Arrow> arrowIterator = arrows.iterator();
            while (arrowIterator.hasNext()) {
                Arrow arrow = arrowIterator.next();
                arrow.update();
                
                // 移除失效的箭矢
                if (arrow.shouldRemove()) {
                    arrowIterator.remove();
                }
            }
        }
        
        // 更新所有炸弹状态
        synchronized(bombs) {
            Iterator<Bomb> bombIterator = bombs.iterator();
            while (bombIterator.hasNext()) {
                Bomb bomb = bombIterator.next();
                bomb.update();
                
                // 移除已爆炸的炸弹
                if (bomb.shouldRemove()) {
                    bombIterator.remove();
                }
            }
        }
        
        // 处理物品栏键盘事件
        handleInventoryInput();
        
        // 处理存档按键
        handleSaveLoadInput();
    }
    
    /**
     * 处理开始页面的键盘和鼠标输入
     */
    private void handleStartScreenInput() {
        // 处理所有按键事件（特别是设置界面的按键绑定）
        if (KB.hasNewKeyPress) {
            startScreen.handleKeyInput(new java.awt.event.KeyEvent(
                this, java.awt.event.KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, 
                KB.lastKeyPressed, java.awt.event.KeyEvent.CHAR_UNDEFINED
            ));
            KB.hasNewKeyPress = false; // 重置按键事件标志
        }
        
        // 处理上箭头键
        if (KB.isUpArrowPressed()) {
            startScreen.handleKeyInput(new java.awt.event.KeyEvent(
                this, java.awt.event.KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, 
                java.awt.event.KeyEvent.VK_UP, java.awt.event.KeyEvent.CHAR_UNDEFINED
            ));
            KB.upArrowPressed = false; // 重置按键状态
        }
        
        // 处理下箭头键
        if (KB.isDownArrowPressed()) {
            startScreen.handleKeyInput(new java.awt.event.KeyEvent(
                this, java.awt.event.KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, 
                java.awt.event.KeyEvent.VK_DOWN, java.awt.event.KeyEvent.CHAR_UNDEFINED
            ));
            KB.downArrowPressed = false; // 重置按键状态
        }
        
        // 处理回车键
        if (KB.isEnterPressed()) {
            startScreen.handleKeyInput(new java.awt.event.KeyEvent(
                this, java.awt.event.KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, 
                java.awt.event.KeyEvent.VK_ENTER, java.awt.event.KeyEvent.CHAR_UNDEFINED
            ));
            KB.enterPressed = false; // 重置按键状态
        }
        
        // 处理空格键（作为确认键）
        if (KB.spacePressed) {
            startScreen.handleKeyInput(new java.awt.event.KeyEvent(
                this, java.awt.event.KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, 
                java.awt.event.KeyEvent.VK_SPACE, java.awt.event.KeyEvent.CHAR_UNDEFINED
            ));
            KB.spacePressed = false; // 重置按键状态
        }
        
        // 处理鼠标点击
        if (KB.attackPressed) {
            java.awt.event.MouseEvent mouseEvent = new java.awt.event.MouseEvent(
                this, java.awt.event.MouseEvent.MOUSE_CLICKED,
                System.currentTimeMillis(), 0,
                KB.mouseX, KB.mouseY, 1, false, java.awt.event.MouseEvent.BUTTON1
            );
            startScreen.handleMouseClick(mouseEvent);
            KB.attackPressed = false; // 重置鼠标点击状态
        }
        
        // 处理鼠标移动（用于按钮高亮）
        java.awt.event.MouseEvent mouseMoveEvent = new java.awt.event.MouseEvent(
            this, java.awt.event.MouseEvent.MOUSE_MOVED,
            System.currentTimeMillis(), 0,
            KB.mouseX, KB.mouseY, 0, false
        );
        startScreen.handleMouseMove(mouseMoveEvent);
    }
    
    /**
     * 处理暂停页面的键盘和鼠标输入
     */
    private void handlePauseScreenInput() {
        int choice = pauseScreen.handleInput(KB, KB.mouseX, KB.mouseY, screenWidth, screenHeight);
        
        switch (choice) {
            case 1: // 继续游戏
                gameState = GameState.PLAYING;
                break;
            case 2: // 保存游戏
                String saveName = pauseScreen.getSelectedSaveName();
                if (saveName != null && !saveName.isEmpty()) {
                    saveGame(saveName);
                }
                break;
            case 3: // 加载游戏
                String loadName = pauseScreen.getSelectedSaveName();
                if (loadName != null && !loadName.isEmpty()) {
                    loadGame(loadName);
                }
                break;
            case 4: // 返回主菜单
                gameState = GameState.START_SCREEN;
                pauseScreen.reset(); // 重置暂停菜单选择
                break;
            case 5: // 退出游戏
                System.exit(0);
                break;
            default:
                // 无操作，继续显示暂停菜单
                break;
        }
    }
    
    /**
     * 处理物品栏相关的键盘输入
     */
    private void handleInventoryInput() {
        // 处理Tab键切换物品栏显示
        if (KB.isTabPressed()) {
            inventory.toggleFullInventoryDisplay();
            KB.tabPressed = false; // 重置Tab键状态
        }
        
        // 处理数字键快速选择槽位
        int numberKey = KB.getNumberKeyPressed();
        if (numberKey != -1) {
            inventory.selectSlot(numberKey);
            KB.resetNumberKeyPressed();
        }
        
        // 处理鼠标滚轮切换槽位
        if (KB.isWheelScrolled()) {
            int wheelRotation = KB.getWheelRotation();
            if (wheelRotation > 0) {
                // 向下滚动，选择下一个槽位
                inventory.selectNextSlot();
            } else if (wheelRotation < 0) {
                // 向上滚动，选择上一个槽位
                inventory.selectPreviousSlot();
            }
            KB.resetWheelState(); // 重置滚轮状态
        }
        
        // 处理鼠标点击物品栏
        if (KB.attackPressed) {
            inventory.handleMouseClick(KB.mouseX, KB.mouseY, screenWidth, screenHeight);
            KB.attackPressed = false; // 重置鼠标点击状态
        }
        
        // 处理鼠标移动
        inventory.handleMouseMove(KB.mouseX, KB.mouseY);
    }
    
    /**
     * 处理存档相关的键盘输入
     */
    private void handleSaveLoadInput() {
        // F5键 - 快速保存
        if (KB.f5Pressed) {
            saveGame("quicksave");
            KB.f5Pressed = false;
        }
        
        // F9键 - 快速加载
        if (KB.f9Pressed) {
            loadGame("quicksave");
            KB.f9Pressed = false;
        }
    }
    
    /**
     * 保存游戏（异步方式）
     * @param saveName 存档名称
     */
    public void saveGame(String saveName) {
        try {
            // 使用异步方法保存游戏
            saveManager.saveGameAsync(saveName)
                .thenAccept(success -> {
                    if (success) {
                        System.out.println("游戏已异步保存: " + saveName);
                    } else {
                        System.err.println("异步保存游戏失败: " + saveName);
                    }
                })
                .exceptionally(e -> {
                    System.err.println("异步保存游戏出现异常: " + e.getMessage());
                    e.printStackTrace();
                    return null;
                });
            
            // 立即返回，不阻塞游戏主线程
            System.out.println("正在后台保存游戏: " + saveName);
        } catch (Exception e) {
            System.err.println("启动异步保存失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 加载游戏
     * @param saveName 存档名称
     */
    public void loadGame(String saveName) {
        try {
            if (saveManager.loadGame(saveName)) {
                System.out.println("游戏已加载: " + saveName);
            } else {
                System.out.println("存档不存在: " + saveName);
            }
        } catch (Exception e) {
            System.err.println("加载游戏失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 更新网络同步
     */
    private void updateNetworkSync() {
        long currentTime = System.currentTimeMillis();
        
        // 定期发送玩家位置更新
        if (currentTime - lastNetworkUpdate >= NETWORK_UPDATE_INTERVAL) {
            networkClient.sendPlayerPosition();
            lastNetworkUpdate = currentTime;
        }
        
        // 显示接收到的Echo消息
        if (networkClient.hasNewEchoMessage()) {
            String echoMsg = networkClient.getLastEchoMessage();
            System.out.println("收到Echo回复: " + echoMsg);
        }
        
        // 发送玩家攻击事件
        if (player.isAttacking && player.attackJustStarted) {
            networkClient.sendPlayerAttack(
                player.worldx, player.worldy, 
                player.swordAngle, player.attackDamage,
                player.isChargedAttack, player.chargeMultiplier
            );
            player.attackJustStarted = false; // 防止重复发送
        }
        
        // 发送方块放置事件
        if (player.blockJustPlaced) {
            int worldX = KB.mouseX + player.worldx - player.screenx;
            int worldY = KB.mouseY + player.worldy - player.screeny;
            int tileX = worldX / tileSize;
            int tileY = worldY / tileSize;
            
            if (tileX >= 0 && tileX < maxworldcol && tileY >= 0 && tileY < maxworldrow) {
                int blockType = tilemanager.mapnum[tileX][tileY];
                networkClient.sendBlockPlace(tileX, tileY, blockType);
                
                // 方块放置后发送地图同步消息
                networkClient.sendMapSync(
                    tilemanager.mapnum,
                    maxworldcol,
                    maxworldrow
                );
                System.out.println("已发送地图同步消息（方块放置后）");
            }
            player.blockJustPlaced = false; // 防止重复发送
        }
    }

    /**
     * 绘制游戏画面（重写JPanel的paintComponent方法）
     * 按层次顺序绘制所有游戏元素
     * @param g Graphics对象，用于绘制
     */
    public void paintComponent(Graphics g) {
        // 调用父类的绘制方法，清除之前的画面
        super.paintComponent(g);
        // 转换为Graphics2D对象以获得更多绘图功能
        Graphics2D g2 = (Graphics2D) g;

        // 根据游戏状态绘制不同内容
        switch (gameState) {
            case START_SCREEN:
                // 绘制开始页面
                startScreen.draw(g2);
                break;
            case PLAYING:
                // 绘制游戏内容
                drawGameplay(g2);
                break;
            case PAUSED:
                // 绘制游戏画面作为背景，然后绘制暂停菜单
                drawGameplay(g2);
                pauseScreen.draw(g2, getWidth(), getHeight());
                break;
        }
        
        // 释放图形资源，防止内存泄漏
        g2.dispose();
    }
    
    /**
     * 绘制游戏玩法相关的所有内容
     */
    private void drawGameplay(Graphics2D g2) {
        // 绘制地图图块（背景层）
        tilemanager.draw(g2);
        
        // 绘制方块选中框（在地图之上，实体之下）
        drawBlockSelectionBox(g2);
        
        // 绘制玩家坐标（左上角）
        drawPlayerCoordinates(g2);
        
        // 绘制所有敌人（中间层）
        synchronized(enemies) {
            for (enemy currentEnemy : enemies) {
                currentEnemy.draw(g2);
            }
        }
        
        // 绘制所有箭矢
        synchronized(arrows) {
            for (Arrow arrow : arrows) {
                arrow.draw(g2, player);
            }
        }
        
        // 绘制所有炸弹
        synchronized(bombs) {
            for (Bomb bomb : bombs) {
                bomb.draw(g2);
            }
        }
        
        // 绘制玩家角色（前景层）
        player.draw(g2);
        
        // 绘制其他联机玩家
        if (isMultiplayer && networkClient != null) {
            drawRemotePlayers(g2);
        }
        
        // 绘制物品栏UI（最上层）- 缩小版本在玩家头顶
        inventory.draw(g2, screenWidth, screenHeight, player.screenx, player.screeny);
    }
    
    /**
     * 绘制方块选中框
     * 当玩家持有方块物品时，在鼠标位置显示可放置的选中框
     */
    private void drawBlockSelectionBox(Graphics2D g2) {
        // 检查当前选中的物品是否为方块物品
        item.Item selectedItem = inventory.getSelectedItem();
        if (!(selectedItem instanceof item.BlockItem)) {
            return; // 不是方块物品，不显示选中框
        }
        
        // 计算鼠标点击位置对应的世界坐标
        int worldX = KB.mouseX + player.worldx - player.screenx;
        int worldY = KB.mouseY + player.worldy - player.screeny;
        
        // 转换为图块坐标
        int tileX = worldX / tileSize;
        int tileY = worldY / tileSize;
        
        // 检查坐标是否在有效范围内
        if (tileX >= 0 && tileX < maxworldcol && tileY >= 0 && tileY < maxworldrow) {
            // 计算选中框在屏幕上的位置
            int screenX = tileX * tileSize - player.worldx + player.screenx;
            int screenY = tileY * tileSize - player.worldy + player.screeny;
            
            // 检查该位置是否可以放置方块（空位置）
            boolean canPlace = (tilemanager.mapnum[tileX][tileY] == 0);
            
            // 设置选中框颜色
            if (canPlace) {
                // 可以放置 - 绿色选中框
                g2.setColor(new Color(0, 255, 0, 100)); // 半透明绿色
            } else {
                // 不能放置 - 红色选中框
                g2.setColor(new Color(255, 0, 0, 100)); // 半透明红色
            }
            
            // 绘制填充的选中框
            g2.fillRect(screenX, screenY, tileSize, tileSize);
            
            // 绘制选中框边框
            g2.setStroke(new BasicStroke(2));
            if (canPlace) {
                g2.setColor(new Color(0, 255, 0, 200)); // 更不透明的绿色边框
            } else {
                g2.setColor(new Color(255, 0, 0, 200)); // 更不透明的红色边框
            }
            g2.drawRect(screenX, screenY, tileSize, tileSize);
            
            // 重置画笔
            g2.setStroke(new BasicStroke(1));
        }
    }
    
    /**
     * 绘制其他联机玩家
     */
    /**
     * 绘制玩家坐标信息
     * 在屏幕左上角显示玩家当前的世界坐标
     */
    private void drawPlayerCoordinates(Graphics2D g2) {
        // 计算玩家所在的图块坐标
        int tileX = player.worldx / tileSize;
        int tileY = player.worldy / tileSize;
        
        // 设置文本样式
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 16));
        
        // 绘制坐标文本（添加黑色描边使文字在任何背景下都清晰可见）
        String coordText = "X: " + tileX + "  Y: " + tileY;
        
        // 绘制文本阴影/描边
        g2.setColor(Color.BLACK);
        g2.drawString(coordText, 12, 22); // 右下偏移
        g2.drawString(coordText, 8, 22); // 左下偏移
        g2.drawString(coordText, 12, 18); // 右上偏移
        g2.drawString(coordText, 8, 18); // 左上偏移
        
        // 绘制主文本
        g2.setColor(Color.white);
        g2.drawString(coordText, 10, 20);
    }
    
    private void drawRemotePlayers(Graphics2D g2) {
        Map<String, RemotePlayer> remotePlayers = networkClient.getRemotePlayers();
        
        for (RemotePlayer remotePlayer : remotePlayers.values()) {
            // 检查玩家是否在屏幕可见范围内
            if (remotePlayer.isVisible(player.worldx, player.worldy, screenWidth, screenHeight)) {
                // 计算其他玩家在屏幕上的位置
                int screenX = remotePlayer.getScreenX(player.worldx, screenWidth);
                int screenY = remotePlayer.getScreenY(player.worldy, screenHeight);
                
                // 绘制其他玩家（简化版本，使用矩形表示）
                g2.setColor(Color.BLUE); // 其他玩家用蓝色表示
                g2.fillRect(screenX - 24, screenY - 48, 48, 48); // 玩家大小48x48
                
                // 绘制玩家名称
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 12));
                FontMetrics fm = g2.getFontMetrics();
                int nameWidth = fm.stringWidth(remotePlayer.playerName);
                g2.drawString(remotePlayer.playerName, screenX - nameWidth/2, screenY - 55);
                
                // 绘制生命值条
                if (remotePlayer.health < remotePlayer.maxHealth) {
                    int barWidth = 40;
                    int barHeight = 4;
                    int barX = screenX - barWidth/2;
                    int barY = screenY - 65;
                    
                    // 背景（红色）
                    g2.setColor(Color.RED);
                    g2.fillRect(barX, barY, barWidth, barHeight);
                    
                    // 生命值（绿色）
                    g2.setColor(Color.GREEN);
                    int healthWidth = (int)((double)remotePlayer.health / remotePlayer.maxHealth * barWidth);
                    g2.fillRect(barX, barY, healthWidth, barHeight);
                    
                    // 边框
                    g2.setColor(Color.WHITE);
                    g2.drawRect(barX, barY, barWidth, barHeight);
                }
            }
        }
    }
}