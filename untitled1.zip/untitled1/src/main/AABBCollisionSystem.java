package main;

import entity.entity;
import java.util.List;
import java.util.ArrayList;

/**
 * AABB碰撞检测系统
 * 提供高效的轴对齐包围盒碰撞检测功能
 * 支持实体间碰撞、地图碰撞、连续碰撞检测等
 */
public class AABBCollisionSystem {
    private GamePanel gp;
    
    // 碰撞检测结果结构
    public static class CollisionResult {
        public boolean hasCollision;     // 是否发生碰撞
        public float penetrationX;       // X方向穿透深度
        public float penetrationY;       // Y方向穿透深度
        public String collisionSide;     // 碰撞面（"top", "bottom", "left", "right"）
        public AABB collisionBox;        // 碰撞的包围盒
        
        public CollisionResult() {
            this.hasCollision = false;
            this.penetrationX = 0;
            this.penetrationY = 0;
            this.collisionSide = "none";
            this.collisionBox = null;
        }
    }
    
    /**
     * 构造函数
     * @param gp 游戏面板引用
     */
    public AABBCollisionSystem(GamePanel gp) {
        this.gp = gp;
    }
    
    /**
     * 从实体创建AABB包围盒
     * @param entity 实体对象
     * @return AABB包围盒
     */
    public AABB createAABBFromEntity(entity entity) {
        return new AABB(
            entity.worldx + entity.solidarea.x,
            entity.worldy + entity.solidarea.y,
            entity.solidarea.width,
            entity.solidarea.height
        );
    }
    
    /**
     * 预测实体移动后的AABB包围盒
     * @param entity 实体对象
     * @param deltaX X方向移动距离
     * @param deltaY Y方向移动距离
     * @return 移动后的AABB包围盒
     */
    public AABB predictAABB(entity entity, float deltaX, float deltaY) {
        return new AABB(
            entity.worldx + entity.solidarea.x + deltaX,
            entity.worldy + entity.solidarea.y + deltaY,
            entity.solidarea.width,
            entity.solidarea.height
        );
    }
    
    /**
     * 检测两个AABB是否碰撞
     * @param aabb1 第一个AABB
     * @param aabb2 第二个AABB
     * @return 碰撞检测结果
     */
    public CollisionResult checkAABBCollision(AABB aabb1, AABB aabb2) {
        CollisionResult result = new CollisionResult();
        
        if (!aabb1.intersects(aabb2)) {
            return result; // 无碰撞
        }
        
        result.hasCollision = true;
        result.collisionBox = aabb2;
        
        // 计算穿透深度
        float overlapX = Math.min(aabb1.getRight(), aabb2.getRight()) - 
                        Math.max(aabb1.x, aabb2.x);
        float overlapY = Math.min(aabb1.getBottom(), aabb2.getBottom()) - 
                        Math.max(aabb1.y, aabb2.y);
        
        result.penetrationX = overlapX;
        result.penetrationY = overlapY;
        
        // 确定碰撞面
        if (overlapX < overlapY) {
            // 水平碰撞
            if (aabb1.getCenterX() < aabb2.getCenterX()) {
                result.collisionSide = "right";
            } else {
                result.collisionSide = "left";
            }
        } else {
            // 垂直碰撞
            if (aabb1.getCenterY() < aabb2.getCenterY()) {
                result.collisionSide = "bottom";
            } else {
                result.collisionSide = "top";
            }
        }
        
        return result;
    }
    
    /**
     * 检测实体与地图图块的碰撞
     * @param entity 实体对象
     * @param deltaX X方向移动距离
     * @param deltaY Y方向移动距离
     * @return 碰撞检测结果
     */
    public CollisionResult checkTileCollision(entity entity, float deltaX, float deltaY) {
        CollisionResult result = new CollisionResult();
        
        AABB predictedAABB = predictAABB(entity, deltaX, deltaY);
        
        // 计算需要检查的图块范围
        int startCol = Math.max(0, (int)(predictedAABB.x / gp.tileSize));
        int endCol = Math.min(gp.maxworldcol - 1, (int)(predictedAABB.getRight() / gp.tileSize));
        int startRow = Math.max(0, (int)(predictedAABB.y / gp.tileSize));
        int endRow = Math.min(gp.maxworldrow - 1, (int)(predictedAABB.getBottom() / gp.tileSize));
        
        // 检查范围内的所有图块
        for (int col = startCol; col <= endCol; col++) {
            for (int row = startRow; row <= endRow; row++) {
                if (isTileCollidable(col, row)) {
                    AABB tileAABB = new AABB(
                        col * gp.tileSize,
                        row * gp.tileSize,
                        gp.tileSize,
                        gp.tileSize
                    );
                    
                    CollisionResult tileCollision = checkAABBCollision(predictedAABB, tileAABB);
                    if (tileCollision.hasCollision) {
                        // 如果是第一次碰撞或者穿透更深，更新结果
                        if (!result.hasCollision || 
                            (tileCollision.penetrationX + tileCollision.penetrationY) > 
                            (result.penetrationX + result.penetrationY)) {
                            result = tileCollision;
                        }
                    }
                }
            }
        }
        
        return result;
    }
    
    /**
     * 连续碰撞检测（扫描检测）
     * 防止高速移动时穿透物体
     * @param entity 实体对象
     * @param deltaX X方向移动距离
     * @param deltaY Y方向移动距离
     * @param steps 检测步数
     * @return 碰撞检测结果
     */
    public CollisionResult continuousCollisionDetection(entity entity, float deltaX, float deltaY, int steps) {
        CollisionResult result = new CollisionResult();
        
        float stepX = deltaX / steps;
        float stepY = deltaY / steps;
        
        for (int i = 1; i <= steps; i++) {
            float currentDeltaX = stepX * i;
            float currentDeltaY = stepY * i;
            
            CollisionResult stepResult = checkTileCollision(entity, currentDeltaX, currentDeltaY);
            if (stepResult.hasCollision) {
                return stepResult;
            }
        }
        
        return result;
    }
    
    /**
     * 检测实体间碰撞
     * @param entity1 第一个实体
     * @param entity2 第二个实体
     * @return 碰撞检测结果
     */
    public CollisionResult checkEntityCollision(entity entity1, entity entity2) {
        AABB aabb1 = createAABBFromEntity(entity1);
        AABB aabb2 = createAABBFromEntity(entity2);
        return checkAABBCollision(aabb1, aabb2);
    }
    
    /**
     * 检测实体与实体列表的碰撞
     * @param entity 实体对象
     * @param entities 实体列表
     * @return 碰撞检测结果列表
     */
    public List<CollisionResult> checkEntityListCollision(entity entity, List<entity> entities) {
        List<CollisionResult> results = new ArrayList<>();
        AABB entityAABB = createAABBFromEntity(entity);
        
        for (entity other : entities) {
            if (other != entity) {
                AABB otherAABB = createAABBFromEntity(other);
                CollisionResult result = checkAABBCollision(entityAABB, otherAABB);
                if (result.hasCollision) {
                    results.add(result);
                }
            }
        }
        
        return results;
    }
    
    /**
     * 解决碰撞（位置修正）
     * @param entity 实体对象
     * @param collision 碰撞结果
     */
    public void resolveCollision(entity entity, CollisionResult collision) {
        if (!collision.hasCollision) return;
        
        switch (collision.collisionSide) {
            case "left":
                entity.worldx = (int)(collision.collisionBox.getRight() - entity.solidarea.x);
                break;
            case "right":
                entity.worldx = (int)(collision.collisionBox.x - entity.solidarea.x - entity.solidarea.width);
                break;
            case "top":
                entity.worldy = (int)(collision.collisionBox.getBottom() - entity.solidarea.y);
                break;
            case "bottom":
                entity.worldy = (int)(collision.collisionBox.y - entity.solidarea.y - entity.solidarea.height);
                entity.onGround = true;
                entity.velocityY = 0;
                break;
        }
    }
    
    /**
     * 检查指定图块是否可碰撞
     * @param col 图块列
     * @param row 图块行
     * @return 是否可碰撞
     */
    private boolean isTileCollidable(int col, int row) {
        // 边界检查
        if (col < 0 || col >= gp.maxworldcol || row < 0 || row >= gp.maxworldrow) {
            return true;
        }
        
        // 获取图块索引
        int tileIndex = gp.tilemanager.mapnum[col][row];
        
        // 检查图块索引有效性
        if (tileIndex < 0 || tileIndex >= gp.tilemanager.TI.length) {
            return true;
        }
        
        // 返回图块碰撞属性
        return gp.tilemanager.TI[tileIndex].collision;
    }
    
    /**
     * 获取实体周围的AABB（用于范围查询）
     * @param entity 实体对象
     * @param radius 半径
     * @return 扩展的AABB
     */
    public AABB getExpandedAABB(entity entity, float radius) {
        AABB entityAABB = createAABBFromEntity(entity);
        return new AABB(
            entityAABB.x - radius,
            entityAABB.y - radius,
            entityAABB.width + 2 * radius,
            entityAABB.height + 2 * radius
        );
    }
    
    /**
     * 射线投射检测
     * @param startX 起始X坐标
     * @param startY 起始Y坐标
     * @param endX 结束X坐标
     * @param endY 结束Y坐标
     * @return 是否有碰撞
     */
    public boolean raycast(float startX, float startY, float endX, float endY) {
        float dx = endX - startX;
        float dy = endY - startY;
        float distance = (float)Math.sqrt(dx * dx + dy * dy);
        
        if (distance == 0) return false;
        
        float stepX = dx / distance;
        float stepY = dy / distance;
        
        int steps = (int)(distance / (gp.tileSize / 4)); // 每1/4图块大小检测一次
        
        for (int i = 0; i <= steps; i++) {
            float currentX = startX + stepX * i * (gp.tileSize / 4);
            float currentY = startY + stepY * i * (gp.tileSize / 4);
            
            int col = (int)(currentX / gp.tileSize);
            int row = (int)(currentY / gp.tileSize);
            
            if (isTileCollidable(col, row)) {
                return true;
            }
        }
        
        return false;
    }
}