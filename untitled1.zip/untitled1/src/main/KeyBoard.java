package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

/**
 * 键盘输入处理类
 * 实现KeyListener接口，负责处理游戏中的键盘输入事件
 * 支持动态按键绑定和WASD移动控制、空格键跳跃功能
 */
public class KeyBoard implements KeyListener, MouseListener, MouseMotionListener, MouseWheelListener {
    private KeySettings keySettings = KeySettings.getInstance();
    public boolean up,down,left,right,stop;
    public boolean space;  // 跳跃按键状态
    public boolean spacePressed;  // 跳跃按键按下瞬间状态
    public boolean attackPressed;  // 攻击按键按下瞬间状态（鼠标左键）
    public boolean attackHeld;     // 攻击按键持续按下状态（用于蓄力）
    public int attackHoldTime = 0; // 攻击按键持续按下时间（帧数）
    private boolean wPressed, aPressed, sPressed, dPressed;
    
    // 鼠标位置跟踪
    public int mouseX = 0;
    public int mouseY = 0;
    
    // 鼠标按键状态
    public boolean mousePressed = false;  // 鼠标按键是否被按下
    public int mouseButton = 0;           // 按下的鼠标按键（1=左键，2=中键，3=右键）
    public boolean rightClickPressed = false;  // 右键按下瞬间状态（用于放置方块）
    
    // 物品栏相关按键
    public boolean tabPressed = false;  // Tab键切换物品栏显示
    public int numberKeyPressed = -1;   // 数字键1-9，用于快速选择物品栏槽位
    
    // 鼠标滚轮状态
    public int wheelRotation = 0;       // 滚轮滚动方向（正数向下，负数向上）
    public boolean wheelScrolled = false; // 滚轮是否滚动
    
    // 开始页面导航按键
    public boolean upArrowPressed = false;   // 上箭头键
    public boolean downArrowPressed = false; // 下箭头键
    public boolean enterPressed = false;     // 回车键
    
    // 移动状态控制按键
    public boolean shift = false;            // Shift键（跑步）
    public boolean ctrl = false;             // Ctrl键（冲刺）
    
    // 游戏控制按键
    public boolean escPressed = false;       // ESC键（暂停游戏）
    
    // 存档相关按键
    public boolean f5Pressed = false;        // F5键（快速保存）
    public boolean f9Pressed = false;        // F9键（快速加载）
    
    // 通用按键事件跟踪
    public int lastKeyPressed = -1;          // 最后按下的按键代码
    public boolean hasNewKeyPress = false;   // 是否有新的按键按下事件

    @Override
    public void keyTyped(KeyEvent e) {
        // 此方法在当前游戏中未使用
    }

    /**
     * 按键按下事件处理
     * 当玩家按下键盘按键时触发，设置对应的移动状态
     * @param e 键盘事件对象
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();  // 获取按键代码
        
        // 记录通用按键事件
        lastKeyPressed = code;
        hasNewKeyPress = true;

        // 动态按键绑定 - 向上移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_UP)){
            up = true;
        }
        // 动态按键绑定 - 向左移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_LEFT)){
            left = true;
        }
        // 动态按键绑定 - 向下移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_DOWN)){
            down = true;
        }
        // 动态按键绑定 - 向右移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_RIGHT)){
            right = true;
        }
        // 动态按键绑定 - 跳跃控制
        if (code == keySettings.getKeyCode(KeySettings.JUMP)){
            space = true;
            spacePressed = true;
        }
        
        // 动态按键绑定 - 切换物品栏显示
        if (code == keySettings.getKeyCode(KeySettings.INVENTORY)) {
            tabPressed = true;
        }
        
        // 动态按键绑定 - 快速选择物品栏槽位
        String[] itemKeys = {KeySettings.ITEM_1, KeySettings.ITEM_2, KeySettings.ITEM_3, 
                            KeySettings.ITEM_4, KeySettings.ITEM_5, KeySettings.ITEM_6,
                            KeySettings.ITEM_7, KeySettings.ITEM_8, KeySettings.ITEM_9};
        for (int i = 0; i < itemKeys.length; i++) {
            if (code == keySettings.getKeyCode(itemKeys[i])) {
                numberKeyPressed = i; // 转换为0-8的索引
                break;
            }
        }
        
        // 上下箭头键 - 开始页面菜单导航（保持硬编码，因为这些是系统导航键）
        if (code == KeyEvent.VK_UP) {
            upArrowPressed = true;
        }
        if (code == KeyEvent.VK_DOWN) {
            downArrowPressed = true;
        }
        
        // 回车键 - 开始页面确认选择（保持硬编码，因为这是系统确认键）
        if (code == KeyEvent.VK_ENTER) {
            enterPressed = true;
        }
        
        // 动态按键绑定 - 跑步
        if (code == keySettings.getKeyCode(KeySettings.RUN)) {
            shift = true;
        }
        
        // 动态按键绑定 - 冲刺
        if (code == keySettings.getKeyCode(KeySettings.SPRINT)) {
            ctrl = true;
        }
        
        // ESC键 - 暂停游戏
        if (code == KeyEvent.VK_ESCAPE) {
            escPressed = true;
        }
        
        // F5键 - 快速保存
        if (code == KeyEvent.VK_F5) {
            f5Pressed = true;
        }
        
        // F9键 - 快速加载
        if (code == KeyEvent.VK_F9) {
            f9Pressed = true;
        }
        
        // X键攻击已移除，改为鼠标左键攻击
    }

    /**
     * 按键释放事件处理
     * 当玩家释放键盘按键时触发，取消对应的移动状态
     * @param e 键盘事件对象
     */
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();  // 获取按键代码

        // 动态按键绑定 - 停止向上移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_UP)){
            up = false;
        }
        // 动态按键绑定 - 停止向左移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_LEFT)){
            left = false;
        }
        // 动态按键绑定 - 停止向下移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_DOWN)){
            down = false;
        }
        // 动态按键绑定 - 停止向右移动
        if (code == keySettings.getKeyCode(KeySettings.MOVE_RIGHT)){
            right = false;
        }
        // 动态按键绑定 - 停止跳跃
        if (code == keySettings.getKeyCode(KeySettings.JUMP)){
            space = false;
        }
        
        // 动态按键绑定 - 物品栏键释放
        if (code == keySettings.getKeyCode(KeySettings.INVENTORY)) {
            tabPressed = false;
        }
        
        // 上下箭头键释放（保持硬编码，因为这些是系统导航键）
        if (code == KeyEvent.VK_UP) {
            upArrowPressed = false;
        }
        if (code == KeyEvent.VK_DOWN) {
            downArrowPressed = false;
        }
        
        // 回车键释放（保持硬编码，因为这是系统确认键）
        if (code == KeyEvent.VK_ENTER) {
            enterPressed = false;
        }
        
        // 动态按键绑定 - 停止跑步
        if (code == keySettings.getKeyCode(KeySettings.RUN)) {
            shift = false;
        }
        
        // 动态按键绑定 - 停止冲刺
        if (code == keySettings.getKeyCode(KeySettings.SPRINT)) {
            ctrl = false;
        }
        
        // ESC键释放（保持硬编码，因为这是系统功能键）
// ESC键释放
        if (code == KeyEvent.VK_ESCAPE) {
            escPressed = false;
        }
        
        // F5键释放
        if (code == KeyEvent.VK_F5) {
            f5Pressed = false;
        }
        
        // F9键释放
        if (code == KeyEvent.VK_F9) {
            f9Pressed = false;
        }
        
        // X键攻击已移除，改为鼠标左键攻击
    }
    
    // 鼠标监听器实现
    @Override
    public void mouseClicked(MouseEvent e) {
        // 鼠标点击事件（可选实现）
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        mousePressed = true;
        mouseButton = e.getButton();
        
        // 鼠标左键按下 - 开始蓄力攻击
        if (e.getButton() == MouseEvent.BUTTON1) {
            attackPressed = true;
            attackHeld = true;
            attackHoldTime = 0;
        }
        
        // 鼠标右键按下 - 放置方块
        if (e.getButton() == MouseEvent.BUTTON3) {
            rightClickPressed = true;
        }
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        mousePressed = false;
        
        // 鼠标左键释放 - 结束蓄力攻击
        if (e.getButton() == MouseEvent.BUTTON1) {
            attackHeld = false;
        }
        
        mouseButton = 0;
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
        // 鼠标进入组件事件（未使用）
    }
    
    @Override
    public void mouseExited(MouseEvent e) {
        // 鼠标离开组件事件（未使用）
    }
    
    // MouseMotionListener实现
    @Override
    public void mouseDragged(MouseEvent e) {
        mouseX = e.getX();
        mouseY = e.getY();
    }
    
    @Override
    public void mouseMoved(MouseEvent e) {
        mouseX = e.getX();
        mouseY = e.getY();
    }
    
    /**
     * 获取当前移动方向
     * 根据当前按键状态返回玩家的移动方向字符串
     * @return 移动方向（"up", "down", "left", "right", "stop"）
     */
    public String getDirection() {
        if (up) {
            return "up";
        } else if (down) {
            return "down";
        } else if (left) {
            return "left";
        } else if (right) {
            return "right";
        } else {
            return "stop";
        }
    }
    
    /**
     * 检查是否有任何移动按键被按下
     * @return 如果有移动按键被按下返回true，否则返回false
     */
    public boolean isMoving() {
        return up || down || left || right;
    }
    
    /**
     * 重置所有按键状态
     * 用于游戏重置或特殊情况下清除所有输入状态
     */
    public void resetAllKeys() {
        up = down = left = right = false;
        space = spacePressed = false;
        attackPressed = false;
        attackHeld = false;
        attackHoldTime = 0;
        tabPressed = false;
        numberKeyPressed = -1;
        mousePressed = false;
        mouseButton = 0;
        rightClickPressed = false;
        upArrowPressed = false;
        downArrowPressed = false;
        enterPressed = false;
        stop = true;
    }
    
    /**
     * 更新蓄力攻击时间
     * 每帧调用以增加蓄力时间
     */
    public void updateChargeTime() {
        if (attackHeld) {
            attackHoldTime++;
        }
    }
    
    /**
     * 获取蓄力攻击时间
     * @return 蓄力时间（帧数）
     */
    public int getChargeTime() {
        return attackHoldTime;
    }
    
    /**
     * 检查是否正在蓄力
     * @return 是否正在蓄力
     */
    public boolean isCharging() {
        return attackHeld;
    }
    
    /**
     * 检查跳跃按键是否被按下
     * @return 跳跃按键状态
     */
    public boolean isJumpPressed() {
        return spacePressed;
    }
    
    /**
     * 重置跳跃按键状态
     * 用于防止跳跃按键持续触发
     */
    public void resetJumpPressed() {
        spacePressed = false;
    }
    
    /**
     * 获取Tab键按下状态
     * @return Tab键是否被按下
     */
    public boolean isTabPressed() {
        return tabPressed;
    }
    
    /**
     * 获取数字键按下状态
     * @return 按下的数字键索引（0-8），如果没有按下则返回-1
     */
    public int getNumberKeyPressed() {
        return numberKeyPressed;
    }
    
    /**
     * 重置数字键按下状态
     */
    public void resetNumberKeyPressed() {
        numberKeyPressed = -1;
    }
    
    /**
     * 更新方向状态（私有方法，当前未被使用）
     * 根据按键状态更新移动方向，支持对角线移动
     * 注意：此方法目前未被调用，可能是为了未来的功能扩展
     */
    private void updateDirection() {
        // 重置方向状态
        up = false;
        down = false;
        left = false;
        right = false;
        stop = true; // 默认停止，除非有按键按下

        // 处理对角线移动（优先级高于单一方向）
        if (wPressed && dPressed) {
            up = true;      // 右上方向
            right = true;
            stop = false;
        } else if (wPressed && aPressed) {
            up = true;      // 左上方向
            left = true;
            stop = false;
        } else if (sPressed && dPressed) {
            down = true;    // 右下方向
            right = true;
            stop = false;
        } else if (sPressed && aPressed) {
            down = true;    // 左下方向
            left = true;
            stop = false;
        }
        // 处理单一方向移动
        else if (wPressed) {
            up = true;      // 向上
            stop = false;
        } else if (sPressed) {
            down = true;    // 向下
            stop = false;
        } else if (aPressed) {
            left = true;    // 向左
            stop = false;
        } else if (dPressed) {
            right = true;   // 向右
            stop = false;
        }

        // 空格键处理（跳跃或其他动作）
        if (spacePressed) {
            // 这里可以添加跳跃或其他动作的逻辑
            // 例如：up = true; 或者保持原样
        }
    }
    
    // MouseWheelListener实现
    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        wheelRotation = e.getWheelRotation();
        wheelScrolled = true;
    }
    
    /**
     * 检查滚轮是否滚动
     * @return 滚轮是否滚动
     */
    public boolean isWheelScrolled() {
        return wheelScrolled;
    }
    
    /**
     * 获取滚轮滚动方向
     * @return 滚轮滚动方向（正数向下，负数向上）
     */
    public int getWheelRotation() {
        return wheelRotation;
    }
    
    /**
     * 重置滚轮状态
     */
    public void resetWheelState() {
        wheelScrolled = false;
        wheelRotation = 0;
    }
    
    /**
     * 获取上箭头键按下状态
     * @return 上箭头键是否被按下
     */
    public boolean isUpArrowPressed() {
        return upArrowPressed;
    }
    
    /**
     * 获取下箭头键按下状态
     * @return 下箭头键是否被按下
     */
    public boolean isDownArrowPressed() {
        return downArrowPressed;
    }
    
    /**
     * 获取回车键按下状态
     * @return 回车键是否被按下
     */
    public boolean isEnterPressed() {
        return enterPressed;
    }
    
    /**
     * 重置开始页面导航按键状态
     */
    public void resetStartScreenKeys() {
        upArrowPressed = false;
        downArrowPressed = false;
        enterPressed = false;
    }
}
