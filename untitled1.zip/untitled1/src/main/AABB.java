package main;

/**
 * AABB（Axis-Aligned Bounding Box）轴对齐包围盒类
 * 用于表示游戏中实体的碰撞边界框
 * 支持高效的碰撞检测和空间查询
 */
public class AABB {
    public float x;      // 包围盒左上角X坐标
    public float y;      // 包围盒左上角Y坐标
    public float width;  // 包围盒宽度
    public float height; // 包围盒高度
    
    /**
     * 构造函数
     * @param x 左上角X坐标
     * @param y 左上角Y坐标
     * @param width 宽度
     * @param height 高度
     */
    public AABB(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    /**
     * 复制构造函数
     * @param other 要复制的AABB对象
     */
    public AABB(AABB other) {
        this.x = other.x;
        this.y = other.y;
        this.width = other.width;
        this.height = other.height;
    }
    
    /**
     * 获取包围盒右边界X坐标
     * @return 右边界X坐标
     */
    public float getRight() {
        return x + width;
    }
    
    /**
     * 获取包围盒下边界Y坐标
     * @return 下边界Y坐标
     */
    public float getBottom() {
        return y + height;
    }
    
    /**
     * 获取包围盒中心点X坐标
     * @return 中心点X坐标
     */
    public float getCenterX() {
        return x + width / 2.0f;
    }
    
    /**
     * 获取包围盒中心点Y坐标
     * @return 中心点Y坐标
     */
    public float getCenterY() {
        return y + height / 2.0f;
    }
    
    /**
     * 设置包围盒位置
     * @param newX 新的X坐标
     * @param newY 新的Y坐标
     */
    public void setPosition(float newX, float newY) {
        this.x = newX;
        this.y = newY;
    }
    
    /**
     * 设置包围盒大小
     * @param newWidth 新的宽度
     * @param newHeight 新的高度
     */
    public void setSize(float newWidth, float newHeight) {
        this.width = newWidth;
        this.height = newHeight;
    }
    
    /**
     * 移动包围盒
     * @param deltaX X方向移动距离
     * @param deltaY Y方向移动距离
     */
    public void translate(float deltaX, float deltaY) {
        this.x += deltaX;
        this.y += deltaY;
    }
    
    /**
     * 检查点是否在包围盒内
     * @param pointX 点的X坐标
     * @param pointY 点的Y坐标
     * @return 如果点在包围盒内返回true，否则返回false
     */
    public boolean contains(float pointX, float pointY) {
        return pointX >= x && pointX <= getRight() && 
               pointY >= y && pointY <= getBottom();
    }
    
    /**
     * 检查两个AABB是否相交
     * @param other 另一个AABB对象
     * @return 如果相交返回true，否则返回false
     */
    public boolean intersects(AABB other) {
        return !(this.getRight() < other.x || 
                 this.x > other.getRight() || 
                 this.getBottom() < other.y || 
                 this.y > other.getBottom());
    }
    
    /**
     * 检查当前AABB是否完全包含另一个AABB
     * @param other 另一个AABB对象
     * @return 如果完全包含返回true，否则返回false
     */
    public boolean contains(AABB other) {
        return this.x <= other.x && 
               this.y <= other.y && 
               this.getRight() >= other.getRight() && 
               this.getBottom() >= other.getBottom();
    }
    
    /**
     * 计算与另一个AABB的重叠区域
     * @param other 另一个AABB对象
     * @return 重叠区域的AABB，如果不重叠返回null
     */
    public AABB getIntersection(AABB other) {
        if (!intersects(other)) {
            return null;
        }
        
        float left = Math.max(this.x, other.x);
        float top = Math.max(this.y, other.y);
        float right = Math.min(this.getRight(), other.getRight());
        float bottom = Math.min(this.getBottom(), other.getBottom());
        
        return new AABB(left, top, right - left, bottom - top);
    }
    
    /**
     * 扩展包围盒以包含另一个AABB
     * @param other 另一个AABB对象
     */
    public void union(AABB other) {
        float left = Math.min(this.x, other.x);
        float top = Math.min(this.y, other.y);
        float right = Math.max(this.getRight(), other.getRight());
        float bottom = Math.max(this.getBottom(), other.getBottom());
        
        this.x = left;
        this.y = top;
        this.width = right - left;
        this.height = bottom - top;
    }
    
    /**
     * 计算包围盒面积
     * @return 包围盒面积
     */
    public float getArea() {
        return width * height;
    }
    
    /**
     * 计算包围盒周长
     * @return 包围盒周长
     */
    public float getPerimeter() {
        return 2.0f * (width + height);
    }
    
    /**
     * 创建当前AABB的副本
     * @return AABB副本
     */
    public AABB clone() {
        return new AABB(this.x, this.y, this.width, this.height);
    }
    
    /**
     * 字符串表示
     * @return AABB的字符串描述
     */
    @Override
    public String toString() {
        return String.format("AABB[x=%.2f, y=%.2f, width=%.2f, height=%.2f]", 
                           x, y, width, height);
    }
    
    /**
     * 判断两个AABB是否相等
     * @param obj 比较对象
     * @return 如果相等返回true，否则返回false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        AABB aabb = (AABB) obj;
        return Float.compare(aabb.x, x) == 0 &&
               Float.compare(aabb.y, y) == 0 &&
               Float.compare(aabb.width, width) == 0 &&
               Float.compare(aabb.height, height) == 0;
    }
    
    /**
     * 计算哈希码
     * @return 哈希码
     */
    @Override
    public int hashCode() {
        int result = Float.floatToIntBits(x);
        result = 31 * result + Float.floatToIntBits(y);
        result = 31 * result + Float.floatToIntBits(width);
        result = 31 * result + Float.floatToIntBits(height);
        return result;
    }
}