package main;

import java.util.Random;

/**
 * 地形生成器类
 * 负责程序化生成游戏世界的地形
 * 支持多种地形类型和生成算法
 */
public class TerrainGenerator {
    private static final double FREQUENCY = 0.1;
    private static final double AMPLITUDE = 1.0;
    private static final int OCTAVES = 4;
    
    // 地形生成配置
    private TerrainConfig terrainConfig;
    
    /**
     * 地形生成配置类
     */
    private static class TerrainConfig {
        public double noiseScale = 0.02; // 噪声缩放
        public int groundVariation = 20; // 地表起伏幅度
        public double caveThreshold = 0.6; // 洞穴生成阈值
        public double mineralChance = 0.05; // 矿物生成概率
    }
    
    /**
     * 地形类型枚举
     * 定义不同的地形类型及其对应的图块索引
     */
    public enum TerrainType {
        AIR(0),        // 空气/可通行区域
        STONE(1);      // 石头/墙壁
        
        private final int tileIndex;
        
        TerrainType(int tileIndex) {
            this.tileIndex = tileIndex;
        }
        
        public int getTileIndex() {
            return tileIndex;
        }
    }
    
    /**
     * 地形生成参数配置类
     * 包含各种生成算法的参数设置
     */
    public static class GenerationConfig {
        public long seed = System.currentTimeMillis();  // 随机种子
        public double noiseScale = 0.02;               // 噪声缩放比例（横版地形用更小的值）
        public int groundLevel = 30;                   // 地面基础高度
        public int groundVariation = 5;               // 地面高度变化范围
        public int platformMinWidth = 3;               // 平台最小宽度
        public int platformMaxWidth = 8;               // 平台最大宽度
        public int platformMinGap = 2;                 // 平台间最小间隔
        public int platformMaxGap = 6;                 // 平台间最大间隔
        public double platformDensity = 0.3;           // 平台生成密度
        public boolean generateObstacles = true;       // 是否生成障碍物
        public double obstacleDensity = 0.1;           // 障碍物密度
    }
    
    private Random random;
    private GenerationConfig config;
    
    /**
     * 构造函数
     * 使用默认配置初始化地形生成器
     */
    public TerrainGenerator() {
        this(new GenerationConfig());
        this.terrainConfig = new TerrainConfig();
    }
    
    /**
     * 构造函数
     * 使用指定配置初始化地形生成器
     * @param config 生成配置参数
     */
    public TerrainGenerator(GenerationConfig config) {
        this.config = config;
        this.random = new Random(config.seed);
        this.terrainConfig = new TerrainConfig();
    }
    
    /**
     * 生成横版2D地形数据
     * 包含地面、平台和障碍物
     * @param width 地图宽度（列数）
     * @param height 地图高度（行数）
     * @return 二维地形数据数组
     */
    public int[][] generateTerrain(int width, int height) {
        int[][] terrain = new int[width][height];
        
        // 初始化为全空气
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                terrain[x][y] = TerrainType.AIR.tileIndex;
            }
        }
        
        // 第一阶段：生成地面
        generateGround(terrain, width, height);
        
        // 第二阶段：生成平台
        generatePlatforms(terrain, width, height);
        
        // 第三阶段：生成障碍物
        if (config.generateObstacles) {
            generateObstacles(terrain, width, height);
        }
        
        return terrain;
    }
    
    /**
     * 生成横版2D地形数据
     * @param width 地图宽度
     * @param height 地图高度
     * @param seed 随机种子
     * @return 地形数据数组
     */
    public int[][] generateTerrain(int width, int height, long seed) {
        Random random = new Random(seed);
        int[][] terrain = new int[width][height];
        
        // 生成地表高度
        int[] surfaceHeight = generateSurfaceHeight(width, height, random);
        
        // 填充地形
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (y >= surfaceHeight[x]) {
                    // 地表以下填充土壤和石头
                    if (y < surfaceHeight[x] + 3) {
                        terrain[x][y] = 2; // 土壤
                    } else {
                        terrain[x][y] = 1; // 石头
                    }
                } else {
                    terrain[x][y] = 0; // 空气
                }
            }
        }
        
        // 生成洞穴
        generateCaves(terrain, width, height, random);
        
        // 添加矿物和装饰
        addMinerals(terrain, width, height, random);
        
        return terrain;
    }
    
    /**
     * 生成地表高度数组
     * @param width 地图宽度
     * @param height 地图高度
     * @param random 随机数生成器
     * @return 地表高度数组
     */
    private int[] generateSurfaceHeight(int width, int height, Random random) {
        int[] surfaceHeight = new int[width];
        int baseHeight = height * 10; // 基础地表高度 - 降低地形位置
        
        for (int x = 0; x < width; x++) {
            // 使用噪声生成地表起伏
            double noise = generateNoise(x * config.noiseScale, 0);
            surfaceHeight[x] = baseHeight + (int)(noise * config.groundVariation);
            
            // 确保地表高度在合理范围内
            surfaceHeight[x] = Math.max(5, Math.min(height - 5, surfaceHeight[x]));
        }
        
        return surfaceHeight;
    }
    
    /**
     * 生成洞穴系统
     * @param terrain 地形数据数组
     * @param width 地图宽度
     * @param height 地图高度
     * @param random 随机数生成器
     */
    private void generateCaves(int[][] terrain, int width, int height, Random random) {
        // 使用噪声生成洞穴
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (terrain[x][y] != 0) { // 只在非空气区域生成洞穴
                    double caveNoise = generateNoise(x * 0.05, y * 0.05);
                    if (caveNoise > 0.6) {
                        terrain[x][y] = 0; // 挖空形成洞穴
                    }
                }
            }
        }
    }
    
    /**
     * 添加矿物和装饰
     * @param terrain 地形数据数组
     * @param width 地图宽度
     * @param height 地图高度
     * @param random 随机数生成器
     */
    private void addMinerals(int[][] terrain, int width, int height, Random random) {
        // 在石头区域随机添加矿物（这里简化为保持石头类型）
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (terrain[x][y] == 1 && random.nextDouble() < 0.05) {
                    // 5%概率生成特殊矿物，这里保持为石头
                    terrain[x][y] = 1;
                }
            }
        }
    }
    
    /**
     * 简化的柏林噪声实现
     * 生成平滑的随机噪声值
     * @param x X坐标
     * @param y Y坐标
     * @return 噪声值（0.0 - 1.0）
     */
    private double generateNoise(double x, double y) {
        // 简化的噪声算法，使用多层噪声叠加
        double noise = 0.0;
        double amplitude = 1.0;
        double frequency = 1.0;
        
        // 多层噪声叠加
        for (int i = 0; i < 4; i++) {
            noise += amplitude * smoothNoise(x * frequency, y * frequency);
            amplitude *= 0.5;
            frequency *= 2.0;
        }
        
        // 归一化到0-1范围
        return Math.max(0.0, Math.min(1.0, (noise + 1.0) / 2.0));
    }
    
    /**
     * 平滑噪声函数
     * 基于插值的噪声生成
     * @param x X坐标
     * @param y Y坐标
     * @return 噪声值（-1.0 - 1.0）
     */
    private double smoothNoise(double x, double y) {
        int intX = (int) x;
        int intY = (int) y;
        double fracX = x - intX;
        double fracY = y - intY;
        
        // 获取四个角的噪声值
        double a = rawNoise(intX, intY);
        double b = rawNoise(intX + 1, intY);
        double c = rawNoise(intX, intY + 1);
        double d = rawNoise(intX + 1, intY + 1);
        
        // 双线性插值
        double i1 = interpolate(a, b, fracX);
        double i2 = interpolate(c, d, fracX);
        return interpolate(i1, i2, fracY);
    }
    
    /**
     * 原始噪声函数
     * 基于坐标生成伪随机值
     * @param x X坐标
     * @param y Y坐标
     * @return 噪声值（-1.0 - 1.0）
     */
    private double rawNoise(int x, int y) {
        int n = x + y * 57;
        n = (n << 13) ^ n;
        return (1.0 - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0);
    }
    
    /**
     * 线性插值函数
     * @param a 起始值
     * @param b 结束值
     * @param t 插值参数（0.0 - 1.0）
     * @return 插值结果
     */
    private double interpolate(double a, double b, double t) {
        double ft = t * Math.PI;
        double f = (1.0 - Math.cos(ft)) * 0.5;
        return a * (1.0 - f) + b * f;
    }
    
    /**
     * 生成地面
     * 创建横版2D游戏的基础地面
     * @param terrain 地形数据数组
     * @param width 地图宽度
     * @param height 地图高度
     */
    private void generateGround(int[][] terrain, int width, int height) {
        for (int x = 0; x < width; x++) {
            // 使用噪声生成地面高度变化
            double heightNoise = generateNoise(x * config.noiseScale, 0);
            int groundHeight = config.groundLevel + (int)(heightNoise * config.groundVariation);
            
            // 确保地面高度在合理范围内
            groundHeight = Math.max(5, Math.min(height - 5, groundHeight));
            
            // 生成地面和地下部分
            for (int y = groundHeight; y < height; y++) {
                terrain[x][y] = TerrainType.STONE.tileIndex;
            }
        }
    }
    
    /**
     * 生成平台
     * 在空中创建可跳跃的平台
     * @param terrain 地形数据数组
     * @param width 地图宽度
     * @param height 地图高度
     */
    private void generatePlatforms(int[][] terrain, int width, int height) {
        int x = 0;
        while (x < width) {
            // 随机决定是否生成平台
            if (random.nextDouble() < config.platformDensity) {
                // 随机平台宽度
                int platformWidth = config.platformMinWidth + 
                    random.nextInt(config.platformMaxWidth - config.platformMinWidth + 1);
                
                // 随机平台高度（在地面上方）
                int platformY = config.groundLevel - 8 - random.nextInt(15);
                platformY = Math.max(5, platformY);
                
                // 生成平台
                for (int px = x; px < Math.min(x + platformWidth, width); px++) {
                    if (terrain[px][platformY] == TerrainType.AIR.tileIndex) {
                        terrain[px][platformY] = TerrainType.STONE.tileIndex;
                    }
                }
                
                x += platformWidth;
            }
            
            // 添加平台间隔
            int gap = config.platformMinGap + 
                random.nextInt(config.platformMaxGap - config.platformMinGap + 1);
            x += gap;
        }
    }
    
    /**
     * 生成障碍物
     * 在地面和平台上添加小型障碍物
     * @param terrain 地形数据数组
     * @param width 地图宽度
     * @param height 地图高度
     */
    private void generateObstacles(int[][] terrain, int width, int height) {
        for (int x = 1; x < width - 1; x++) {
            for (int y = 1; y < height - 1; y++) {
                // 在地面或平台上方生成障碍物
                if (terrain[x][y] == TerrainType.AIR.tileIndex && 
                    terrain[x][y + 1] == TerrainType.STONE.tileIndex) {
                    
                    if (random.nextDouble() < config.obstacleDensity) {
                        // 生成1-2格高的障碍物
                        int obstacleHeight = 1 + random.nextInt(2);
                        for (int oy = 0; oy < obstacleHeight && (y - oy) >= 0; oy++) {
                            terrain[x][y - oy] = TerrainType.STONE.tileIndex;
                        }
                    }
                }
            }
        }
    }
    

    
    /**
     * 生成平坦地形（用于测试）
     * @param width 地图宽度
     * @param height 地图高度
     * @param groundLevel 地面高度
     * @return 地形数据数组
     */
    public int[][] generateFlatTerrain(int width, int height, int groundLevel) {
        int[][] terrain = new int[width][height];
        
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (y >= groundLevel) {
                    terrain[x][y] = TerrainType.STONE.getTileIndex();
                } else {
                    terrain[x][y] = TerrainType.AIR.getTileIndex();
                }
            }
        }
        
        return terrain;
    }
    
    /**
     * 获取当前配置
     * @return 生成配置
     */
    public GenerationConfig getConfig() {
        return config;
    }
    
    /**
     * 设置新的配置
     * @param config 新的生成配置
     */
    public void setConfig(GenerationConfig config) {
        this.config = config;
        this.random = new Random(config.seed);
    }
}