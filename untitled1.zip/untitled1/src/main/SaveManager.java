package main;

import entity.enemy;
import entity.player;
import item.Inventory;
import item.Item;
import item.ItemSlot;
import tile.tilemanager;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 存档管理器类
 * 负责游戏存档的保存、加载和管理
 */
public class SaveManager {
    private static final String SAVE_DIRECTORY = "saves";
    private static final String SAVE_EXTENSION = ".sav";
    private static final int MAX_SAVE_SLOTS = 10;
    
    private GamePanel gamePanel;
    
    /**
     * 构造函数
     */
    public SaveManager(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        createSaveDirectory();
    }
    
    /**
     * 创建存档目录
     */
    private void createSaveDirectory() {
        try {
            Path saveDir = Paths.get(SAVE_DIRECTORY);
            if (!Files.exists(saveDir)) {
                Files.createDirectories(saveDir);
                System.out.println("Created save directory: " + saveDir.toAbsolutePath());
            }
        } catch (IOException e) {
            System.err.println("Failed to create save directory: " + e.getMessage());
        }
    }
    
    /**
     * 保存游戏（同步方法）
     * @param saveName 存档名称
     * @return 是否保存成功
     */
    public boolean saveGame(String saveName) {
        try {
            GameSave gameSave = createGameSave(saveName);
            String fileName = sanitizeFileName(saveName) + SAVE_EXTENSION;
            Path savePath = Paths.get(SAVE_DIRECTORY, fileName);
            
            // 使用对象序列化保存
            try (ObjectOutputStream oos = new ObjectOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(savePath)))) {
                oos.writeObject(gameSave);
            }
            
            System.out.println("Game saved successfully: " + savePath.toAbsolutePath());
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to save game: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 异步保存游戏
     * @param saveName 存档名称
     * @return 包含保存操作结果的CompletableFuture
     */
    public CompletableFuture<Boolean> saveGameAsync(String saveName) {
        return CompletableFuture.supplyAsync(() -> {
            return saveGame(saveName);
        });
    }
    
    /**
     * 加载游戏
     * @param saveName 存档名称
     * @return 是否加载成功
     */
    public boolean loadGame(String saveName) {
        try {
            String fileName = sanitizeFileName(saveName) + SAVE_EXTENSION;
            Path savePath = Paths.get(SAVE_DIRECTORY, fileName);
            
            if (!Files.exists(savePath)) {
                System.err.println("Save file not found: " + savePath);
                return false;
            }
            
            // 使用对象反序列化加载
            GameSave gameSave;
            try (ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(Files.newInputStream(savePath)))) {
                gameSave = (GameSave) ois.readObject();
            }
            
            // 验证存档数据
            if (!gameSave.isValid()) {
                System.err.println("Invalid save data: " + savePath);
                return false;
            }
            
            // 应用存档数据到游戏
            applyGameSave(gameSave);
            
            System.out.println("Game loaded successfully: " + savePath.toAbsolutePath());
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to load game: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 创建游戏存档数据
     */
    private GameSave createGameSave(String saveName) {
        GameSave gameSave = new GameSave();
        gameSave.saveName = saveName;
        
        // 保存玩家数据
        gameSave.playerData = createPlayerSaveData();
        
        // 保存世界数据
        gameSave.worldData = createWorldSaveData();
        
        // 保存物品栏数据
        gameSave.inventoryData = createInventorySaveData();
        
        // 保存敌人数据
        gameSave.enemyData = createEnemySaveData();
        
        return gameSave;
    }
    
    /**
     * 创建玩家存档数据
     */
    private GameSave.PlayerSaveData createPlayerSaveData() {
        player p = gamePanel.player;
        GameSave.PlayerSaveData playerData = new GameSave.PlayerSaveData();
        
        // 位置信息
        playerData.worldX = p.worldx;
        playerData.worldY = p.worldy;
        
        // 生命值和状态
        playerData.health = p.health;
        playerData.maxHealth = p.maxHealth;
        playerData.stamina = p.stamina;
        playerData.maxStamina = p.maxStamina;
        
        // 战斗属性
        playerData.attackDamage = p.attackDamage;
        playerData.attackRange = p.attackRange;
        
        // 移动状态
        playerData.movementState = p.currentMovementState.name();
        playerData.direction = p.direction;
        
        // 游戏进度（暂时设置默认值）
        playerData.playTime = System.currentTimeMillis();
        playerData.level = 1;
        playerData.experience = 0;
        
        return playerData;
    }
    
    /**
     * 创建世界存档数据
     */
    private GameSave.WorldSaveData createWorldSaveData() {
        tilemanager tm = gamePanel.tilemanager;
        GameSave.WorldSaveData worldData = new GameSave.WorldSaveData();
        
        // 地图数据
        worldData.mapData = copyMapData(tm.mapnum);
        worldData.mapWidth = gamePanel.maxworldcol;
        worldData.mapHeight = gamePanel.maxworldrow;
        
        // 地形生成配置
        worldData.terrainConfig = createTerrainConfigSaveData();
        
        // 世界时间和环境
        worldData.worldTime = System.currentTimeMillis();
        worldData.weather = "clear"; // 默认天气
        worldData.dayNightCycle = 0; // 默认昼夜循环
        
        return worldData;
    }
    
    /**
     * 创建地形配置存档数据
     */
    private GameSave.TerrainConfigSaveData createTerrainConfigSaveData() {
        TerrainGenerator.GenerationConfig config = gamePanel.tilemanager.getTerrainGenerator().getConfig();
        GameSave.TerrainConfigSaveData terrainConfig = new GameSave.TerrainConfigSaveData();
        
        terrainConfig.seed = config.seed;
        terrainConfig.noiseScale = config.noiseScale;
        terrainConfig.groundLevel = config.groundLevel;
        terrainConfig.groundVariation = config.groundVariation;
        // 其他属性设置为默认值
        terrainConfig.octaves = 4;
        terrainConfig.persistence = 0.5;
        terrainConfig.lacunarity = 2.0;
        terrainConfig.surfaceThickness = 3;
        terrainConfig.caveThreshold = 0.6;
        terrainConfig.minCaveSize = 5;
        terrainConfig.oreFrequency = 0.05;
        
        return terrainConfig;
    }
    
    /**
     * 创建物品栏存档数据
     */
    private GameSave.InventorySaveData createInventorySaveData() {
        Inventory inventory = gamePanel.inventory;
        GameSave.InventorySaveData inventoryData = new GameSave.InventorySaveData();
        
        inventoryData.size = 50; // 物品栏大小
        inventoryData.selectedSlot = inventory.getSelectedSlot();
        
        // 保存每个槽位的数据
        for (int i = 0; i < inventoryData.size; i++) {
            Item item = inventory.getItem(i);
            int quantity = inventory.getQuantity(i);
            
            if (item != null && quantity > 0) {
                String itemType = item.getClass().getSimpleName();
                String itemData = ""; // 可以扩展为JSON格式的物品数据
                inventoryData.slots.add(new GameSave.ItemSlotSaveData(itemType, quantity, itemData));
            } else {
                inventoryData.slots.add(new GameSave.ItemSlotSaveData("", 0, ""));
            }
        }
        
        return inventoryData;
    }
    
    /**
     * 创建敌人存档数据
     */
    private List<GameSave.EnemySaveData> createEnemySaveData() {
        List<GameSave.EnemySaveData> enemyDataList = new ArrayList<>();
        
        synchronized(gamePanel.enemies) {
            for (enemy e : gamePanel.enemies) {
                GameSave.EnemySaveData enemyData = new GameSave.EnemySaveData();
                
                // 位置信息
                enemyData.worldX = e.worldx;
                enemyData.worldY = e.worldy;
                
                // 生命值和状态
                enemyData.health = e.health;
                enemyData.maxHealth = e.maxHealth;
                
                // AI状态
                enemyData.aiState = e.currentState.name();
                enemyData.direction = e.direction;
                
                // 巡逻相关
                enemyData.patrolStartX = e.patrolStartX;
                enemyData.patrolDirection = e.patrolDirection;
                
                // 敌人属性
                enemyData.enemyType = "BasicEnemy"; // 可以扩展为不同类型
                enemyData.attackDamage = e.damage;
                enemyData.detectionRange = e.detectionRange;
                enemyData.attackRange = e.attackRange;
                enemyData.aggressionLevel = e.aggressionLevel;
                
                enemyDataList.add(enemyData);
            }
        }
        
        return enemyDataList;
    }
    
    /**
     * 应用存档数据到游戏
     */
    private void applyGameSave(GameSave gameSave) {
        // 应用玩家数据
        applyPlayerSaveData(gameSave.playerData);
        
        // 应用世界数据
        applyWorldSaveData(gameSave.worldData);
        
        // 应用物品栏数据
        applyInventorySaveData(gameSave.inventoryData);
        
        // 应用敌人数据
        applyEnemySaveData(gameSave.enemyData);
    }
    
    /**
     * 应用玩家存档数据
     */
    private void applyPlayerSaveData(GameSave.PlayerSaveData playerData) {
        player p = gamePanel.player;
        
        // 位置信息
        p.worldx = playerData.worldX;
        p.worldy = playerData.worldY;
        
        // 生命值和状态
        p.health = playerData.health;
        p.maxHealth = playerData.maxHealth;
        p.stamina = playerData.stamina;
        p.maxStamina = playerData.maxStamina;
        
        // 战斗属性
        p.attackDamage = playerData.attackDamage;
        p.attackRange = playerData.attackRange;
        
        // 移动状态
        try {
            p.currentMovementState = player.MovementState.valueOf(playerData.movementState);
        } catch (IllegalArgumentException e) {
            p.currentMovementState = player.MovementState.WALKING; // 默认状态
        }
        p.direction = playerData.direction;
    }
    
    /**
     * 应用世界存档数据
     */
    private void applyWorldSaveData(GameSave.WorldSaveData worldData) {
        tilemanager tm = gamePanel.tilemanager;
        
        // 应用地图数据
        tm.mapnum = copyMapData(worldData.mapData);
        
        // 应用地形配置（如果需要重新生成）
        if (worldData.terrainConfig != null) {
            TerrainGenerator.GenerationConfig config = new TerrainGenerator.GenerationConfig();
            config.seed = worldData.terrainConfig.seed;
            config.noiseScale = worldData.terrainConfig.noiseScale;
            config.groundLevel = worldData.terrainConfig.groundLevel;
            config.groundVariation = worldData.terrainConfig.groundVariation;
            
            tm.setTerrainConfig(config);
        }
    }
    
    /**
     * 应用物品栏存档数据
     */
    private void applyInventorySaveData(GameSave.InventorySaveData inventoryData) {
        Inventory inventory = gamePanel.inventory;
        
        // 清空当前物品栏
        for (int i = 0; i < inventoryData.size; i++) {
            inventory.removeItem(i, inventory.getQuantity(i));
        }
        
        // 恢复物品栏数据
        inventory.setSelectedSlot(inventoryData.selectedSlot);
        
        for (int i = 0; i < inventoryData.slots.size() && i < inventoryData.size; i++) {
            GameSave.ItemSlotSaveData slotData = inventoryData.slots.get(i);
            if (!slotData.itemType.isEmpty() && slotData.quantity > 0) {
                Item item = createItemFromType(slotData.itemType);
                if (item != null) {
                    // 为特殊物品设置必要的属性
                    if (item instanceof item.BowItem) {
                        ((item.BowItem) item).setOwner(gamePanel.player, gamePanel);
                    } else if (item instanceof item.BombItem) {
                        ((item.BombItem) item).setOwner(gamePanel.player, gamePanel);
                    }
                    inventory.addItem(item, slotData.quantity);
                }
            }
        }
    }
    
    /**
     * 应用敌人存档数据
     */
    private void applyEnemySaveData(List<GameSave.EnemySaveData> enemyDataList) {
        // 清空当前敌人
        synchronized(gamePanel.enemies) {
            gamePanel.enemies.clear();
        }
        
        // 恢复敌人数据
        for (GameSave.EnemySaveData enemyData : enemyDataList) {
            enemy e = new enemy(gamePanel, enemyData.worldX, enemyData.worldY);
            
            // 位置信息
            e.worldx = enemyData.worldX;
            e.worldy = enemyData.worldY;
            
            // 生命值和状态
            e.health = enemyData.health;
            e.maxHealth = enemyData.maxHealth;
            
            // AI状态
            try {
                e.currentState = enemy.AIState.valueOf(enemyData.aiState);
            } catch (IllegalArgumentException ex) {
                e.currentState = enemy.AIState.PATROL; // 默认状态
            }
            e.direction = enemyData.direction;
            
            // 巡逻相关
            e.patrolStartX = enemyData.patrolStartX;
            e.patrolDirection = enemyData.patrolDirection;
            
            // 敌人属性
            e.damage = enemyData.attackDamage;
            e.detectionRange = enemyData.detectionRange;
            e.attackRange = enemyData.attackRange;
            e.aggressionLevel = enemyData.aggressionLevel;
            
            synchronized(gamePanel.enemies) {
                gamePanel.enemies.add(e);
            }
        }
    }
    
    /**
     * 根据类型名称创建物品实例
     */
    private Item createItemFromType(String itemType) {
        try {
            switch (itemType) {
                case "BowItem":
                    return new item.BowItem("弓箭", 30, 400, 30, 8);
                case "SwordItem":
                    return new item.SwordItem("剑", 50, 80, 20);
                case "BombItem":
                    return new item.BombItem("炸弹", 80, 100, 180, 200);
                case "BlockItem":
                    return new item.BlockItem("方块", 1);
                default:
                    System.err.println("Unknown item type: " + itemType);
                    return null;
            }
        } catch (Exception e) {
            System.err.println("Failed to create item of type " + itemType + ": " + e.getMessage());
            return null;
        }
    }
    
    /**
     * 复制地图数据
     */
    private int[][] copyMapData(int[][] original) {
        if (original == null) return null;
        
        int[][] copy = new int[original.length][];
        for (int i = 0; i < original.length; i++) {
            copy[i] = original[i].clone();
        }
        return copy;
    }
    
    /**
     * 清理文件名中的非法字符
     */
    private String sanitizeFileName(String fileName) {
        return fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
    
    /**
     * 获取所有存档文件列表
     */
    public List<String> getSaveFileList() {
        List<String> saveFiles = new ArrayList<>();
        
        try {
            Path saveDir = Paths.get(SAVE_DIRECTORY);
            if (Files.exists(saveDir)) {
                Files.list(saveDir)
                    .filter(path -> path.toString().endsWith(SAVE_EXTENSION))
                    .forEach(path -> {
                        String fileName = path.getFileName().toString();
                        String saveName = fileName.substring(0, fileName.length() - SAVE_EXTENSION.length());
                        saveFiles.add(saveName);
                    });
            }
        } catch (IOException e) {
            System.err.println("Failed to list save files: " + e.getMessage());
        }
        
        return saveFiles;
    }
    
    /**
     * 删除存档文件
     */
    public boolean deleteSave(String saveName) {
        try {
            String fileName = sanitizeFileName(saveName) + SAVE_EXTENSION;
            Path savePath = Paths.get(SAVE_DIRECTORY, fileName);
            
            if (Files.exists(savePath)) {
                Files.delete(savePath);
                System.out.println("Save deleted: " + savePath);
                return true;
            } else {
                System.err.println("Save file not found: " + savePath);
                return false;
            }
        } catch (IOException e) {
            System.err.println("Failed to delete save: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 检查存档文件是否存在
     */
    public boolean saveExists(String saveName) {
        String fileName = sanitizeFileName(saveName) + SAVE_EXTENSION;
        Path savePath = Paths.get(SAVE_DIRECTORY, fileName);
        return Files.exists(savePath);
    }
    
    /**
     * 获取存档信息（不完全加载）
     */
    public GameSave getSaveInfo(String saveName) {
        try {
            String fileName = sanitizeFileName(saveName) + SAVE_EXTENSION;
            Path savePath = Paths.get(SAVE_DIRECTORY, fileName);
            
            if (!Files.exists(savePath)) {
                return null;
            }
            
            try (ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(Files.newInputStream(savePath)))) {
                return (GameSave) ois.readObject();
            }
            
        } catch (Exception e) {
            System.err.println("Failed to get save info: " + e.getMessage());
            return null;
        }
    }
}