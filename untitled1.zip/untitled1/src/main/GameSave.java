package main;

import entity.enemy;
import item.Inventory;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 游戏存档数据结构类
 * 包含所有需要保存的游戏状态信息
 */
public class GameSave implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // 存档基本信息
    public String saveName;              // 存档名称
    public long saveTime;                // 保存时间戳
    public String gameVersion;           // 游戏版本
    
    // 玩家数据
    public PlayerSaveData playerData;
    
    // 世界数据
    public WorldSaveData worldData;
    
    // 物品栏数据
    public InventorySaveData inventoryData;
    
    // 敌人数据
    public List<EnemySaveData> enemyData;
    
    /**
     * 构造函数
     */
    public GameSave() {
        this.saveTime = System.currentTimeMillis();
        this.gameVersion = "1.0.0";
        this.enemyData = new ArrayList<>();
    }
    
    /**
     * 玩家存档数据
     */
    public static class PlayerSaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        // 位置信息
        public int worldX;
        public int worldY;
        
        // 生命值和状态
        public int health;
        public int maxHealth;
        public int stamina;
        public int maxStamina;
        
        // 战斗属性
        public int attackDamage;
        public int attackRange;
        
        // 移动状态
        public String movementState;        // 移动状态枚举的字符串表示
        public String direction;             // 面向方向
        
        // 游戏进度相关
        public long playTime;                // 游戏时间
        public int level;                    // 玩家等级（如果有）
        public int experience;               // 经验值（如果有）
    }
    
    /**
     * 世界存档数据
     */
    public static class WorldSaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        // 地图数据
        public int[][] mapData;              // 地图瓦片数据
        public int mapWidth;                 // 地图宽度
        public int mapHeight;                // 地图高度
        
        // 地形生成配置
        public TerrainConfigSaveData terrainConfig;
        
        // 世界时间和环境
        public long worldTime;               // 世界时间
        public String weather;               // 天气状态（如果有）
        public int dayNightCycle;            // 昼夜循环状态（如果有）
    }
    
    /**
     * 地形配置存档数据
     */
    public static class TerrainConfigSaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        public long seed;                    // 地形生成种子
        public double noiseScale;            // 噪声缩放
        public int octaves;                  // 噪声层数
        public double persistence;           // 持续性
        public double lacunarity;            // 间隙性
        public int groundLevel;              // 地面高度
        public int groundVariation;          // 地面高度变化范围
        public int surfaceThickness;         // 地表厚度
        public double caveThreshold;         // 洞穴阈值
        public int minCaveSize;              // 最小洞穴大小
        public double oreFrequency;          // 矿物频率
    }
    
    /**
     * 物品栏存档数据
     */
    public static class InventorySaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        public int size;                     // 物品栏大小
        public int selectedSlot;             // 当前选中槽位
        public List<ItemSlotSaveData> slots; // 槽位数据
        
        public InventorySaveData() {
            this.slots = new ArrayList<>();
        }
    }
    
    /**
     * 物品槽存档数据
     */
    public static class ItemSlotSaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        public String itemType;              // 物品类型
        public int quantity;                 // 数量
        public String itemData;              // 物品额外数据（JSON格式）
        
        public ItemSlotSaveData() {}
        
        public ItemSlotSaveData(String itemType, int quantity, String itemData) {
            this.itemType = itemType;
            this.quantity = quantity;
            this.itemData = itemData;
        }
    }
    
    /**
     * 敌人存档数据
     */
    public static class EnemySaveData implements Serializable {
        private static final long serialVersionUID = 1L;
        
        // 位置信息
        public int worldX;
        public int worldY;
        
        // 生命值和状态
        public int health;
        public int maxHealth;
        
        // AI状态
        public String aiState;               // AI状态枚举的字符串表示
        public String direction;             // 面向方向
        
        // 巡逻相关
        public int patrolStartX;             // 巡逻起始点
        public boolean patrolDirection;      // 巡逻方向
        
        // 敌人类型和属性
        public String enemyType;             // 敌人类型
        public int attackDamage;             // 攻击伤害
        public int detectionRange;           // 检测范围
        public int attackRange;              // 攻击范围
        public int aggressionLevel;          // 攻击性等级
    }
    
    /**
     * 获取存档的显示名称
     */
    public String getDisplayName() {
        if (saveName != null && !saveName.isEmpty()) {
            return saveName;
        }
        return "Save " + java.time.Instant.ofEpochMilli(saveTime).toString();
    }
    
    /**
     * 获取格式化的保存时间
     */
    public String getFormattedSaveTime() {
        java.time.LocalDateTime dateTime = java.time.LocalDateTime.ofInstant(
            java.time.Instant.ofEpochMilli(saveTime), 
            java.time.ZoneId.systemDefault()
        );
        return dateTime.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
    
    /**
     * 验证存档数据的完整性
     */
    public boolean isValid() {
        return playerData != null && 
               worldData != null && 
               inventoryData != null &&
               worldData.mapData != null &&
               worldData.mapWidth > 0 &&
               worldData.mapHeight > 0;
    }
}