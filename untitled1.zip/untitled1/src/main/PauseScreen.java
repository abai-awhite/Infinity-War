package main;

import java.awt.*;

/**
 * 暂停页面类
 * 负责渲染暂停菜单界面和处理用户交互
 */
public class PauseScreen {
    // 添加对SaveSlotScreen的引用
    private SaveSlotScreen saveSlotScreen;
    private boolean showingSaveSlots = false;
    private boolean isLoadMode = false;
    private SaveManager saveManager;
    
    public PauseScreen(SaveManager saveManager) {
        this.saveManager = saveManager;
    }
    private int selectedOption = 0; // 当前选中的菜单选项
    private final String[] menuOptions = {"继续游戏", "保存游戏", "加载游戏", "返回主菜单", "退出游戏"};
    
    // 菜单样式配置
    private final Color backgroundColor = new Color(0, 0, 0, 150); // 半透明黑色背景
    private final Color menuBackgroundColor = new Color(40, 40, 40, 200); // 菜单背景
    private final Color selectedColor = new Color(255, 215, 0); // 选中项颜色（金色）
    private final Color normalColor = Color.WHITE; // 普通项颜色
    private final Font titleFont = new Font("微软雅黑", Font.BOLD, 48);
    private final Font menuFont = new Font("微软雅黑", Font.PLAIN, 24);
    
    /**
     * 渲染暂停页面
     * @param g2 图形上下文
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     */
    public void draw(Graphics2D g2, int screenWidth, int screenHeight) {
        // 如果正在显示存档选择界面，则绘制存档选择界面
        if (showingSaveSlots) {
            // 如果SaveSlotScreen对象为空，则创建它
            if (saveSlotScreen == null) {
                saveSlotScreen = new SaveSlotScreen(saveManager, isLoadMode);
            }
            saveSlotScreen.draw(g2, screenWidth, screenHeight);
            return;
        }
        
        // 绘制半透明背景覆盖整个屏幕
        g2.setColor(backgroundColor);
        g2.fillRect(0, 0, screenWidth, screenHeight);
        
        // 计算菜单位置和尺寸
        int menuWidth = 400;
        int menuHeight = 380; // 增加高度以适应新的菜单选项
        int menuX = (screenWidth - menuWidth) / 2;
        int menuY = (screenHeight - menuHeight) / 2;
        
        // 绘制菜单背景
        g2.setColor(menuBackgroundColor);
        g2.fillRoundRect(menuX, menuY, menuWidth, menuHeight, 20, 20);
        
        // 绘制菜单边框
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(menuX, menuY, menuWidth, menuHeight, 20, 20);
        
        // 绘制标题
        g2.setFont(titleFont);
        g2.setColor(Color.WHITE);
        String title = "游戏暂停";
        FontMetrics titleMetrics = g2.getFontMetrics(titleFont);
        int titleX = menuX + (menuWidth - titleMetrics.stringWidth(title)) / 2;
        int titleY = menuY + 80;
        g2.drawString(title, titleX, titleY);
        
        // 绘制菜单选项
        g2.setFont(menuFont);
        FontMetrics menuMetrics = g2.getFontMetrics(menuFont);
        
        for (int i = 0; i < menuOptions.length; i++) {
            // 设置选中项和普通项的颜色
            if (i == selectedOption) {
                g2.setColor(selectedColor);
                // 绘制选中项的背景高亮
                int optionY = titleY + 60 + i * 40;
                int optionX = menuX + (menuWidth - menuMetrics.stringWidth(menuOptions[i])) / 2;
                g2.fillRoundRect(optionX - 10, optionY - 25, menuMetrics.stringWidth(menuOptions[i]) + 20, 35, 5, 5);
                g2.setColor(Color.BLACK);
            } else {
                g2.setColor(normalColor);
            }
            
            // 绘制菜单选项文本
            int optionY = titleY + 60 + i * 40;
            int optionX = menuX + (menuWidth - menuMetrics.stringWidth(menuOptions[i])) / 2;
            g2.drawString(menuOptions[i], optionX, optionY);
        }
        
        // 绘制操作提示
        g2.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        g2.setColor(Color.LIGHT_GRAY);
        String hint = "使用↑↓键或鼠标选择，回车键或点击确认，ESC键返回游戏";
        FontMetrics hintMetrics = g2.getFontMetrics();
        int hintX = menuX + (menuWidth - hintMetrics.stringWidth(hint)) / 2;
        int hintY = menuY + menuHeight - 30;
        g2.drawString(hint, hintX, hintY);
    }
    
    /**
     * 处理暂停页面的输入
     * @param KB 键盘输入对象
     * @return 返回用户选择的操作（0=无操作，1=继续游戏，2=保存游戏，3=加载游戏，4=返回主菜单，5=退出游戏）
     */
    public int handleInput(KeyBoard KB) {
        return handleInput(KB, 0, 0, 800, 600);
    }
    
    /**
     * 处理暂停页面的输入（支持鼠标）
     * @param KB 键盘输入对象
     * @param mouseX 鼠标X坐标
     * @param mouseY 鼠标Y坐标
     * @param screenWidth 屏幕宽度
     * @param screenHeight 屏幕高度
     * @return 返回用户选择的操作（0=无操作，1=继续游戏，2=保存游戏，3=加载游戏，4=返回主菜单，5=退出游戏）
     */
    public int handleInput(KeyBoard KB, int mouseX, int mouseY, int screenWidth, int screenHeight) {
        // 如果正在显示存档选择界面，则处理存档选择界面的输入
        if (showingSaveSlots) {
            int result = saveSlotScreen.handleInput(KB);
            
            if (result == 1) { // 返回上一级菜单
                showingSaveSlots = false;
                return 0;
            } else if (result == 2) { // 选择了存档
                String saveName = saveSlotScreen.getSelectedSaveName();
                if (saveName != null) {
                    showingSaveSlots = false;
                    if (isLoadMode) {
                        // 返回加载游戏操作，GamePanel会处理具体的加载逻辑
                        return 3;
                    } else {
                        // 返回保存游戏操作，GamePanel会处理具体的保存逻辑
                        return 2;
                    }
                }
            }
            
            return 0; // 无操作
        }
        
        // 计算菜单位置和尺寸（与draw方法中的计算保持一致）
        int menuWidth = 400;
        int menuHeight = 380; // 增加高度以适应新的菜单选项
        int menuX = (screenWidth - menuWidth) / 2;
        int menuY = (screenHeight - menuHeight) / 2;
        int titleY = menuY + 80;
        
        // 处理鼠标悬停检测
        Font menuFont = new Font("微软雅黑", Font.PLAIN, 24);
        FontMetrics menuMetrics = new Canvas().getFontMetrics(menuFont);
        
        for (int i = 0; i < menuOptions.length; i++) {
            int optionY = titleY + 60 + i * 40;
            int optionX = menuX + (menuWidth - menuMetrics.stringWidth(menuOptions[i])) / 2;
            int optionWidth = menuMetrics.stringWidth(menuOptions[i]) + 20;
            int optionHeight = 35;
            
            // 检查鼠标是否悬停在选项上
            if (mouseX >= optionX - 10 && mouseX <= optionX - 10 + optionWidth &&
                mouseY >= optionY - 25 && mouseY <= optionY - 25 + optionHeight) {
                selectedOption = i;
                
                // 检查鼠标左键点击
                if (KB.mousePressed) {
                    KB.mousePressed = false; // 重置鼠标状态
                    
                    // 处理保存游戏和加载游戏选项，显示存档选择界面
                    if (selectedOption == 1) { // 保存游戏
                        showingSaveSlots = true;
                        isLoadMode = false;
                        saveSlotScreen = new SaveSlotScreen(saveManager, isLoadMode);
                        return 0;
                    } else if (selectedOption == 2) { // 加载游戏
                        showingSaveSlots = true;
                        isLoadMode = true;
                        saveSlotScreen = new SaveSlotScreen(saveManager, isLoadMode);
                        return 0;
                    }
                    
                    return selectedOption + 1; // 返回其他选择结果
                }
            }
        }
        
        // 处理上下箭头键选择
        if (KB.upArrowPressed) {
            selectedOption = (selectedOption - 1 + menuOptions.length) % menuOptions.length;
            KB.upArrowPressed = false; // 重置按键状态
        }
        if (KB.downArrowPressed) {
            selectedOption = (selectedOption + 1) % menuOptions.length;
            KB.downArrowPressed = false; // 重置按键状态
        }
        
        // 处理回车键确认选择
        if (KB.enterPressed) {
            KB.enterPressed = false; // 重置按键状态
            
            // 处理保存游戏和加载游戏选项，显示存档选择界面
            if (selectedOption == 1) { // 保存游戏
                showingSaveSlots = true;
                isLoadMode = false;
                saveSlotScreen = new SaveSlotScreen(saveManager, isLoadMode);
                return 0;
            } else if (selectedOption == 2) { // 加载游戏
                showingSaveSlots = true;
                isLoadMode = true;
                saveSlotScreen = new SaveSlotScreen(saveManager, isLoadMode);
                return 0;
            }
            
            return selectedOption + 1; // 返回其他选择结果
        }
        
        // 处理ESC键直接返回游戏
        if (KB.escPressed) {
            KB.escPressed = false; // 重置按键状态
            return 1; // 返回继续游戏
        }
        
        return 0; // 无操作
    }
    
    /**
     * 重置菜单选择
     */
    public void reset() {
        selectedOption = 0;
        showingSaveSlots = false;
        if (saveSlotScreen != null) {
            saveSlotScreen.reset();
        }
    }
    
    /**
     * 获取选中的存档名称
     */
    public String getSelectedSaveName() {
        if (showingSaveSlots && saveSlotScreen != null) {
            return saveSlotScreen.getSelectedSaveName();
        }
        return null;
    }
}