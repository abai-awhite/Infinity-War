package main;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

/**
 * 游戏开始页面类
 * 负责显示游戏标题、开始按钮和基本操作说明
 * 处理开始页面的用户交互
 */
public class StartScreen {
    private GamePanel gp;
    private Font titleFont;
    private Font buttonFont;
    private Font instructionFont;
    
    // UI颜色
    private Color backgroundColor = new Color(20, 20, 30);
    private Color titleColor = new Color(255, 215, 0); // 金色
    private Color buttonColor = new Color(100, 150, 255); // 蓝色
    private Color instructionColor = new Color(200, 200, 200); // 灰色
    private Color highlightColor = new Color(255, 255, 255); // 白色高亮
    
    // 按钮状态
    private boolean startButtonHighlighted = true;
    private int selectedOption = 0; // 0=开始游戏, 1=联机游戏, 2=设置, 3=退出游戏
    
    // 按钮区域
    private Rectangle startButtonRect;
    private Rectangle multiplayerButtonRect;
    private Rectangle settingsButtonRect;
    private Rectangle exitButtonRect;
    
    // 联机相关
    private boolean inMultiplayerMenu = false;
    private String serverAddress = "localhost";
    private String serverPort = "12345";
    private String playerName = "Player";
    private int multiplayerSelectedField = 0; // 0=服务器地址, 1=端口, 2=玩家名称, 3=连接, 4=开设服务器, 5=Echo消息, 6=发送Echo, 7=返回
    private boolean editingField = false;
    private String currentInput = "";
    private Rectangle[] multiplayerFieldRects = new Rectangle[8];
    private String echoMessage = "Hello World"; // Echo测试消息
    private boolean isServerRunning = false; // 服务器是否运行中
    
    // 设置界面相关
    private boolean inSettingsMenu = false;
    private int selectedSettingOption = 0;
    private String[] settingActions;
    private boolean waitingForKeyInput = false;
    private String currentEditingAction = null;
    private KeySettings keySettings;
    
    public StartScreen(GamePanel gp) {
        this.gp = gp;
        initializeFonts();
        keySettings = KeySettings.getInstance();
        keySettings.loadSettings(); // 加载保存的按键设置
        initializeSettingActions();
        keySettingRects = new Rectangle[settingActions.length]; // 初始化按键设置矩形数组
    }
    
    /**
     * 初始化设置选项
     */
    private void initializeSettingActions() {
        settingActions = new String[]{
            KeySettings.MOVE_UP, KeySettings.MOVE_DOWN, KeySettings.MOVE_LEFT, KeySettings.MOVE_RIGHT,
            KeySettings.JUMP, KeySettings.RUN, KeySettings.SPRINT, KeySettings.INVENTORY,
            KeySettings.MENU_UP, KeySettings.MENU_DOWN, KeySettings.CONFIRM,
            KeySettings.ITEM_1, KeySettings.ITEM_2, KeySettings.ITEM_3, KeySettings.ITEM_4, KeySettings.ITEM_5,
            KeySettings.ITEM_6, KeySettings.ITEM_7, KeySettings.ITEM_8, KeySettings.ITEM_9
        };
    }
    
    /**
     * 初始化字体
     */
    private void initializeFonts() {
        try {
            // 使用支持中文的字体
            titleFont = new Font("Microsoft YaHei", Font.BOLD, 48);
            buttonFont = new Font("Microsoft YaHei", Font.BOLD, 24);
            instructionFont = new Font("Microsoft YaHei", Font.PLAIN, 16);
        } catch (Exception e) {
            try {
                // 如果微软雅黑不可用，尝试使用宋体
                titleFont = new Font("SimSun", Font.BOLD, 48);
                buttonFont = new Font("SimSun", Font.BOLD, 24);
                instructionFont = new Font("SimSun", Font.PLAIN, 16);
            } catch (Exception e2) {
                // 使用默认字体作为最后后备
                titleFont = new Font(Font.SANS_SERIF, Font.BOLD, 48);
                buttonFont = new Font(Font.SANS_SERIF, Font.BOLD, 24);
                instructionFont = new Font(Font.SANS_SERIF, Font.PLAIN, 16);
            }
        }
    }
    
    /**
     * 绘制开始页面
     */
    public void draw(Graphics2D g2) {
        if (inSettingsMenu) {
            drawSettingsMenu(g2);
        } else if (inMultiplayerMenu) {
            drawMultiplayerMenu(g2);
        } else {
            // 绘制背景
            g2.setColor(backgroundColor);
            g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
            
            // 绘制游戏标题
            drawTitle(g2);
            
            // 绘制菜单选项
            drawMenuOptions(g2);
            
            // 绘制操作说明
            drawInstructions(g2);
        }
    }
    
    /**
     * 绘制游戏标题
     */
    private void drawTitle(Graphics2D g2) {
        g2.setFont(titleFont);
        g2.setColor(titleColor);
        
        String title = "无限战争";
        FontMetrics fm = g2.getFontMetrics();
        int titleWidth = fm.stringWidth(title);
        int titleX = (gp.screenWidth - titleWidth) / 2;
        int titleY = gp.screenHeight / 4;
        
        g2.drawString(title, titleX, titleY);
        
        // 添加标题下划线效果
        g2.setStroke(new BasicStroke(3));
        g2.drawLine(titleX, titleY + 10, titleX + titleWidth, titleY + 10);
    }
    
    /**
     * 绘制菜单选项
     */
    private void drawMenuOptions(Graphics2D g2) {
        g2.setFont(buttonFont);
        
        int centerX = gp.screenWidth / 2;
        int startY = gp.screenHeight / 2;
        int optionSpacing = 60;
        
        // 开始游戏选项
        String startText = "开始游戏";
        FontMetrics fm = g2.getFontMetrics();
        int startWidth = fm.stringWidth(startText);
        int startX = centerX - startWidth / 2;
        
        // 计算开始按钮的点击区域
        startButtonRect = new Rectangle(startX - 10, startY - 30, startWidth + 20, 40);
        
        if (selectedOption == 0) {
            g2.setColor(highlightColor);
            // 绘制选中框
            g2.drawRect(startButtonRect.x, startButtonRect.y, startButtonRect.width, startButtonRect.height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(startText, startX, startY);
        
        // 联机游戏选项
        String multiplayerText = "联机游戏";
        int multiplayerWidth = fm.stringWidth(multiplayerText);
        int multiplayerX = centerX - multiplayerWidth / 2;
        int multiplayerY = startY + optionSpacing;
        
        // 计算联机按钮的点击区域
        multiplayerButtonRect = new Rectangle(multiplayerX - 10, multiplayerY - 30, multiplayerWidth + 20, 40);
        
        if (selectedOption == 1) {
            g2.setColor(highlightColor);
            // 绘制选中框
            g2.drawRect(multiplayerButtonRect.x, multiplayerButtonRect.y, multiplayerButtonRect.width, multiplayerButtonRect.height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(multiplayerText, multiplayerX, multiplayerY);
        
        // 设置选项
        String settingsText = "设置";
        int settingsWidth = fm.stringWidth(settingsText);
        int settingsX = centerX - settingsWidth / 2;
        int settingsY = startY + 2 * optionSpacing;
        
        // 计算设置按钮的点击区域
        settingsButtonRect = new Rectangle(settingsX - 10, settingsY - 30, settingsWidth + 20, 40);
        
        if (selectedOption == 2) {
            g2.setColor(highlightColor);
            // 绘制选中框
            g2.drawRect(settingsButtonRect.x, settingsButtonRect.y, settingsButtonRect.width, settingsButtonRect.height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(settingsText, settingsX, settingsY);
        
        // 退出游戏选项
        String exitText = "退出游戏";
        int exitWidth = fm.stringWidth(exitText);
        int exitX = centerX - exitWidth / 2;
        int exitY = startY + 3 * optionSpacing;
        
        // 计算退出按钮的点击区域
        exitButtonRect = new Rectangle(exitX - 10, exitY - 30, exitWidth + 20, 40);
        
        if (selectedOption == 3) {
            g2.setColor(highlightColor);
            // 绘制选中框
            g2.drawRect(exitButtonRect.x, exitButtonRect.y, exitButtonRect.width, exitButtonRect.height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(exitText, exitX, exitY);
    }
    
    /**
     * 绘制联机菜单
     */
    private void drawMultiplayerMenu(Graphics2D g2) {
        // 绘制背景
        g2.setColor(backgroundColor);
        g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        
        // 绘制标题
        g2.setFont(titleFont);
        g2.setColor(titleColor);
        String title = "联机游戏";
        FontMetrics titleFm = g2.getFontMetrics();
        int titleX = (gp.screenWidth - titleFm.stringWidth(title)) / 2;
        g2.drawString(title, titleX, 150);
        
        g2.setFont(buttonFont);
        int centerX = gp.screenWidth / 2;
        int startY = 250;
        int fieldSpacing = 60;
        
        // 服务器地址输入框
        String addressLabel = "服务器地址:";
        g2.setColor(buttonColor);
        g2.drawString(addressLabel, centerX - 200, startY);
        
        multiplayerFieldRects[0] = new Rectangle(centerX - 50, startY - 25, 200, 30);
        if (multiplayerSelectedField == 0) {
            g2.setColor(highlightColor);
        } else {
            g2.setColor(Color.WHITE);
        }
        g2.fillRect(multiplayerFieldRects[0].x, multiplayerFieldRects[0].y, multiplayerFieldRects[0].width, multiplayerFieldRects[0].height);
        g2.setColor(Color.BLACK);
        g2.drawRect(multiplayerFieldRects[0].x, multiplayerFieldRects[0].y, multiplayerFieldRects[0].width, multiplayerFieldRects[0].height);
        String displayAddress = (editingField && multiplayerSelectedField == 0) ? currentInput : serverAddress;
        g2.drawString(displayAddress, multiplayerFieldRects[0].x + 5, multiplayerFieldRects[0].y + 20);
        
        // 端口输入框
        String portLabel = "端口:";
        g2.setColor(buttonColor);
        g2.drawString(portLabel, centerX - 200, startY + fieldSpacing);
        
        multiplayerFieldRects[1] = new Rectangle(centerX - 50, startY + fieldSpacing - 25, 200, 30);
        if (multiplayerSelectedField == 1) {
            g2.setColor(highlightColor);
        } else {
            g2.setColor(Color.WHITE);
        }
        g2.fillRect(multiplayerFieldRects[1].x, multiplayerFieldRects[1].y, multiplayerFieldRects[1].width, multiplayerFieldRects[1].height);
        g2.setColor(Color.BLACK);
        g2.drawRect(multiplayerFieldRects[1].x, multiplayerFieldRects[1].y, multiplayerFieldRects[1].width, multiplayerFieldRects[1].height);
        String displayPort = (editingField && multiplayerSelectedField == 1) ? currentInput : serverPort;
        g2.drawString(displayPort, multiplayerFieldRects[1].x + 5, multiplayerFieldRects[1].y + 20);
        
        // 玩家名称输入框
        String nameLabel = "玩家名称:";
        g2.setColor(buttonColor);
        g2.drawString(nameLabel, centerX - 200, startY + 2 * fieldSpacing);
        
        multiplayerFieldRects[2] = new Rectangle(centerX - 50, startY + 2 * fieldSpacing - 25, 200, 30);
        if (multiplayerSelectedField == 2) {
            g2.setColor(highlightColor);
        } else {
            g2.setColor(Color.WHITE);
        }
        g2.fillRect(multiplayerFieldRects[2].x, multiplayerFieldRects[2].y, multiplayerFieldRects[2].width, multiplayerFieldRects[2].height);
        g2.setColor(Color.BLACK);
        g2.drawRect(multiplayerFieldRects[2].x, multiplayerFieldRects[2].y, multiplayerFieldRects[2].width, multiplayerFieldRects[2].height);
        String displayName = (editingField && multiplayerSelectedField == 2) ? currentInput : playerName;
        g2.drawString(displayName, multiplayerFieldRects[2].x + 5, multiplayerFieldRects[2].y + 20);
        
        // 连接按钮
        String connectText = "连接服务器";
        FontMetrics fm = g2.getFontMetrics();
        int connectWidth = fm.stringWidth(connectText);
        int connectX = centerX - connectWidth / 2;
        int connectY = startY + 3 * fieldSpacing + 20;
        
        multiplayerFieldRects[3] = new Rectangle(connectX - 10, connectY - 25, connectWidth + 20, 30);
        if (multiplayerSelectedField == 3) {
            g2.setColor(highlightColor);
            g2.drawRect(multiplayerFieldRects[3].x, multiplayerFieldRects[3].y, multiplayerFieldRects[3].width, multiplayerFieldRects[3].height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(connectText, connectX, connectY);
        
        // 开设服务器按钮
        String hostServerText = isServerRunning ? "服务器运行中" : "开设服务器";
        int hostServerWidth = fm.stringWidth(hostServerText);
        int hostServerX = centerX - hostServerWidth / 2;
        int hostServerY = startY + 4 * fieldSpacing;
        
        multiplayerFieldRects[4] = new Rectangle(hostServerX - 10, hostServerY - 25, hostServerWidth + 20, 30);
        if (multiplayerSelectedField == 4) {
            g2.setColor(highlightColor);
            g2.drawRect(multiplayerFieldRects[4].x, multiplayerFieldRects[4].y, multiplayerFieldRects[4].width, multiplayerFieldRects[4].height);
        } else {
            g2.setColor(isServerRunning ? new Color(100, 200, 100) : buttonColor);
        }
        g2.drawString(hostServerText, hostServerX, hostServerY);
        
        // Echo测试消息输入框
        String echoMsgLabel = "Echo消息:";
        g2.setColor(buttonColor);
        g2.drawString(echoMsgLabel, centerX - 200, startY + 5 * fieldSpacing + 20);
        
        multiplayerFieldRects[5] = new Rectangle(centerX - 50, startY + 5 * fieldSpacing - 5, 200, 30);
        if (multiplayerSelectedField == 5) {
            g2.setColor(highlightColor);
        } else {
            g2.setColor(Color.WHITE);
        }
        g2.fillRect(multiplayerFieldRects[5].x, multiplayerFieldRects[5].y, multiplayerFieldRects[5].width, multiplayerFieldRects[5].height);
        g2.setColor(Color.BLACK);
        g2.drawRect(multiplayerFieldRects[5].x, multiplayerFieldRects[5].y, multiplayerFieldRects[5].width, multiplayerFieldRects[5].height);
        String displayEchoMsg = (editingField && multiplayerSelectedField == 5) ? currentInput : echoMessage;
        g2.drawString(displayEchoMsg, multiplayerFieldRects[5].x + 5, multiplayerFieldRects[5].y + 20);
        
        // Echo测试按钮
        String echoText = "发送Echo";
        FontMetrics echoFm = g2.getFontMetrics();
        int echoWidth = echoFm.stringWidth(echoText);
        int echoX = centerX - echoWidth / 2;
        int echoY = startY + 6 * fieldSpacing;
        
        multiplayerFieldRects[6] = new Rectangle(echoX - 10, echoY - 25, echoWidth + 20, 30);
        if (multiplayerSelectedField == 6) {
            g2.setColor(highlightColor);
            g2.drawRect(multiplayerFieldRects[6].x, multiplayerFieldRects[6].y, multiplayerFieldRects[6].width, multiplayerFieldRects[6].height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(echoText, echoX, echoY);
        
        // 返回按钮
        String backText = "返回";
        FontMetrics backFm = g2.getFontMetrics();
        int backWidth = backFm.stringWidth(backText);
        int backX = centerX - backWidth / 2;
        int backY = startY + 7 * fieldSpacing;
        
        multiplayerFieldRects[7] = new Rectangle(backX - 10, backY - 25, backWidth + 20, 30);
        if (multiplayerSelectedField == 7) {
            g2.setColor(highlightColor);
            g2.drawRect(multiplayerFieldRects[7].x, multiplayerFieldRects[7].y, multiplayerFieldRects[7].width, multiplayerFieldRects[7].height);
        } else {
            g2.setColor(buttonColor);
        }
        g2.drawString(backText, backX, backY);
    }
    
    /**
     * 绘制操作说明
     */
    private void drawInstructions(Graphics2D g2) {
        g2.setFont(instructionFont);
        g2.setColor(instructionColor);
        
        String[] instructions = {
            "操作说明：",
            "WASD - 移动",
            "空格 - 跳跃",
            "鼠标左键 - 攻击/射击/点击",
            "数字键1-9 - 选择物品",
            "↑↓ - 选择菜单",
            "回车 - 确认选择",
            "鼠标 - 点击按钮"
        };
        
        int instructionX = 50;
        int instructionY = gp.screenHeight - 200;
        int lineSpacing = 25;
        
        for (int i = 0; i < instructions.length; i++) {
            if (i == 0) {
                g2.setColor(titleColor);
            } else {
                g2.setColor(instructionColor);
            }
            g2.drawString(instructions[i], instructionX, instructionY + i * lineSpacing);
        }
    }
    
    /**
     * 处理键盘输入
     */
    public void handleKeyInput(KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        if (inSettingsMenu) {
            handleSettingsKeyInput(e);
        } else if (inMultiplayerMenu) {
            handleMultiplayerKeyInput(e);
        } else {
            switch (keyCode) {
                case KeyEvent.VK_UP:
                    selectedOption = Math.max(0, selectedOption - 1);
                    break;
                case KeyEvent.VK_DOWN:
                    selectedOption = Math.min(3, selectedOption + 1);
                    break;
                case KeyEvent.VK_ENTER:
                    executeSelectedOption();
                    break;
                case KeyEvent.VK_SPACE:
                    if (selectedOption == 0) {
                        executeSelectedOption();
                    }
                    break;
            }
        }
    }
    
    /**
     * 处理鼠标点击
     */
    public void handleMouseClick(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) { // 左键点击
            Point clickPoint = e.getPoint();
            
            if (inSettingsMenu) {
                handleSettingsMouseClick(e);
            } else if (inMultiplayerMenu) {
                handleMultiplayerMouseClick(e);
            } else {
                if (startButtonRect != null && startButtonRect.contains(clickPoint)) {
                    selectedOption = 0;
                    executeSelectedOption();
                } else if (multiplayerButtonRect != null && multiplayerButtonRect.contains(clickPoint)) {
                    selectedOption = 1;
                    executeSelectedOption();
                } else if (settingsButtonRect != null && settingsButtonRect.contains(clickPoint)) {
                    selectedOption = 2;
                    executeSelectedOption();
                } else if (exitButtonRect != null && exitButtonRect.contains(clickPoint)) {
                    selectedOption = 3;
                    executeSelectedOption();
                }
            }
        }
    }
    
    /**
     * 处理鼠标移动（用于高亮按钮）
     */
    public void handleMouseMove(MouseEvent e) {
        Point mousePoint = e.getPoint();
        
        if (inSettingsMenu) {
            handleSettingsMouseMove(e);
        } else if (inMultiplayerMenu) {
            handleMultiplayerMouseMove(e);
        } else {
            if (startButtonRect != null && startButtonRect.contains(mousePoint)) {
                selectedOption = 0;
            } else if (multiplayerButtonRect != null && multiplayerButtonRect.contains(mousePoint)) {
                selectedOption = 1;
            } else if (settingsButtonRect != null && settingsButtonRect.contains(mousePoint)) {
                selectedOption = 2;
            } else if (exitButtonRect != null && exitButtonRect.contains(mousePoint)) {
                selectedOption = 3;
            }
        }
    }
    
    /**
     * 执行选中的选项
     */
    private void executeSelectedOption() {
        switch (selectedOption) {
            case 0: // 开始游戏
                gp.startGame();
                break;
            case 1: // 联机游戏
                inMultiplayerMenu = true;
                multiplayerSelectedField = 0;
                break;
            case 2: // 设置
                inSettingsMenu = true;
                selectedSettingOption = 0;
                break;
            case 3: // 退出游戏
                System.exit(0);
                break;
        }
    }
    
    // 设置界面相关变量
    private Rectangle backButtonRect;
    private Rectangle resetButtonRect;
    private Rectangle[] keySettingRects;
    
    /**
     * 绘制设置菜单
     */
    private void drawSettingsMenu(Graphics2D g2) {
        // 绘制半透明背景
        g2.setColor(new Color(0, 0, 0, 180));
        g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);
        
        // 绘制设置面板
        int panelWidth = 700;
        int panelHeight = 600;
        int panelX = (gp.screenWidth - panelWidth) / 2;
        int panelY = (gp.screenHeight - panelHeight) / 2;
        
        g2.setColor(new Color(40, 40, 40, 220));
        g2.fillRoundRect(panelX, panelY, panelWidth, panelHeight, 20, 20);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(panelX, panelY, panelWidth, panelHeight, 20, 20);
        
        // 绘制标题
        g2.setFont(new Font("Microsoft YaHei", Font.BOLD, 32));
        String title = "按键设置";
        FontMetrics titleFm = g2.getFontMetrics();
        int titleX = panelX + (panelWidth - titleFm.stringWidth(title)) / 2;
        int titleY = panelY + 50;
        g2.setColor(titleColor);
        g2.drawString(title, titleX, titleY);
        
        // 绘制按键设置选项
        g2.setFont(instructionFont);
        FontMetrics fm = g2.getFontMetrics();
        
        int optionY = titleY + 60;
        int optionSpacing = 25;
        int maxVisibleOptions = 15;
        int scrollOffset = Math.max(0, selectedSettingOption - maxVisibleOptions + 1);
        
        for (int i = 0; i < Math.min(settingActions.length, maxVisibleOptions); i++) {
            int actualIndex = i + scrollOffset;
            if (actualIndex >= settingActions.length) break;
            
            String action = settingActions[actualIndex];
            String actionName = getActionDisplayName(action);
            int keyCode = keySettings.getKeyCode(action);
            String keyText = KeyEvent.getKeyText(keyCode);
            
            int currentY = optionY + i * optionSpacing;
            
            // 绘制选项背景
            if (selectedSettingOption == actualIndex) {
                g2.setColor(new Color(100, 149, 237, 100));
                g2.fillRoundRect(panelX + 20, currentY - 15, panelWidth - 40, 20, 5, 5);
            }
            
            // 绘制动作名称
            g2.setColor(Color.WHITE);
            g2.drawString(actionName + ":", panelX + 30, currentY);
            
            // 绘制按键
            g2.setColor(buttonColor);
            String displayText = waitingForKeyInput && currentEditingAction != null && 
                               currentEditingAction.equals(action) ? "按下新键..." : keyText;
            g2.drawString(displayText, panelX + 300, currentY);
            
            // 保存按钮区域用于鼠标点击
            keySettingRects[actualIndex] = new Rectangle(panelX + 20, currentY - 15, panelWidth - 40, 20);
        }
        
        // 绘制重置按钮
        int buttonWidth = 120;
        int buttonHeight = 40;
        int buttonSpacing = 20;
        int resetButtonX = panelX + panelWidth - 2 * buttonWidth - buttonSpacing - 30;
        int resetButtonY = panelY + panelHeight - buttonHeight - 30;
        resetButtonRect = new Rectangle(resetButtonX, resetButtonY, buttonWidth, buttonHeight);
        
        if (selectedSettingOption == settingActions.length + 1) {
            g2.setColor(new Color(220, 20, 60, 200)); // 红色高亮
        } else {
            g2.setColor(new Color(70, 70, 70, 150));
        }
        g2.fillRoundRect(resetButtonX, resetButtonY, buttonWidth, buttonHeight, 10, 10);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(resetButtonX, resetButtonY, buttonWidth, buttonHeight, 10, 10);
        
        g2.setFont(buttonFont);
        String resetText = "重置";
        FontMetrics resetFm = g2.getFontMetrics();
        int resetTextX = resetButtonX + (buttonWidth - resetFm.stringWidth(resetText)) / 2;
        int resetTextY = resetButtonY + (buttonHeight + resetFm.getAscent()) / 2 - 2;
        g2.setColor(Color.WHITE);
        g2.drawString(resetText, resetTextX, resetTextY);
        
        // 绘制返回按钮
        int backButtonX = panelX + panelWidth - buttonWidth - 30;
        int backButtonY = panelY + panelHeight - buttonHeight - 30;
        backButtonRect = new Rectangle(backButtonX, backButtonY, buttonWidth, buttonHeight);
        
        if (selectedSettingOption == settingActions.length) {
            g2.setColor(new Color(100, 149, 237, 200));
        } else {
            g2.setColor(new Color(70, 70, 70, 150));
        }
        g2.fillRoundRect(backButtonX, backButtonY, buttonWidth, buttonHeight, 10, 10);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(backButtonX, backButtonY, buttonWidth, buttonHeight, 10, 10);
        
        g2.setFont(buttonFont);
        String backText = "返回";
        FontMetrics backFm = g2.getFontMetrics();
        int backTextX = backButtonX + (buttonWidth - backFm.stringWidth(backText)) / 2;
        int backTextY = backButtonY + (buttonHeight + backFm.getAscent()) / 2 - 2;
        g2.setColor(Color.WHITE);
        g2.drawString(backText, backTextX, backTextY);
        
        // 如果正在等待按键输入，显示提示
        if (waitingForKeyInput) {
            g2.setColor(new Color(255, 255, 0, 200));
            g2.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
            String prompt = "请按下新的按键...";
            FontMetrics promptFm = g2.getFontMetrics();
            int promptX = (gp.screenWidth - promptFm.stringWidth(prompt)) / 2;
            int promptY = panelY + panelHeight + 50;
            g2.drawString(prompt, promptX, promptY);
        }
    }
    
    /**
     * 获取动作的显示名称
     */
    private String getActionDisplayName(String action) {
        switch (action) {
            case KeySettings.MOVE_UP: return "上移";
            case KeySettings.MOVE_DOWN: return "下移";
            case KeySettings.MOVE_LEFT: return "左移";
            case KeySettings.MOVE_RIGHT: return "右移";
            case KeySettings.JUMP: return "跳跃";
            case KeySettings.RUN: return "奔跑";
            case KeySettings.SPRINT: return "冲刺";
            case KeySettings.INVENTORY: return "背包";
            case KeySettings.MENU_UP: return "菜单上";
            case KeySettings.MENU_DOWN: return "菜单下";
            case KeySettings.CONFIRM: return "确认";
            case KeySettings.ITEM_1: return "物品1";
            case KeySettings.ITEM_2: return "物品2";
            case KeySettings.ITEM_3: return "物品3";
            case KeySettings.ITEM_4: return "物品4";
            case KeySettings.ITEM_5: return "物品5";
            case KeySettings.ITEM_6: return "物品6";
            case KeySettings.ITEM_7: return "物品7";
            case KeySettings.ITEM_8: return "物品8";
            case KeySettings.ITEM_9: return "物品9";
            default: return action;
        }
    }
    
    /**
     * 处理设置界面的键盘输入
     */
    private void handleSettingsKeyInput(KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        if (waitingForKeyInput) {
            // 如果按下ESC，取消按键设置
            if (keyCode == KeyEvent.VK_ESCAPE) {
                waitingForKeyInput = false;
                currentEditingAction = null;
                return;
            }
            
            // 设置新的按键
            if (currentEditingAction != null) {
                keySettings.setKeyCode(currentEditingAction, keyCode);
                keySettings.saveSettings(); // 立即保存按键设置
                waitingForKeyInput = false;
                currentEditingAction = null;
            }
            return;
        }
        
        switch (keyCode) {
            case KeyEvent.VK_UP:
                selectedSettingOption = Math.max(0, selectedSettingOption - 1);
                break;
            case KeyEvent.VK_DOWN:
                selectedSettingOption = Math.min(settingActions.length + 1, selectedSettingOption + 1);
                break;
            case KeyEvent.VK_ENTER:
                executeSettingOption();
                break;
            case KeyEvent.VK_ESCAPE:
                inSettingsMenu = false;
                selectedSettingOption = 0;
                break;
        }
    }
    
    /**
     * 处理设置界面的鼠标点击
     */
    private void handleSettingsMouseClick(MouseEvent e) {
        Point clickPoint = e.getPoint();
        
        if (waitingForKeyInput) {
            return; // 等待按键输入时忽略鼠标点击
        }
        
        // 检查返回按钮
        if (backButtonRect != null && backButtonRect.contains(clickPoint)) {
            inSettingsMenu = false;
            selectedSettingOption = 0;
            return;
        }
        
        // 检查重置按钮
        if (resetButtonRect != null && resetButtonRect.contains(clickPoint)) {
            selectedSettingOption = settingActions.length + 1;
            executeSettingOption();
            return;
        }
        
        // 检查按键设置选项
        for (int i = 0; i < settingActions.length; i++) {
            if (keySettingRects[i] != null && keySettingRects[i].contains(clickPoint)) {
                selectedSettingOption = i;
                executeSettingOption();
                return;
            }
        }
    }
    
    /**
     * 处理设置界面的鼠标移动
     */
    private void handleSettingsMouseMove(MouseEvent e) {
        Point mousePoint = e.getPoint();
        
        if (waitingForKeyInput) {
            return; // 等待按键输入时忽略鼠标移动
        }
        
        // 检查返回按钮
        if (backButtonRect != null && backButtonRect.contains(mousePoint)) {
            selectedSettingOption = settingActions.length;
            return;
        }
        
        // 检查重置按钮
        if (resetButtonRect != null && resetButtonRect.contains(mousePoint)) {
            selectedSettingOption = settingActions.length + 1;
            return;
        }
        
        // 检查按键设置选项
        for (int i = 0; i < settingActions.length; i++) {
            if (keySettingRects[i] != null && keySettingRects[i].contains(mousePoint)) {
                selectedSettingOption = i;
                return;
            }
        }
    }
    
    /**
     * 执行设置选项
     */
    private void executeSettingOption() {
        if (selectedSettingOption < settingActions.length) {
            // 开始等待新的按键输入
            waitingForKeyInput = true;
            currentEditingAction = settingActions[selectedSettingOption];
        } else if (selectedSettingOption == settingActions.length) {
            // 保存设置并返回主菜单
            keySettings.saveSettings();
            inSettingsMenu = false;
            selectedSettingOption = 0;
        } else if (selectedSettingOption == settingActions.length + 1) {
            // 重置按键设置
            keySettings.resetToDefaults();
            keySettings.saveSettings();
        }
    }
    
    /**
     * 处理联机菜单的键盘输入
     */
    private void handleMultiplayerKeyInput(KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        if (editingField) {
            if (keyCode == KeyEvent.VK_ENTER) {
                // 确认输入
                switch (multiplayerSelectedField) {
                    case 0:
                        serverAddress = currentInput;
                        break;
                    case 1:
                        serverPort = currentInput;
                        break;
                    case 2:
                        playerName = currentInput;
                        break;
                    case 5:
                        echoMessage = currentInput;
                        break;
                }
                editingField = false;
                currentInput = "";
            } else if (keyCode == KeyEvent.VK_ESCAPE) {
                // 取消输入
                editingField = false;
                currentInput = "";
            } else if (keyCode == KeyEvent.VK_BACK_SPACE) {
                // 删除字符
                if (currentInput.length() > 0) {
                    currentInput = currentInput.substring(0, currentInput.length() - 1);
                }
            } else {
                // 添加字符
                char keyChar = e.getKeyChar();
                if (Character.isLetterOrDigit(keyChar) || keyChar == '.' || keyChar == ':' || keyChar == '-' || keyChar == '_') {
                    currentInput += keyChar;
                }
            }
        } else {
            switch (keyCode) {
                case KeyEvent.VK_UP:
                    multiplayerSelectedField = Math.max(0, multiplayerSelectedField - 1);
                    break;
                case KeyEvent.VK_DOWN:
                    multiplayerSelectedField = Math.min(7, multiplayerSelectedField + 1);
                    break;
                case KeyEvent.VK_ENTER:
                    executeMultiplayerOption();
                    break;
                case KeyEvent.VK_ESCAPE:
                    inMultiplayerMenu = false;
                    multiplayerSelectedField = 0;
                    break;
            }
        }
    }
    
    /**
     * 处理联机菜单的鼠标点击
     */
    private void handleMultiplayerMouseClick(MouseEvent e) {
        Point clickPoint = e.getPoint();
        
        for (int i = 0; i < multiplayerFieldRects.length; i++) {
            if (multiplayerFieldRects[i] != null && multiplayerFieldRects[i].contains(clickPoint)) {
                multiplayerSelectedField = i;
                executeMultiplayerOption();
                return;
            }
        }
    }
    
    /**
     * 处理联机菜单的鼠标移动
     */
    private void handleMultiplayerMouseMove(MouseEvent e) {
        Point mousePoint = e.getPoint();
        
        for (int i = 0; i < multiplayerFieldRects.length; i++) {
            if (multiplayerFieldRects[i] != null && multiplayerFieldRects[i].contains(mousePoint)) {
                multiplayerSelectedField = i;
                return;
            }
        }
    }
    
    /**
     * 执行联机菜单选项
     */
    private void executeMultiplayerOption() {
        switch (multiplayerSelectedField) {
            case 0: // 服务器地址
            case 1: // 端口
            case 2: // 玩家名称
            case 5: // Echo消息
                if (!editingField) {
                    editingField = true;
                    switch (multiplayerSelectedField) {
                        case 0:
                            currentInput = serverAddress;
                            break;
                        case 1:
                            currentInput = serverPort;
                            break;
                        case 2:
                            currentInput = playerName;
                            break;
                        case 5:
                            currentInput = echoMessage;
                            break;
                    }
                }
                break;
            case 3: // 连接服务器
                 try {
                     int port = Integer.parseInt(serverPort);
                     gp.startMultiplayerGame(serverAddress, port, playerName);
                     inMultiplayerMenu = false;
                     multiplayerSelectedField = 0;
                     editingField = false;
                     currentInput = "";
                 } catch (NumberFormatException ex) {
                     System.err.println("无效的端口号: " + serverPort);
                 }
                 break;
            case 4: // 开设服务器
                 if (!isServerRunning) {
                     try {
                         int port = Integer.parseInt(serverPort);
                         // 创建并启动服务器
                         gp.startServer(port);
                         isServerRunning = true;
                         System.out.println("服务器已在端口 " + port + " 上启动");
                     } catch (NumberFormatException ex) {
                         System.err.println("无效的端口号: " + serverPort);
                     }
                 } else {
                     // 停止服务器
                     gp.stopServer();
                     isServerRunning = false;
                     System.out.println("服务器已停止");
                 }
                 break;
            case 6: // 发送Echo
                if (gp.isMultiplayer && gp.networkClient != null && gp.networkClient.isConnected()) {
                    // 发送Echo测试消息
                    gp.networkClient.sendEcho(echoMessage);
                    System.out.println("已发送Echo测试消息: " + echoMessage);
                } else {
                    System.err.println("请先连接到服务器");
                }
                break;
            case 7: // 返回
                if (isServerRunning) {
                    // 如果服务器正在运行，先停止服务器
                    gp.stopServer();
                    isServerRunning = false;
                    System.out.println("服务器已停止");
                }
                inMultiplayerMenu = false;
                multiplayerSelectedField = 0;
                editingField = false;
                currentInput = "";
                break;
        }
    }
    
    /**
     * 重置开始页面状态
     */
    public void reset() {
        selectedOption = 0;
        inSettingsMenu = false;
        selectedSettingOption = 0;
        waitingForKeyInput = false;
        currentEditingAction = null;
        inMultiplayerMenu = false;
        multiplayerSelectedField = 0;
        editingField = false;
        currentInput = "";
    }
}