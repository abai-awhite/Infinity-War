package main;

import entity.entity;
import entity.player;

/**
 * 碰撞检测类
 * 负责检测游戏实体与地图图块之间的碰撞
 * 支持八个方向的移动碰撞检测
 */
public class pengzhuang {
    GamePanel gp; // 游戏面板引用
    
    /**
     * 构造函数
     * @param gp 游戏面板实例，用于获取地图和图块信息
     */
    public pengzhuang(GamePanel gp) {
        this.gp=gp;
    }
    /**
     * 检测实体与地图图块的碰撞
     * 根据实体的移动方向预测下一帧的位置，检查是否会与图块发生碰撞
     * @param entity 要检测碰撞的实体对象
     */
    public void checktile(entity entity) {
        // 计算实体碰撞箱的四个边界在世界坐标中的位置
        int leftWorldX = entity.worldx + entity.solidarea.x;
        int rightWorldX = entity.worldx + entity.solidarea.x + entity.solidarea.width;
        int topWorldY = entity.worldy + entity.solidarea.y;
        int bottomWorldY = entity.worldy + entity.solidarea.y + entity.solidarea.height;

        // 计算对应的图块坐标（将世界坐标转换为图块网格坐标）
        int leftCol = leftWorldX / gp.tileSize;
        int rightCol = rightWorldX / gp.tileSize;
        int topRow = topWorldY / gp.tileSize;
        int bottomRow = bottomWorldY / gp.tileSize;

        // 根据移动方向检查碰撞，预测下一帧位置是否会发生碰撞
        switch (entity.direction) {
            case "up": // 向上移动
                topRow = (topWorldY - entity.speed) / gp.tileSize;
                // 检查实体上边界的左右两个角是否会碰撞
                if (isColliding(leftCol, topRow) || isColliding(rightCol, topRow)) {
                    entity.collisionon = true;
                }
                break;

            case "down": // 向下移动
                bottomRow = (bottomWorldY + entity.speed) / gp.tileSize;
                // 检查实体下边界的左右两个角是否会碰撞
                if (isColliding(leftCol, bottomRow) || isColliding(rightCol, bottomRow)) {
                    entity.collisionon = true;
                }
                break;

            case "left": // 向左移动
                leftCol = (leftWorldX - entity.speed) / gp.tileSize;
                // 检查实体左边界的上下两个角是否会碰撞
                if (isColliding(leftCol, topRow) || isColliding(leftCol, bottomRow)) {
                    entity.collisionon = true;
                }
                break;

            case "right": // 向右移动
                rightCol = (rightWorldX + entity.speed) / gp.tileSize;
                // 检查实体右边界的上下两个角是否会碰撞
                if (isColliding(rightCol, topRow) || isColliding(rightCol, bottomRow)) {
                    entity.collisionon = true;
                }
                break;
            case "upright": // 右上对角线移动
                topRow = (topWorldY - entity.speed) / gp.tileSize;
                rightCol = (rightWorldX + entity.speed) / gp.tileSize;
                // 检查右上角是否会碰撞
                if (isColliding(rightCol, topRow)) {
                    entity.collisionon = true;
                }
                break;

            case "upleft": // 左上对角线移动
                topRow = (topWorldY - entity.speed) / gp.tileSize;
                leftCol = (leftWorldX - entity.speed) / gp.tileSize;
                // 检查左上角是否会碰撞
                if (isColliding(leftCol, topRow)) {
                    entity.collisionon = true;
                }
                break;

            case "downright": // 右下对角线移动
                bottomRow = (bottomWorldY + entity.speed) / gp.tileSize;
                rightCol = (rightWorldX + entity.speed) / gp.tileSize;
                // 检查右下角是否会碰撞
                if (isColliding(rightCol, bottomRow)) {
                    entity.collisionon = true;
                }
                break;

            case "downleft": // 左下对角线移动
                bottomRow = (bottomWorldY + entity.speed) / gp.tileSize;
                leftCol = (leftWorldX - entity.speed) / gp.tileSize;
                // 检查左下角是否会碰撞
                if (isColliding(leftCol, bottomRow)) {
                    entity.collisionon = true;
                }
                break;

            case "stop":
                // 停止状态不需要检查碰撞
                break;
        }
    }

    /**
     * 水平碰撞检测方法 - 专为水平移动设计
     * 检测实体在水平方向上的碰撞，支持向左和向右的移动
     * @param entity 要检测碰撞的实体对象
     * @param horizontalMovement 水平移动距离（正数向右，负数向左）
     */
    public void checkHorizontalCollision(entity entity, int horizontalMovement) {
        // 计算实体的边界坐标
        int leftWorldX = entity.worldx + entity.solidarea.x;
        int rightWorldX = entity.worldx + entity.solidarea.x + entity.solidarea.width;
        int topWorldY = entity.worldy + entity.solidarea.y;
        int bottomWorldY = entity.worldy + entity.solidarea.y + entity.solidarea.height;
        
        // 计算当前占用的图块行
        int topRow = topWorldY / gp.tileSize;
        int bottomRow = bottomWorldY / gp.tileSize;
        
        if (horizontalMovement < 0) {
            // 向左移动 - 检查左侧碰撞
            int leftCol = (leftWorldX + horizontalMovement) / gp.tileSize;
            
            // 检查左侧上角和下角
            if (isColliding(leftCol, topRow) || isColliding(leftCol, bottomRow)) {
                entity.collisionon = true;
            }
        } else if (horizontalMovement > 0) {
            // 向右移动 - 检查右侧碰撞
            int rightCol = (rightWorldX + horizontalMovement) / gp.tileSize;
            
            // 检查右侧上角和下角
            if (isColliding(rightCol, topRow) || isColliding(rightCol, bottomRow)) {
                entity.collisionon = true;
            }
        }
    }
    
    /**
     * 垂直碰撞检测方法 - 专为跳跃系统设计
     * 检测实体在垂直方向上的碰撞，支持向上和向下的移动
     * @param entity 要检测碰撞的实体对象
     * @param verticalMovement 垂直移动距离（正数向下，负数向上）
     */
    public void checkVerticalCollision(entity entity, int verticalMovement) {
        // 计算实体的边界坐标
        int leftWorldX = entity.worldx + entity.solidarea.x;
        int rightWorldX = entity.worldx + entity.solidarea.x + entity.solidarea.width;
        int topWorldY = entity.worldy + entity.solidarea.y;
        int bottomWorldY = entity.worldy + entity.solidarea.y + entity.solidarea.height;
        
        // 计算当前占用的图块列
        int leftCol = leftWorldX / gp.tileSize;
        int rightCol = rightWorldX / gp.tileSize;
        
        if (verticalMovement < 0) {
            // 向上移动 - 检查头部碰撞
            int topRow = (topWorldY + verticalMovement) / gp.tileSize;
            
            // 检查头部左上角和右上角
            if (isColliding(leftCol, topRow) || isColliding(rightCol, topRow)) {
                entity.collisionon = true;
            }
        } else if (verticalMovement > 0) {
            // 向下移动 - 检查脚部碰撞
            int bottomRow = (bottomWorldY + verticalMovement) / gp.tileSize;
            
            // 检查脚部左下角和右下角
            if (isColliding(leftCol, bottomRow) || isColliding(rightCol, bottomRow)) {
                entity.collisionon = true;
            }
        }
    }
    
    /**
     * 辅助方法：检查指定图块坐标是否有碰撞
     * 检查给定的图块坐标是否超出边界或具有碰撞属性
     * @param col 图块的列坐标
     * @param row 图块的行坐标
     * @return true表示有碰撞，false表示无碰撞
     */
    private boolean isColliding(int col, int row) {
        
        // 屏幕边界检查 - 防止数组越界（双重保护）
        if (col < 0 || col >= gp.maxworldcol || row < 0 || row >= gp.maxworldrow) {
            return true; // 超出屏幕边界视为碰撞
        }

        // 获取指定位置的图块索引
        int tileIndex = gp.tilemanager.mapnum[col][row];

        // 检查图块索引是否有效，防止访问不存在的图块类型
        if (tileIndex < 0 || tileIndex >= gp.tilemanager.TI.length) {
            return true; // 无效索引视为碰撞
        }

        // 检查该图块类型是否具有碰撞属性
        return gp.tilemanager.TI[tileIndex].collision;
    }
}




