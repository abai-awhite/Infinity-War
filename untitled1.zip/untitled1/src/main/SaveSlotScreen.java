package main;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;

/**
 * 存档选择界面类
 * 负责显示、选择、创建和删除存档
 */
public class SaveSlotScreen {
    private int selectedSlot = 0;           // 当前选中的存档槽
    private List<String> saveFiles;        // 存档文件列表
    private SaveManager saveManager;       // 存档管理器引用
    private boolean isLoadMode;            // 是否为加载模式（否则为保存模式）
    private String newSaveName = "";      // 新存档名称（用于创建新存档）
    private boolean isNamingNewSave = false; // 是否正在命名新存档
    private boolean showKeyboard = false;  // 是否显示虚拟键盘
    
    // UI相关属性
    private final Color backgroundColor = new Color(0, 0, 0, 150);      // 半透明黑色背景
    private final Color menuBackgroundColor = new Color(40, 40, 40, 200); // 菜单背景
    private final Color selectedColor = new Color(255, 215, 0);         // 选中项颜色（金色）
    private final Color normalColor = Color.WHITE;                       // 普通项颜色
    private final Font titleFont = new Font("微软雅黑", Font.BOLD, 36);    // 标题字体
    private final Font menuFont = new Font("微软雅黑", Font.PLAIN, 24);    // 菜单字体
    private final Font infoFont = new Font("微软雅黑", Font.PLAIN, 16);    // 信息字体
    
    /**
     * 构造函数
     */
    public SaveSlotScreen(SaveManager saveManager, boolean isLoadMode) {
        this.saveManager = saveManager;
        this.isLoadMode = isLoadMode;
        refreshSaveList();
    }
    
    /**
     * 刷新存档列表
     */
    public void refreshSaveList() {
        saveFiles = saveManager.getSaveFileList();
    }
    
    /**
     * 渲染存档选择界面
     */
    public void draw(Graphics2D g2, int screenWidth, int screenHeight) {
        // 绘制半透明背景
        g2.setColor(backgroundColor);
        g2.fillRect(0, 0, screenWidth, screenHeight);
        
        // 计算菜单位置和尺寸
        int menuWidth = 500;
        int menuHeight = 450;
        int menuX = (screenWidth - menuWidth) / 2;
        int menuY = (screenHeight - menuHeight) / 2;
        
        // 绘制菜单背景
        g2.setColor(menuBackgroundColor);
        g2.fillRoundRect(menuX, menuY, menuWidth, menuHeight, 20, 20);
        
        // 绘制菜单边框
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(menuX, menuY, menuWidth, menuHeight, 20, 20);
        
        // 绘制标题
        g2.setFont(titleFont);
        g2.setColor(Color.WHITE);
        String title = isLoadMode ? "加载游戏" : "保存游戏";
        FontMetrics titleMetrics = g2.getFontMetrics(titleFont);
        int titleX = menuX + (menuWidth - titleMetrics.stringWidth(title)) / 2;
        int titleY = menuY + 50;
        g2.drawString(title, titleX, titleY);
        
        // 如果正在命名新存档，显示输入框
        if (isNamingNewSave) {
            drawNewSaveInput(g2, menuX, menuY, menuWidth, menuHeight);
            return;
        }
        
        // 绘制存档列表
        g2.setFont(menuFont);
        int slotY = titleY + 50;
        int slotHeight = 40;
        
        // 添加"新建存档"选项（仅在保存模式下）
        if (!isLoadMode) {
            if (selectedSlot == 0) {
                g2.setColor(selectedColor);
                g2.fillRoundRect(menuX + 20, slotY - 30, menuWidth - 40, slotHeight, 10, 10);
                g2.setColor(Color.BLACK);
            } else {
                g2.setColor(normalColor);
            }
            g2.drawString("新建存档", menuX + 30, slotY);
            slotY += slotHeight + 10;
        }
        
        // 绘制现有存档
        for (int i = 0; i < saveFiles.size(); i++) {
            int slotIndex = isLoadMode ? i : i + 1;
            if (selectedSlot == slotIndex) {
                g2.setColor(selectedColor);
                g2.fillRoundRect(menuX + 20, slotY - 30, menuWidth - 40, slotHeight, 10, 10);
                g2.setColor(Color.BLACK);
            } else {
                g2.setColor(normalColor);
            }
            
            String saveName = saveFiles.get(i);
            g2.drawString(saveName, menuX + 30, slotY);
            
            // 获取存档信息（如果可用）
            GameSave saveInfo = saveManager.getSaveInfo(saveName);
            if (saveInfo != null) {
                g2.setFont(infoFont);
                g2.drawString(saveInfo.getFormattedSaveTime(), menuX + 300, slotY);
                g2.setFont(menuFont);
            }
            
            slotY += slotHeight + 10;
        }
        
        // 绘制返回选项
        int returnIndex = isLoadMode ? saveFiles.size() : saveFiles.size() + 1;
        if (selectedSlot == returnIndex) {
            g2.setColor(selectedColor);
            g2.fillRoundRect(menuX + 20, slotY - 30, menuWidth - 40, slotHeight, 10, 10);
            g2.setColor(Color.BLACK);
        } else {
            g2.setColor(normalColor);
        }
        g2.drawString("返回", menuX + 30, slotY);
        
        // 绘制操作提示
        g2.setFont(infoFont);
        g2.setColor(Color.LIGHT_GRAY);
        String hint = "使用↑↓键选择，回车键确认，ESC键返回";
        if (!isLoadMode) {
            hint += "，DEL键删除存档";
        }
        FontMetrics hintMetrics = g2.getFontMetrics(infoFont);
        int hintX = menuX + (menuWidth - hintMetrics.stringWidth(hint)) / 2;
        int hintY = menuY + menuHeight - 20;
        g2.drawString(hint, hintX, hintY);
    }
    
    /**
     * 绘制新存档输入界面
     */
    private void drawNewSaveInput(Graphics2D g2, int menuX, int menuY, int menuWidth, int menuHeight) {
        // 绘制输入框标题
        g2.setFont(menuFont);
        g2.setColor(Color.WHITE);
        String prompt = "请输入存档名称:";
        int promptY = menuY + 120;
        g2.drawString(prompt, menuX + 30, promptY);
        
        // 绘制输入框
        int inputBoxX = menuX + 30;
        int inputBoxY = promptY + 20;
        int inputBoxWidth = menuWidth - 60;
        int inputBoxHeight = 40;
        
        g2.setColor(Color.BLACK);
        g2.fillRect(inputBoxX, inputBoxY, inputBoxWidth, inputBoxHeight);
        g2.setColor(Color.WHITE);
        g2.drawRect(inputBoxX, inputBoxY, inputBoxWidth, inputBoxHeight);
        
        // 绘制当前输入的文本
        g2.setFont(menuFont);
        g2.drawString(newSaveName + "_", inputBoxX + 10, inputBoxY + 30);
        
        // 绘制确认和取消按钮
        int buttonY = inputBoxY + 80;
        int buttonWidth = 120;
        int buttonHeight = 40;
        
        // 确认按钮
        g2.setColor(new Color(50, 150, 50));
        g2.fillRoundRect(menuX + menuWidth/2 - buttonWidth - 20, buttonY, buttonWidth, buttonHeight, 10, 10);
        g2.setColor(Color.WHITE);
        g2.drawString("确认", menuX + menuWidth/2 - buttonWidth + 30, buttonY + 30);
        
        // 取消按钮
        g2.setColor(new Color(150, 50, 50));
        g2.fillRoundRect(menuX + menuWidth/2 + 20, buttonY, buttonWidth, buttonHeight, 10, 10);
        g2.setColor(Color.WHITE);
        g2.drawString("取消", menuX + menuWidth/2 + 70, buttonY + 30);
    }
    
    /**
     * 处理输入
     * @return 操作结果：
     *         0 = 无操作
     *         1 = 返回上一级菜单
     *         2 = 选择了存档（保存或加载）
     */
    public int handleInput(KeyBoard KB) {
        // 如果正在命名新存档，处理文本输入
        if (isNamingNewSave) {
            return handleNewSaveInput(KB);
        }
        
        // 处理上下箭头键选择
        if (KB.upArrowPressed) {
            int maxIndex = isLoadMode ? saveFiles.size() : saveFiles.size() + 1;
            selectedSlot = (selectedSlot - 1 + maxIndex + 1) % (maxIndex + 1);
            KB.upArrowPressed = false;
        }
        if (KB.downArrowPressed) {
            int maxIndex = isLoadMode ? saveFiles.size() : saveFiles.size() + 1;
            selectedSlot = (selectedSlot + 1) % (maxIndex + 1);
            KB.downArrowPressed = false;
        }
        
        // 处理回车键确认选择
        if (KB.enterPressed) {
            KB.enterPressed = false;
            
            // 返回选项
            int returnIndex = isLoadMode ? saveFiles.size() : saveFiles.size() + 1;
            if (selectedSlot == returnIndex) {
                return 1; // 返回上一级菜单
            }
            
            // 新建存档选项（仅在保存模式下）
            if (!isLoadMode && selectedSlot == 0) {
                isNamingNewSave = true;
                newSaveName = "";
                return 0;
            }
            
            // 选择现有存档
            int saveIndex = isLoadMode ? selectedSlot : selectedSlot - 1;
            if (saveIndex >= 0 && saveIndex < saveFiles.size()) {
                return 2; // 选择了存档
            }
        }
        
        // 处理ESC键返回
        if (KB.escPressed) {
            KB.escPressed = false;
            return 1; // 返回上一级菜单
        }
        
        // 处理DEL键删除存档（仅在非加载模式下）
        if (!isLoadMode && KB.lastKeyPressed == KeyEvent.VK_DELETE && KB.hasNewKeyPress) {
            KB.hasNewKeyPress = false;
            
            // 确保选择的是现有存档
            int saveIndex = selectedSlot - 1;
            if (saveIndex >= 0 && saveIndex < saveFiles.size()) {
                String saveName = saveFiles.get(saveIndex);
                saveManager.deleteSave(saveName);
                refreshSaveList();
                
                // 调整选择索引
                if (selectedSlot > saveFiles.size()) {
                    selectedSlot = saveFiles.size() + 1; // 返回选项
                }
            }
        }
        
        return 0; // 无操作
    }
    
    /**
     * 处理新存档命名输入
     */
    private int handleNewSaveInput(KeyBoard KB) {
        // 处理ESC键取消
        if (KB.escPressed) {
            KB.escPressed = false;
            isNamingNewSave = false;
            return 0;
        }
        
        // 处理回车键确认
        if (KB.enterPressed) {
            KB.enterPressed = false;
            if (!newSaveName.isEmpty()) {
                isNamingNewSave = false;
                return 2; // 选择了存档（新建）
            }
        }
        
        // 处理退格键
        if (KB.lastKeyPressed == KeyEvent.VK_BACK_SPACE && KB.hasNewKeyPress && !newSaveName.isEmpty()) {
            KB.hasNewKeyPress = false;
            newSaveName = newSaveName.substring(0, newSaveName.length() - 1);
        }
        
        // 处理字符输入
        if (KB.hasNewKeyPress) {
            int keyCode = KB.lastKeyPressed;
            KB.hasNewKeyPress = false;
            
            // 只允许字母、数字和一些特殊字符
            char c = 0;
            if (keyCode >= KeyEvent.VK_A && keyCode <= KeyEvent.VK_Z) {
                c = (char)('a' + (keyCode - KeyEvent.VK_A));
                if (KB.shift) c = Character.toUpperCase(c);
            } else if (keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_9) {
                c = (char)('0' + (keyCode - KeyEvent.VK_0));
            } else if (keyCode == KeyEvent.VK_MINUS) {
                c = '-';
            } else if (keyCode == KeyEvent.VK_UNDERSCORE || (keyCode == KeyEvent.VK_MINUS && KB.shift)) {
                c = '_';
            }
            
            if (c != 0 && newSaveName.length() < 20) { // 限制长度
                newSaveName += c;
            }
        }
        
        return 0; // 无操作
    }
    
    /**
     * 获取选中的存档名称
     */
    public String getSelectedSaveName() {
        if (isNamingNewSave) {
            return newSaveName;
        }
        
        int saveIndex = isLoadMode ? selectedSlot : selectedSlot - 1;
        if (saveIndex >= 0 && saveIndex < saveFiles.size()) {
            return saveFiles.get(saveIndex);
        }
        
        return null;
    }
    
    /**
     * 重置选择
     */
    public void reset() {
        selectedSlot = 0;
        isNamingNewSave = false;
        refreshSaveList();
    }
}